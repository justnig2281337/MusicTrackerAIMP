package com.example.aimphistory

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.service.notification.NotificationListenerService

/** Всё, что не даёт системе (особенно Xiaomi) выгрузить отслеживание. */
object Keep {
    fun on(c: Context) = c.getSharedPreferences("p", 0).getBoolean("keep", true)

    fun granted(c: Context) = Settings.Secure.getString(c.contentResolver, "enabled_notification_listeners")
        ?.contains(c.packageName) == true

    /** Принудительно просит систему заново подключить службу уведомлений. */
    fun rebind(c: Context) {
        if (!granted(c)) return
        val cn = ComponentName(c, Listener::class.java)
        try {
            val pm = c.packageManager
            pm.setComponentEnabledSetting(cn, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
            pm.setComponentEnabledSetting(cn, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
        } catch (e: Exception) { }
        try { NotificationListenerService.requestRebind(cn) } catch (e: Exception) { }
    }

    fun startFgs(c: Context) {
        if (!on(c)) return
        try { c.startForegroundService(Intent(c, KeepAlive::class.java)) } catch (e: Exception) { }
    }

    fun stopFgs(c: Context) { try { c.stopService(Intent(c, KeepAlive::class.java)) } catch (e: Exception) { } }

    /** Периодическая проверка раз в ~15 минут: если служба отвалилась — переподключаем. */
    fun schedule(c: Context) {
        try {
            val js = c.getSystemService(JobScheduler::class.java)
            if (js.getPendingJob(77) != null) return
            js.schedule(JobInfo.Builder(77, ComponentName(c, Watchdog::class.java))
                .setPeriodic(15 * 60 * 1000L).setPersisted(true).build())
        } catch (e: Exception) { }
    }

    fun ensure(c: Context) {
        startFgs(c)
        schedule(c)
        if (!Listener.connected) rebind(c)
    }
}

/** Постоянное тихое уведомление — приложение считается «активным» и не выгружается. */
class KeepAlive : Service() {
    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("keep", "Работа в фоне", NotificationManager.IMPORTANCE_MIN))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "keep")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("AIMP История")
            .setContentText("Отслеживаю, что играет в AIMP")
            .setContentIntent(pi).setOngoing(true).build()
        try {
            if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            else startForeground(1, n)
        } catch (e: Exception) { stopSelf() }
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int = START_STICKY

    override fun onTaskRemoved(rootIntent: Intent?) {
        Keep.ensure(this)
        super.onTaskRemoved(rootIntent)
    }
}

class Watchdog : JobService() {
    override fun onStartJob(p: JobParameters?): Boolean {
        if (!Listener.connected) Keep.rebind(this)
        return false
    }
    override fun onStopJob(p: JobParameters?) = false
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { Keep.ensure(c) }
}
