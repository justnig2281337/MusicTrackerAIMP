package com.example.aimphistory

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.util.LruCache
import android.view.*
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager.widget.PagerAdapter
import androidx.viewpager.widget.ViewPager
import java.io.File
import java.text.Collator
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors
import java.util.zip.*

class Pg(private val views: List<View>) : PagerAdapter() {
    override fun getCount() = views.size
    override fun isViewFromObject(v: View, o: Any) = v === o
    override fun instantiateItem(c: ViewGroup, i: Int): Any { c.addView(views[i]); return views[i] }
    override fun destroyItem(c: ViewGroup, i: Int, o: Any) { c.removeView(o as View) }
}

class MainActivity : Activity() {
    private lateinit var db: Db
    private lateinit var pr: SharedPreferences
    private lateinit var p: P
    private lateinit var mainRoot: View
    private lateinit var banner: TextView
    private lateinit var search: EditText
    private lateinit var countTv: TextView
    private lateinit var emptyTv: TextView
    private lateinit var histRv: RecyclerView
    private lateinit var histAd: Hist
    private lateinit var stTime: TextView
    private lateinit var stTracks: TextView
    private lateinit var stArtists: TextView
    private lateinit var wkTitle: TextView
    private lateinit var wkSub: TextView
    private lateinit var wkTotal: TextView
    private lateinit var wkRight: TextView
    private lateinit var wkChart: WeekChart
    private lateinit var genBox: LinearLayout

    private var all: List<Track> = emptyList()
    private var inSettings = false
    private var sortIdx = 0
    private var weekOffset = 0

    private val fmt = SimpleDateFormat("dd.MM.yyyy  HH:mm:ss", Locale.getDefault())
    private val pool = Executors.newFixedThreadPool(2)
    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 8 / 1024).toInt()) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount / 1024
    }
    private val sortNames = arrayOf(
        "Сначала новые", "Сначала старые", "Артист: А → Я", "Артист: Я → А",
        "Название: А → Я", "Название: Я → А", "Альбом: А → Я", "Альбом: Я → А"
    )

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun lp(w: Int, h: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt)

    override fun onCreate(b: android.os.Bundle?) {
        super.onCreate(b)
        db = Db.get(this)
        pr = getSharedPreferences("p", 0)
        sortIdx = pr.getInt("sort", 0).coerceIn(0, sortNames.size - 1)
        Db.onChange = { reload() }
        applyTheme()
        buildMain()
        setContentView(mainRoot)
    }

    override fun onResume() {
        super.onResume()
        banner.visibility = if (enabled()) View.GONE else View.VISIBLE
        reload()
    }

    override fun onDestroy() { Db.onChange = null; super.onDestroy() }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (inSettings) closeSettings() else super.onBackPressed() }

    private fun applyTheme() {
        p = PALS[pr.getInt("theme", 0).coerceIn(0, PALS.lastIndex)]
        window.statusBarColor = p.bg
        window.navigationBarColor = p.bg
        var f = 0
        if (p.light) f = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        window.decorView.systemUiVisibility = f
    }

    private fun tv(t: String, sz: Float, col: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sz; setTextColor(col)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun cardBg(r: Int = 16) = GradientDrawable().apply { setColor(p.card); cornerRadius = dp(r).toFloat() }
    private fun fmtDur(ms: Long): String { val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60) }
    private fun hm(ms: Long) = "${ms / 3600000} ч ${ms / 60000 % 60} мин"
    private fun toast(s: String) = runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_LONG).show() }
    private fun enabled() = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        ?.contains(packageName) == true

    private fun hideKb() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(search.windowToken, 0)
        search.clearFocus()
    }

    // ---------- картинки ----------
    private fun load(name: String, minSide: Int): Bitmap? {
        if (name.isEmpty()) return null
        val f = File(db.coverDir, name)
        if (!f.exists()) return null
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (o.outWidth / (s * 2) >= minSide && o.outHeight / (s * 2) >= minSide) s *= 2
        return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
    }

    private fun loadCap(name: String, cap: Int): Bitmap? {
        if (name.isEmpty()) return null
        val f = File(db.coverDir, name)
        if (!f.exists()) return null
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (maxOf(o.outWidth, o.outHeight) / s > cap) s *= 2
        return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
    }

    private fun bindCover(img: ImageView, name: String) {
        img.tag = name
        val c = if (name.isEmpty()) null else cache.get(name)
        if (c != null) { img.setImageBitmap(c); return }
        img.setImageDrawable(ColorDrawable(p.bg))
        if (name.isEmpty()) return
        pool.execute {
            val bm = load(name, 192)
            if (bm != null) {
                cache.put(name, bm)
                runOnUiThread { if (img.tag == name) img.setImageBitmap(bm) }
            }
        }
    }

    // ---------- данные ----------
    private fun reload() {
        Thread {
            val l = db.all()
            runOnUiThread { if (!isDestroyed) { all = l; refreshUi() } }
        }.start()
    }

    private fun refreshUi() { applyFilter(false); updateStats() }

    // ---------- каркас: вкладки + страницы ----------
    private fun buildMain() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(p.bg) }
        val t0 = tv("История", 17f, p.ac, true)
        val t1 = tv("Статистика", 17f, p.sub, true)
        val tabs = LinearLayout(this)
        for (t in listOf(t0, t1)) {
            t.gravity = Gravity.CENTER; t.setPadding(0, dp(14), 0, dp(14))
            tabs.addView(t, lp(0, -2, 1f))
        }
        val ind = View(this).apply { background = GradientDrawable().apply { setColor(p.ac); cornerRadius = dp(2).toFloat() } }
        val tabWrap = FrameLayout(this)
        tabWrap.addView(tabs, FrameLayout.LayoutParams(-1, -2))
        tabWrap.addView(ind, FrameLayout.LayoutParams(dp(60), dp(3), Gravity.BOTTOM))
        tabWrap.post {
            val w = tabWrap.width / 2 - dp(40)
            ind.layoutParams = FrameLayout.LayoutParams(w, dp(3), Gravity.BOTTOM).apply { leftMargin = dp(20) }
        }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(4), dp(4), 0) }
        bar.addView(tabWrap, lp(0, -2, 1f))
        bar.addView(tv("⚙", 24f, p.ac).apply {
            setPadding(dp(14), dp(8), dp(14), dp(8)); setOnClickListener { showSettings() }
        })
        root.addView(bar)

        banner = tv("Нужен доступ к уведомлениям — нажми сюда и включи «AIMP История»", 14f, p.tx).apply {
            background = cardBg(); setPadding(dp(14), dp(12), dp(14), dp(12))
            setOnClickListener { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
        }
        root.addView(banner, lp(-1, -2).apply { setMargins(dp(12), dp(8), dp(12), 0) })

        val pager = ViewPager(this)
        pager.adapter = Pg(listOf(buildHistory(), buildStats()))
        pager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(pos: Int, off: Float, px: Int) { ind.translationX = (pos + off) * tabWrap.width / 2f }
            override fun onPageSelected(pos: Int) {
                t0.setTextColor(if (pos == 0) p.ac else p.sub)
                t1.setTextColor(if (pos == 1) p.ac else p.sub)
                hideKb()
            }
            override fun onPageScrollStateChanged(s: Int) {}
        })
        t0.setOnClickListener { pager.setCurrentItem(0, true) }
        t1.setOnClickListener { pager.setCurrentItem(1, true) }
        root.addView(pager, lp(-1, 0, 1f))
        mainRoot = root
        refreshUi()
    }

    // ---------- История ----------
    private fun comparator(i: Int): Comparator<Track> {
        val c = Collator.getInstance()
        return when (i) {
            1 -> Comparator { a, b -> a.ts.compareTo(b.ts) }
            2 -> Comparator { a, b -> c.compare(a.artist, b.artist) }
            3 -> Comparator { a, b -> c.compare(b.artist, a.artist) }
            4 -> Comparator { a, b -> c.compare(a.title, b.title) }
            5 -> Comparator { a, b -> c.compare(b.title, a.title) }
            6 -> Comparator { a, b -> c.compare(a.album, b.album) }
            7 -> Comparator { a, b -> c.compare(b.album, a.album) }
            else -> Comparator { a, b -> b.ts.compareTo(a.ts) }
        }
    }

    private fun applyFilter(toTop: Boolean) {
        val q = search.text.toString().trim().lowercase()
        var l: List<Track> = all
        if (q.isNotEmpty()) {
            val parts = q.split(' ').filter { it.isNotEmpty() }
            l = l.filter { t -> parts.all { t.search.contains(it) } }
        }
        l = l.sortedWith(comparator(sortIdx))
        histAd.items = l
        histAd.notifyDataSetChanged()
        if (toTop) histRv.scrollToPosition(0)
        countTv.text = "${l.size} ${if (q.isNotEmpty()) "найдено" else "треков"}  •  ${sortNames[sortIdx]}"
        emptyTv.text = if (all.isEmpty())
            "Пока пусто. Включи музыку в AIMP — трек появится здесь, когда достигнет порога прослушивания."
        else "Ничего не найдено"
        emptyTv.visibility = if (l.isEmpty()) View.VISIBLE else View.GONE
    }

    inner class Hist : RecyclerView.Adapter<VH>() {
        var items: List<Track> = emptyList()
        override fun getItemCount() = items.size
        override fun onCreateViewHolder(g: ViewGroup, v: Int): VH {
            val wrap = FrameLayout(this@MainActivity).apply {
                setPadding(0, dp(5), 0, dp(5)); layoutParams = RecyclerView.LayoutParams(-1, -2)
            }
            val row = LinearLayout(this@MainActivity).apply {
                background = cardBg(); setPadding(dp(10), dp(10), dp(12), dp(10)); gravity = Gravity.CENTER_VERTICAL
            }
            val img = ImageView(this@MainActivity).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                clipToOutline = true
                outlineProvider = object : ViewOutlineProvider() {
                    override fun getOutline(view: View, o: Outline) { o.setRoundRect(0, 0, view.width, view.height, dp(10).toFloat()) }
                }
            }
            row.addView(img, lp(dp(64), dp(64)))
            val col = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
            fun line(sz: Float, c: Int, bold: Boolean) = tv("", sz, c, bold).apply {
                maxLines = 1; ellipsize = TextUtils.TruncateAt.END
            }
            val t = line(15f, p.tx, true); val a = line(13f, p.sub, false); val i = line(12f, p.ac, false)
            col.addView(t); col.addView(a); col.addView(i)
            row.addView(col, lp(0, -2, 1f))
            wrap.addView(row)
            val h = VH(img, t, a, i, wrap)
            wrap.setOnClickListener {
                val pos = h.bindingAdapterPosition
                if (pos >= 0) { hideKb(); details(items[pos]) }
            }
            return h
        }
        override fun onBindViewHolder(h: VH, pos: Int) {
            val t = items[pos]
            h.t.text = "${t.artist} - ${t.title}"
            h.a.text = t.album
            h.a.visibility = if (t.album.isEmpty()) View.GONE else View.VISIBLE
            h.i.text = "${fmtDur(t.dur)}  •  ${fmt.format(Date(t.ts))}"
            bindCover(h.img, t.cover)
        }
    }

    private fun buildHistory(): View {
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), 0) }
        val sr = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        search = EditText(this).apply {
            hint = "Поиск: артист, трек, альбом, жанр…"
            setHintTextColor(p.sub); setTextColor(p.tx); textSize = 15f
            setSingleLine(true); imeOptions = EditorInfo.IME_ACTION_SEARCH
            background = cardBg(24); setPadding(dp(18), dp(10), dp(18), dp(10))
            if (Build.VERSION.SDK_INT >= 29) {
                textCursorDrawable = GradientDrawable().apply { setColor(p.ac); setSize(dp(2), dp(20)) }
            }
            setOnEditorActionListener { _, _, _ -> hideKb(); true }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { applyFilter(true) }
            })
        }
        sr.addView(search, lp(0, dp(46), 1f))
        sr.addView(tv("⇅", 22f, p.ac).apply {
            background = cardBg(24); gravity = Gravity.CENTER; setOnClickListener { pickSort() }
        }, lp(dp(46), dp(46)).apply { leftMargin = dp(8) })
        page.addView(sr)
        countTv = tv("", 12f, p.sub).apply { setPadding(dp(6), dp(8), 0, dp(4)) }
        page.addView(countTv)
        histAd = Hist()
        histRv = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(context)
            adapter = histAd
            clipToPadding = false; setPadding(0, 0, 0, dp(16))
            overScrollMode = View.OVER_SCROLL_NEVER
            setHasFixedSize(true)
        }
        emptyTv = tv("", 15f, p.sub).apply { gravity = Gravity.CENTER; setPadding(dp(24), dp(40), dp(24), 0) }
        val fl = FrameLayout(this)
        fl.addView(histRv, FrameLayout.LayoutParams(-1, -1))
        fl.addView(emptyTv, FrameLayout.LayoutParams(-1, -2))
        page.addView(fl, lp(-1, 0, 1f))
        return page
    }

    private fun pickSort() {
        hideKb()
        AlertDialog.Builder(this).setTitle("Сортировка")
            .setSingleChoiceItems(sortNames, sortIdx) { d, i ->
                sortIdx = i; pr.edit().putInt("sort", i).apply(); applyFilter(true); d.dismiss()
            }.show()
    }

    // ---------- карточка трека ----------
    private fun details(t: Track) {
        Thread {
            val bm = loadCap(t.cover, 2048)
            runOnUiThread { showDetails(t, bm) }
        }.start()
    }

    private fun showDetails(t: Track, bm: Bitmap?) {
        val sv = ScrollView(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(8)) }
        if (bm != null) {
            col.addView(ImageView(this).apply {
                adjustViewBounds = true; setImageBitmap(bm)
                clipToOutline = true
                outlineProvider = object : ViewOutlineProvider() {
                    override fun getOutline(view: View, o: Outline) { o.setRoundRect(0, 0, view.width, view.height, dp(12).toFloat()) }
                }
                setOnClickListener { zoom(t.cover, bm) }
            }, lp(-1, -2).apply { bottomMargin = dp(4) })
            col.addView(tv("нажми на обложку, чтобы рассмотреть", 11f, p.sub))
        }
        col.addView(tv("${t.artist} - ${t.title}", 18f, p.tx, true).apply { setPadding(0, dp(12), 0, dp(8)) })
        fun row(l: String, v: String) {
            col.addView(tv(l, 12f, p.sub).apply { setPadding(0, dp(8), 0, 0) })
            col.addView(tv(v, 15f, p.tx).apply { setTextIsSelectable(true) })
        }
        row("Прослушан", fmt.format(Date(t.ts)))
        row("Длительность", fmtDur(t.dur))
        for (k in t.tags.keys()) {
            if (k == "DURATION" || k in HIDDEN) continue
            row(TAGN[k] ?: k, t.tags.get(k).toString())
        }
        sv.addView(col)
        val d = AlertDialog.Builder(this).setView(sv).setPositiveButton("Закрыть", null).create()
        d.window?.setBackgroundDrawable(cardBg(20))
        d.show()
        d.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(p.ac)
    }

    private fun zoom(name: String, small: Bitmap) {
        Thread {
            val big = loadCap(name, 3072) ?: small
            runOnUiThread {
                val z = ZoomView(this)
                z.setBackgroundColor(Color.BLACK)
                z.setImageBitmap(big)
                Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen).apply { setContentView(z); show() }
            }
        }.start()
    }

    // ---------- Статистика ----------
    private fun buildStats(): View {
        val sv = ScrollView(this).apply { overScrollMode = View.OVER_SCROLL_NEVER; isVerticalScrollBarEnabled = false }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(2), dp(12), dp(24)) }
        fun card() = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = cardBg(20); setPadding(dp(18), dp(16), dp(18), dp(16))
        }
        fun add(v: View) = col.addView(v, lp(-1, -2).apply { topMargin = dp(10) })

        val hero = card()
        hero.addView(tv("Общее время прослушивания", 13f, p.sub))
        stTime = tv("—", 32f, p.ac, true); hero.addView(stTime)
        add(hero)

        val a = card(); a.addView(tv("Треков", 13f, p.sub))
        stTracks = tv("0", 26f, p.tx, true); a.addView(stTracks)
        val b = card(); b.addView(tv("Артистов", 13f, p.sub))
        stArtists = tv("0", 26f, p.tx, true); b.addView(stArtists)
        val tiles = LinearLayout(this)
        tiles.addView(a, lp(0, -2, 1f).apply { rightMargin = dp(5) })
        tiles.addView(b, lp(0, -2, 1f).apply { leftMargin = dp(5) })
        add(tiles)

        val w = card()
        w.addView(tv("Активность по неделям", 13f, p.sub))
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val left = tv("‹", 32f, p.ac).apply { setPadding(dp(12), 0, dp(12), 0); setOnClickListener { shiftWeek(-1) } }
        wkRight = tv("›", 32f, p.ac).apply { setPadding(dp(12), 0, dp(12), 0); setOnClickListener { shiftWeek(1) } }
        wkSub = tv("", 12f, p.sub).apply { gravity = Gravity.CENTER }
        wkTitle = tv("", 17f, p.tx, true).apply { gravity = Gravity.CENTER }
        val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        mid.addView(wkSub, lp(-1, -2)); mid.addView(wkTitle, lp(-1, -2))
        head.addView(left); head.addView(mid, lp(0, -2, 1f)); head.addView(wkRight)
        w.addView(head, lp(-1, -2).apply { topMargin = dp(6) })
        wkChart = WeekChart(this, p)
        w.addView(wkChart, lp(-1, dp(180)).apply { topMargin = dp(8) })
        wkTotal = tv("", 13f, p.sub).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) }
        w.addView(wkTotal, lp(-1, -2))
        // свайп влево/вправо по карточке — смена недели
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onFling(a: MotionEvent?, b: MotionEvent, vx: Float, vy: Float): Boolean {
                if (a == null) return false
                val dx = b.x - a.x; val dy = b.y - a.y
                if (Math.abs(dx) > dp(50) && Math.abs(dx) > Math.abs(dy) * 1.2f) { shiftWeek(if (dx > 0) -1 else 1); return true }
                return false
            }
        })
        var sx = 0f; var sy = 0f
        w.setOnTouchListener { v, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) { sx = e.x; sy = e.y; v.parent.requestDisallowInterceptTouchEvent(true) }
            else if (e.actionMasked == MotionEvent.ACTION_MOVE &&
                Math.abs(e.y - sy) > Math.abs(e.x - sx) && Math.abs(e.y - sy) > dp(12)) {
                v.parent.requestDisallowInterceptTouchEvent(false)
            }
            gd.onTouchEvent(e)
            true
        }
        add(w)

        val g = card()
        g.addView(tv("Любимые жанры", 13f, p.sub))
        genBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        g.addView(genBox, lp(-1, -2).apply { topMargin = dp(6) })
        add(g)

        sv.addView(col)
        return sv
    }

    private fun shiftWeek(d: Int) {
        if (weekOffset + d > 0) return
        weekOffset += d
        val shift = wkChart.width * 0.35f * d
        wkChart.animate().translationX(-shift).alpha(0f).setDuration(110).withEndAction {
            updateWeek()
            wkChart.translationX = shift
            wkChart.animate().translationX(0f).alpha(1f).setDuration(170).start()
        }.start()
    }

    private fun dayIdx(c: Calendar) = (c.get(Calendar.DAY_OF_WEEK) + 5) % 7

    private fun updateWeek() {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        cal.add(Calendar.DAY_OF_YEAR, -dayIdx(cal))
        cal.add(Calendar.DAY_OF_YEAR, weekOffset * 7)
        val start = cal.timeInMillis
        cal.add(Calendar.DAY_OF_YEAR, 7)
        val end = cal.timeInMillis
        val vals = FloatArray(7)
        var sum = 0L
        val c2 = Calendar.getInstance()
        for (t in all) {
            if (t.ts < start || t.ts >= end) continue
            c2.timeInMillis = t.ts
            vals[dayIdx(c2)] += t.dur / 3600000f
            sum += t.dur
        }
        val today = if (weekOffset == 0) dayIdx(Calendar.getInstance()) else -1
        wkChart.set(vals, today)
        val f1 = SimpleDateFormat("d MMM", Locale.getDefault())
        val f2 = SimpleDateFormat("d MMM yyyy", Locale.getDefault())
        wkTitle.text = "${f1.format(Date(start))} – ${f2.format(Date(end - 1))}"
        wkSub.text = when (weekOffset) { 0 -> "Эта неделя"; -1 -> "Прошлая неделя"; else -> "${-weekOffset} нед. назад" }
        wkTotal.text = "Всего за неделю: ${hm(sum)}  •  часы по дням"
        wkRight.alpha = if (weekOffset == 0) 0.25f else 1f
    }

    private fun updateStats() {
        stTime.text = hm(all.sumOf { it.dur })
        stTracks.text = all.size.toString()
        stArtists.text = all.map { it.artist.trim().lowercase() }.toSet().size.toString()
        updateWeek()
        genBox.removeAllViews()
        val cnt = HashMap<String, Int>()
        for (t in all) for (g in t.genres) {
            val k = g.lowercase().replaceFirstChar { it.uppercase() }
            cnt[k] = (cnt[k] ?: 0) + 1
        }
        val top = cnt.entries.sortedByDescending { it.value }.take(5)
        if (top.isEmpty()) {
            genBox.addView(tv("Нет данных: в тегах прослушанных треков не указан жанр.", 14f, p.sub))
            return
        }
        val mx = top[0].value
        val track = (p.tx and 0xFFFFFF) or (0x22 shl 24)
        for (e in top) {
            val r = LinearLayout(this).apply { setPadding(0, dp(8), 0, dp(4)) }
            r.addView(tv(e.key, 15f, p.tx), lp(0, -2, 1f))
            r.addView(tv("${e.value * 100 / all.size}%", 13f, p.sub))
            genBox.addView(r)
            val bar = LinearLayout(this).apply {
                background = GradientDrawable().apply { setColor(track); cornerRadius = dp(4).toFloat() }
            }
            bar.addView(View(this).apply {
                background = GradientDrawable().apply { setColor(p.ac); cornerRadius = dp(4).toFloat() }
            }, lp(0, dp(8), e.value.toFloat()))
            bar.addView(View(this), lp(0, dp(8), (mx - e.value).toFloat()))
            genBox.addView(bar, lp(-1, dp(8)))
        }
    }

    // ---------- настройки ----------
    private fun btn(t: String, a: () -> Unit) = tv(t, 16f, p.tx).apply {
        background = cardBg(); setPadding(dp(16), dp(14), dp(16), dp(14)); setOnClickListener { a() }
    }

    private fun closeSettings() { inSettings = false; setContentView(mainRoot) }

    private fun showSettings() {
        hideKb()
        inSettings = true
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(24)) }
        fun add(v: View) = col.addView(v, lp(-1, -2).apply { topMargin = dp(10) })
        col.addView(tv("‹ Назад", 18f, p.ac).apply { setPadding(0, dp(8), 0, dp(8)); setOnClickListener { closeSettings() } })
        col.addView(tv("Настройки", 24f, p.tx, true))

        val th = pr.getInt("th", 60)
        val lbl = tv("Порог прослушивания: $th%", 16f, p.tx)
        add(lbl)
        add(SeekBar(this).apply {
            max = 100; progress = th
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) {
                    lbl.text = "Порог прослушивания: $v%"; pr.edit().putInt("th", v).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        add(tv("С какого процента трек считается прослушанным и попадает в историю (0–100).", 12f, p.sub))

        add(btn("Тема оформления: ${p.n}") {
            AlertDialog.Builder(this).setItems(PALS.map { it.n }.toTypedArray()) { _, i ->
                pr.edit().putInt("theme", i).apply(); applyTheme(); buildMain(); showSettings()
            }.show()
        })
        add(btn("Создать бэкап") {
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "application/zip"
                putExtra(Intent.EXTRA_TITLE, "aimp-history-" + SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date()) + ".zip")
            }, 1)
        })
        add(btn("Восстановить из бэкапа") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            }, 2)
        })
        add(btn("Доступ к уведомлениям") {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        })
        add(btn("Удалить всю историю") {
            AlertDialog.Builder(this).setMessage("Удалить всю историю прослушиваний? Это нельзя отменить.")
                .setPositiveButton("Удалить") { _, _ -> db.clear(); cache.evictAll(); toast("История удалена") }
                .setNegativeButton("Отмена", null).show()
        }.apply { setTextColor(0xFFFF5252.toInt()) })

        setContentView(ScrollView(this).apply { setBackgroundColor(p.bg); addView(col) })
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        val uri = data?.data ?: return
        if (res != RESULT_OK) return
        if (rc == 1) Thread {
            try {
                contentResolver.openOutputStream(uri)!!.use { o ->
                    ZipOutputStream(o).use { z ->
                        z.putNextEntry(ZipEntry("history.json")); z.write(db.toJson().toByteArray()); z.closeEntry()
                        db.coverDir.listFiles()?.forEach { f ->
                            z.putNextEntry(ZipEntry("covers/" + f.name)); f.inputStream().use { it.copyTo(z) }; z.closeEntry()
                        }
                    }
                }
                toast("Бэкап сохранён")
            } catch (e: Exception) { toast("Ошибка: ${e.message}") }
        }.start()
        if (rc == 2) Thread {
            try {
                var json: String? = null
                ZipInputStream(contentResolver.openInputStream(uri)!!).use { z ->
                    var e = z.nextEntry
                    while (e != null) {
                        val n = e.name
                        if (n == "history.json") json = z.readBytes().toString(Charsets.UTF_8)
                        else if (n.startsWith("covers/") && !e.isDirectory)
                            File(db.coverDir, File(n).name).outputStream().use { z.copyTo(it) }
                        e = z.nextEntry
                    }
                }
                if (json == null) throw Exception("в архиве нет history.json")
                db.restore(json!!)
                cache.evictAll()
                toast("История восстановлена")
            } catch (e: Exception) { toast("Ошибка: ${e.message}") }
        }.start()
    }
}
