package com.example.aimphistory

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.text.TextUtils
import android.util.LruCache
import android.view.*
import android.widget.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.zip.*

class P(val n: String, val bg: Int, val card: Int, val tx: Int, val sub: Int, val ac: Int, val light: Boolean = false)

val PALS = listOf(
    P("Тёмная", 0xFF121212.toInt(), 0xFF1E1E1E.toInt(), 0xFFFFFFFF.toInt(), 0xFFA0A0A0.toInt(), 0xFF4FC3F7.toInt()),
    P("AMOLED", 0xFF000000.toInt(), 0xFF111111.toInt(), 0xFFFFFFFF.toInt(), 0xFF909090.toInt(), 0xFFBB86FC.toInt()),
    P("Светлая", 0xFFF2F2F7.toInt(), 0xFFFFFFFF.toInt(), 0xFF111111.toInt(), 0xFF6B6B6B.toInt(), 0xFF1976D2.toInt(), true),
    P("Синяя ночь", 0xFF0D1B2A.toInt(), 0xFF1B2B40.toInt(), 0xFFE0E1DD.toInt(), 0xFF8FA3B8.toInt(), 0xFF48CAE4.toInt()),
    P("Лесная", 0xFF10201A.toInt(), 0xFF1B3028.toInt(), 0xFFE6F2EA.toInt(), 0xFF8DB09B.toInt(), 0xFF66BB6A.toInt()),
    P("Закат", 0xFF2A1520.toInt(), 0xFF3B1F2E.toInt(), 0xFFFFE9EE.toInt(), 0xFFC99AAA.toInt(), 0xFFFF7A59.toInt())
)

val TAGN = mapOf(
    "TITLE" to "Название", "ARTIST" to "Артист", "ALBUM" to "Альбом", "ALBUM_ARTIST" to "Исполнитель альбома",
    "AUTHOR" to "Автор", "WRITER" to "Автор текста", "COMPOSER" to "Композитор", "COMPILATION" to "Компиляция",
    "GENRE" to "Жанр", "YEAR" to "Год", "DATE" to "Дата", "TRACK_NUMBER" to "Номер трека",
    "NUM_TRACKS" to "Треков в альбоме", "DISC_NUMBER" to "Диск"
)

class MainActivity : Activity() {
    private lateinit var db: Db
    private lateinit var pr: SharedPreferences
    private lateinit var p: P
    private var inSettings = false
    private val fmt = SimpleDateFormat("dd.MM.yyyy  HH:mm:ss", Locale.getDefault())
    private val cache = object : LruCache<String, Bitmap>(60) {}

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    override fun onCreate(b: android.os.Bundle?) {
        super.onCreate(b)
        db = Db.get(this)
        pr = getSharedPreferences("p", 0)
        Db.onChange = { if (!inSettings) show() }
    }

    override fun onResume() {
        super.onResume()
        applyTheme()
        if (inSettings) showSettings() else show()
    }

    override fun onBackPressed() { if (inSettings) show() else super.onBackPressed() }

    private fun applyTheme() {
        p = PALS[pr.getInt("theme", 0).coerceIn(0, PALS.lastIndex)]
        window.statusBarColor = p.bg
        window.navigationBarColor = p.bg
        var f = 0
        if (p.light) f = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        window.decorView.systemUiVisibility = f
    }

    private fun tv(t: String, sz: Float, col: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sz; setTextColor(col)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun cardBg(r: Int = 16) = GradientDrawable().apply { setColor(p.card); cornerRadius = dp(r).toFloat() }
    private fun fmtDur(ms: Long): String { val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60) }
    private fun toast(s: String) = runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_LONG).show() }

    private fun enabled() = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        ?.contains(packageName) == true

    private fun load(name: String, max: Int): Bitmap? {
        if (name.isEmpty()) return null
        val f = File(db.coverDir, name)
        if (!f.exists()) return null
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (o.outWidth / (s * 2) >= max && o.outHeight / (s * 2) >= max) s *= 2
        return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
    }

    private fun thumb(name: String): Bitmap? = cache.get(name) ?: load(name, 160)?.also { cache.put(name, it) }

    // ---------- главный экран ----------
    private fun show() {
        inSettings = false
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(p.bg); setPadding(dp(12), dp(4), dp(12), 0)
        }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(8), dp(4), dp(8)) }
        bar.addView(tv("История прослушиваний", 20f, p.tx, true), LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(tv("⚙", 26f, p.ac).apply { setPadding(dp(12), 0, dp(4), 0); setOnClickListener { showSettings() } })
        root.addView(bar)
        if (!enabled()) {
            root.addView(tv("Нужен доступ к уведомлениям — нажми сюда и включи «AIMP История»", 14f, p.tx).apply {
                background = cardBg(); setPadding(dp(14), dp(12), dp(14), dp(12))
                setOnClickListener { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
            }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
        val items = db.all()
        if (items.isEmpty()) {
            root.addView(tv("Пока пусто. Включи музыку в AIMP — трек появится здесь, когда достигнет порога прослушивания.", 15f, p.sub)
                .apply { setPadding(dp(8), dp(24), dp(8), 0) })
        }
        val lv = ListView(this).apply {
            divider = null; dividerHeight = 0; setSelector(ColorDrawable(Color.TRANSPARENT))
            adapter = object : BaseAdapter() {
                override fun getCount() = items.size
                override fun getItem(i: Int) = items[i]
                override fun getItemId(i: Int) = i.toLong()
                override fun getView(i: Int, v: View?, g: ViewGroup?): View {
                    val t = items[i]
                    val wrap = FrameLayout(this@MainActivity).apply { setPadding(0, dp(5), 0, dp(5)) }
                    val row = LinearLayout(this@MainActivity).apply {
                        background = cardBg(); setPadding(dp(10), dp(10), dp(12), dp(10)); gravity = Gravity.CENTER_VERTICAL
                    }
                    val img = ImageView(this@MainActivity).apply {
                        scaleType = ImageView.ScaleType.CENTER_CROP
                        val bm = thumb(t.cover)
                        if (bm != null) setImageBitmap(bm) else setImageDrawable(ColorDrawable(p.bg))
                    }
                    row.addView(img, LinearLayout.LayoutParams(dp(64), dp(64)))
                    val col = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
                    fun line(s: String, sz: Float, c: Int, bold: Boolean = false) = tv(s, sz, c, bold).apply {
                        maxLines = 1; ellipsize = TextUtils.TruncateAt.END
                    }
                    col.addView(line("${t.artist} - ${t.title}", 15f, p.tx, true))
                    if (t.album.isNotEmpty()) col.addView(line(t.album, 13f, p.sub))
                    col.addView(line("${fmtDur(t.dur)}  •  ${fmt.format(Date(t.ts))}", 12f, p.ac))
                    row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
                    wrap.addView(row)
                    return wrap
                }
            }
            setOnItemClickListener { _, _, i, _ -> details(items[i]) }
        }
        root.addView(lv, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    // ---------- карточка трека ----------
    private fun details(t: Track) {
        val sv = ScrollView(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(8)) }
        val bm = load(t.cover, Int.MAX_VALUE)
        if (bm != null) {
            col.addView(ImageView(this).apply {
                adjustViewBounds = true; setImageBitmap(bm); setOnClickListener { zoom(bm) }
            }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(4) })
            col.addView(tv("${bm.width}×${bm.height} • нажми на обложку, чтобы приблизить", 11f, p.sub))
        }
        col.addView(tv("${t.artist} - ${t.title}", 18f, p.tx, true).apply { setPadding(0, dp(12), 0, dp(8)) })
        fun row(l: String, v: String) {
            col.addView(tv(l, 12f, p.sub).apply { setPadding(0, dp(8), 0, 0) })
            col.addView(tv(v, 15f, p.tx).apply { setTextIsSelectable(true) })
        }
        row("Прослушан", fmt.format(Date(t.ts)))
        row("Длительность", fmtDur(t.dur))
        for (k in t.tags.keys()) {
            if (k == "DURATION") continue
            row(TAGN[k] ?: k, t.tags.get(k).toString())
        }
        sv.addView(col)
        val d = AlertDialog.Builder(this).setView(sv).setPositiveButton("Закрыть", null).create()
        d.window?.setBackgroundDrawable(cardBg(20))
        d.show()
        d.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(p.ac)
    }

    private fun zoom(bm: Bitmap) {
        val iv = ImageView(this).apply { setImageBitmap(bm); setBackgroundColor(Color.BLACK) }
        var s = 1f; var tx = 0f; var ty = 0f; var lx = 0f; var ly = 0f
        val sd = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                s = (s * d.scaleFactor).coerceIn(1f, 8f); iv.scaleX = s; iv.scaleY = s; return true
            }
        })
        iv.setOnTouchListener { _, e ->
            sd.onTouchEvent(e)
            if (e.pointerCount > 1 || e.actionMasked == MotionEvent.ACTION_DOWN) { lx = e.rawX; ly = e.rawY }
            else if (!sd.isInProgress && e.actionMasked == MotionEvent.ACTION_MOVE) {
                tx += e.rawX - lx; ty += e.rawY - ly; lx = e.rawX; ly = e.rawY
                iv.translationX = tx; iv.translationY = ty
            }
            true
        }
        Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen).apply { setContentView(iv); show() }
    }

    // ---------- настройки ----------
    private fun btn(t: String, a: () -> Unit) = tv(t, 16f, p.tx).apply {
        background = cardBg(); setPadding(dp(16), dp(14), dp(16), dp(14)); setOnClickListener { a() }
    }

    private fun showSettings() {
        inSettings = true
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(24)) }
        fun add(v: View) = col.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        col.addView(tv("‹ Назад", 18f, p.ac).apply { setPadding(0, dp(8), 0, dp(8)); setOnClickListener { show() } })
        col.addView(tv("Настройки", 24f, p.tx, true))

        val th = pr.getInt("th", 60)
        val lbl = tv("Порог прослушивания: $th%", 16f, p.tx)
        add(lbl)
        add(SeekBar(this).apply {
            max = 100; progress = th
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) {
                    lbl.text = "Порог прослушивания: $v%"; pr.edit().putInt("th", v).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        add(tv("С какого процента трек считается прослушанным и попадает в историю (0–100).", 12f, p.sub))

        add(btn("Тема оформления: ${p.n}") {
            AlertDialog.Builder(this).setItems(PALS.map { it.n }.toTypedArray()) { _, i ->
                pr.edit().putInt("theme", i).apply(); applyTheme(); showSettings()
            }.show()
        })
        add(btn("Создать бэкап") {
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "application/zip"
                putExtra(Intent.EXTRA_TITLE, "aimp-history-" + SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date()) + ".zip")
            }, 1)
        })
        add(btn("Восстановить из бэкапа") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            }, 2)
        })
        add(btn("Доступ к уведомлениям") {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        })
        add(btn("Удалить всю историю") {
            AlertDialog.Builder(this).setMessage("Удалить всю историю прослушиваний? Это нельзя отменить.")
                .setPositiveButton("Удалить") { _, _ -> db.clear(); toast("История удалена") }
                .setNegativeButton("Отмена", null).show()
        }.apply { setTextColor(0xFFFF5252.toInt()) })

        val sv = ScrollView(this).apply { setBackgroundColor(p.bg); addView(col) }
        setContentView(sv)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        val uri = data?.data ?: return
        if (res != RESULT_OK) return
        if (rc == 1) Thread {
            try {
                contentResolver.openOutputStream(uri)!!.use { o ->
                    ZipOutputStream(o).use { z ->
                        z.putNextEntry(ZipEntry("history.json")); z.write(db.toJson().toByteArray()); z.closeEntry()
                        db.coverDir.listFiles()?.forEach { f ->
                            z.putNextEntry(ZipEntry("covers/" + f.name)); f.inputStream().use { it.copyTo(z) }; z.closeEntry()
                        }
                    }
                }
                toast("Бэкап сохранён")
            } catch (e: Exception) { toast("Ошибка: ${e.message}") }
        }.start()
        if (rc == 2) Thread {
            try {
                var json: String? = null
                ZipInputStream(contentResolver.openInputStream(uri)!!).use { z ->
                    var e = z.nextEntry
                    while (e != null) {
                        val n = e.name
                        if (n == "history.json") json = z.readBytes().toString(Charsets.UTF_8)
                        else if (n.startsWith("covers/") && !e.isDirectory)
                            File(db.coverDir, File(n).name).outputStream().use { z.copyTo(it) }
                        e = z.nextEntry
                    }
                }
                if (json == null) throw Exception("в архиве нет history.json")
                db.restore(json!!)
                toast("История восстановлена")
            } catch (e: Exception) { toast("Ошибка: ${e.message}") }
        }.start()
    }
}
