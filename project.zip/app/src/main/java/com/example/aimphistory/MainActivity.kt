package com.example.aimphistory

import android.animation.ValueAnimator
import android.app.Activity
import android.app.Dialog
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.transition.TransitionManager
import android.util.LruCache
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.palette.graphics.Palette
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager.widget.PagerAdapter
import androidx.viewpager.widget.ViewPager
import java.io.File
import java.text.Collator
import java.text.SimpleDateFormat
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.*
import java.util.concurrent.Executors
import java.util.zip.*

class Pg(private val views: List<View>) : PagerAdapter() {
    override fun getCount() = views.size
    override fun isViewFromObject(v: View, o: Any) = v === o
    override fun instantiateItem(c: ViewGroup, i: Int): Any { c.addView(views[i]); return views[i] }
    override fun destroyItem(c: ViewGroup, i: Int, o: Any) { c.removeView(o as View) }
}

fun times(n: Int) = if (n % 10 in 2..4 && n % 100 !in 12..14) "раза" else "раз"
fun daysW(n: Int) = when {
    n % 10 == 1 && n % 100 != 11 -> "день"
    n % 10 in 2..4 && n % 100 !in 12..14 -> "дня"
    else -> "дней"
}

class MainActivity : Activity() {
    private lateinit var db: Db
    private lateinit var pr: SharedPreferences
    private lateinit var p: P
    private lateinit var mainRoot: View
    private lateinit var banner: TextView
    private lateinit var search: EditText
    private lateinit var countTv: TextView
    private lateinit var emptyTv: TextView
    private lateinit var histRv: RecyclerView
    private lateinit var histAd: Hist
    private lateinit var histPage: LinearLayout
    // сейчас играет
    private lateinit var nowCard: FrameLayout
    private lateinit var nowBg: NowBg
    private lateinit var nowImg: ImageView
    private lateinit var nowEq: EqView
    private lateinit var nowStatus: TextView
    private lateinit var nowTitle: TextView
    private lateinit var nowSub: TextView
    private lateinit var nowInfo: TextView
    private lateinit var nowProg: Prog
    private var nowKey = ""
    private var lastCover: Bitmap? = null
    // статистика
    private lateinit var stTime: TextView
    private lateinit var stTracks: TextView
    private lateinit var stArtists: TextView
    private lateinit var wkTitle: TextView
    private lateinit var wkSub: TextView
    private lateinit var wkTotal: TextView
    private lateinit var wkRight: TextView
    private lateinit var wkChart: WeekChart
    private lateinit var dayDonut: DayDonut
    private lateinit var dayLegend: LinearLayout
    private lateinit var dayInsight: TextView
    private lateinit var genBox: LinearLayout
    private lateinit var topBox: LinearLayout
    private lateinit var stkCard: FireCard
    private lateinit var stkNum: TextView
    private lateinit var stkUnit: TextView
    private lateinit var stkFlame: FlameView
    private lateinit var stkDots: LinearLayout
    private lateinit var stkBest: TextView
    private lateinit var stkHint: TextView
    private lateinit var sumTitle: TextView
    private lateinit var sumHours: TextView
    private lateinit var sumDelta: TextView
    private lateinit var sumFacts: LinearLayout
    private lateinit var sumBody: LinearLayout
    private lateinit var sumRight: TextView
    private lateinit var sumM: TextView
    private lateinit var sumY: TextView
    // календарь
    private lateinit var calGrid: CalView
    private lateinit var calTitle: TextView
    private lateinit var calSub: TextView
    private lateinit var calRight: TextView
    private lateinit var calDayTitle: TextView
    private lateinit var calDayBox: LinearLayout
    private val statCards = ArrayList<View>()
    private val calCards = ArrayList<View>()
    private var statsPlayed = false
    private var calPlayed = false

    private var all: List<Track> = emptyList()
    private var agg: List<Row> = emptyList()
    private var counts: Map<String, Int> = HashMap()
    private var inSettings = false
    private var sortIdx = 0
    private var weekOffset = 0
    private var calOffset = 0
    private var calSel = -1
    private var sumYear = false
    private var sumOff = 0
    private var streakVal = 0
    private val selSet = HashSet<Long>()
    private lateinit var selBar: LinearLayout
    private lateinit var searchRow: LinearLayout
    private lateinit var selCount: TextView

    private val fmt = SimpleDateFormat("dd.MM.yyyy  HH:mm:ss", Locale.getDefault())
    private val pool = Executors.newFixedThreadPool(2)
    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 8 / 1024).toInt()) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount / 1024
    }
    private val sortNames = arrayOf(
        "Сначала новые", "Сначала старые", "Артист: А → Я", "Артист: Я → А",
        "Название: А → Я", "Название: Я → А", "Альбом: А → Я", "Альбом: Я → А", "Топ по прослушиваниям"
    )
    private val sortIcons = arrayOf("🆕", "⏳", "🎤", "🎤", "🎵", "🎵", "💿", "💿", "🏆")

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun lp(w: Int, h: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt)
    private fun keyOf(t: Track) = (t.artist.trim() + "|" + t.title.trim()).lowercase()

    override fun onCreate(b: android.os.Bundle?) {
        super.onCreate(b)
        db = Db.get(this)
        pr = getSharedPreferences("p", 0)
        sortIdx = pr.getInt("sort", 0).coerceIn(0, sortNames.size - 1)
        Db.onChange = { reload() }
        Now.onChange = { updateNow() }
        applyTheme()
        buildMain()
        setContentView(mainRoot)
        if (Build.VERSION.SDK_INT >= 33 && !pr.getBoolean("askedNotif", false) &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            pr.edit().putBoolean("askedNotif", true).apply()
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 9)
        }
    }

    override fun onResume() {
        super.onResume()
        banner.visibility = if (enabled()) View.GONE else View.VISIBLE
        Keep.ensure(this)
        reload()
        updateNow()
        val b = Build.MANUFACTURER.lowercase() + Build.BRAND.lowercase()
        if (!pr.getBoolean("bgHelp", false) && (b.contains("xiaomi") || b.contains("redmi") || b.contains("poco"))) {
            pr.edit().putBoolean("bgHelp", true).apply()
            mainRoot.post { showBgHelp() }
        }
    }

    private fun openAppInfo() {
        try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) } catch (e: Exception) { }
    }

    private fun openAutostart() {
        val tries = listOf(
            Intent().setComponent(ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")),
            Intent().setComponent(ComponentName("com.miui.securitycenter", "com.miui.powerkeeper.ui.HiddenAppsConfigActivity"))
        )
        for (i in tries) { try { startActivity(i); return } catch (e: Exception) { } }
        openAppInfo()
    }

    private fun openBattery() {
        val xiaomi = Intent().setComponent(ComponentName("com.miui.powerkeeper", "com.miui.powerkeeper.ui.HiddenAppsConfigActivity"))
            .putExtra("package_name", packageName).putExtra("package_label", "AIMP История")
        try { startActivity(xiaomi); return } catch (e: Exception) { }
        try { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))); return } catch (e: Exception) { }
        try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (e: Exception) { openAppInfo() }
    }

    private fun showBgHelp() {
        sheet("Чтобы трекер работал всегда") { c, close ->
            c.addView(tv("На Xiaomi система сама выгружает фоновые приложения. Сделай три шага — и отслеживание больше не пропадёт:", 14f, p.sub).apply { setPadding(dp(8), 0, dp(8), dp(12)) })
            c.addView(tv("1. Включи автозапуск для приложения\n2. В настройках батареи выбери «Нет ограничений»\n3. Открой «Недавние», потяни карточку приложения вниз и нажми замок 🔒", 14f, p.tx).apply { setPadding(dp(8), 0, dp(8), dp(16)) })
            c.addView(sheetBtn("Автозапуск", withA(p.ac, 0x30), p.ac) { openAutostart() }, lp(-1, -2).apply { bottomMargin = dp(8) })
            c.addView(sheetBtn("Батарея: без ограничений", withA(p.ac, 0x30), p.ac) { openBattery() }, lp(-1, -2).apply { bottomMargin = dp(8) })
            c.addView(sheetBtn("Готово", p.ac, contrast()) { close() }, lp(-1, -2))
        }
    }

    override fun onDestroy() { Db.onChange = null; Now.onChange = null; super.onDestroy() }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (inSettings) closeSettings()
        else if (selSet.isNotEmpty()) clearSel()
        else super.onBackPressed()
    }

    private fun updateSelBar() {
        if (!::selBar.isInitialized) return
        val show = selSet.isNotEmpty()
        selCount.text = "Выбрано: ${selSet.size}"
        if (show == (selBar.visibility == View.VISIBLE)) return
        selBar.animate().cancel(); searchRow.animate().cancel()
        if (show) {
            selBar.alpha = 0f; selBar.visibility = View.VISIBLE
            selBar.animate().alpha(1f).setDuration(200).setInterpolator(EASE).start()
            searchRow.animate().alpha(0f).setDuration(160).withEndAction { searchRow.visibility = View.INVISIBLE }.start()
        } else {
            searchRow.visibility = View.VISIBLE
            searchRow.animate().alpha(1f).setDuration(200).setInterpolator(EASE).start()
            selBar.animate().alpha(0f).setDuration(160).withEndAction { selBar.visibility = View.GONE }.start()
        }
    }

    private fun toggleSel(ts: Long) {
        if (!selSet.add(ts)) selSet.remove(ts)
        val i = histAd.items.indexOfFirst { it.t.ts == ts }
        if (i >= 0) histAd.notifyItemChanged(i) else histAd.notifyDataSetChanged()
        updateSelBar()
    }

    private fun clearSel() { selSet.clear(); histAd.notifyDataSetChanged(); updateSelBar() }

    private fun confirmDeleteSel() {
        val n = selSet.size
        sheet("Удалить выбранное?") { c, close ->
            c.addView(tv("Из истории будет удалено: $n. Это нельзя отменить.", 14f, p.sub).apply { setPadding(dp(8), 0, dp(8), dp(16)) })
            val r = LinearLayout(this)
            r.addView(sheetBtn("Отмена", withA(p.tx, 0x18), p.tx) { close() }, lp(0, -2, 1f).apply { rightMargin = dp(6) })
            r.addView(sheetBtn("Удалить", 0xFFE53935.toInt(), 0xFFFFFFFF.toInt()) {
                val list = selSet.toList(); selSet.clear(); updateSelBar()
                db.deleteByTs(list); close()
            }, lp(0, -2, 1f).apply { leftMargin = dp(6) })
            c.addView(r)
        }
    }

    // ---------- оформление ----------
    private fun applyTheme() {
        p = PALS[pr.getInt("theme", 0).coerceIn(0, PALS.lastIndex)]
        window.statusBarColor = p.bg
        window.navigationBarColor = p.bg2
        var f = 0
        if (p.light) f = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        window.decorView.systemUiVisibility = f
    }

    private fun bgDrawable() = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(p.bg, p.bg2))

    private fun tv(t: String, sz: Float, col: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sz; setTextColor(col)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    private fun cardBg(r: Int = p.rad) = GradientDrawable().apply {
        setColor(p.card); cornerRadius = dp(r).toFloat()
        if (p.stroke != 0) setStroke(dp(1), p.stroke)
    }

    private fun contrast() = if (p.light) 0xFFFFFFFF.toInt() else 0xFF101010.toInt()
    private fun fmtDur(ms: Long): String { val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60) }
    private fun hm(ms: Long) = "${ms / 3600000} ч ${ms / 60000 % 60} мин"
    private fun toast(s: String) = runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_LONG).show() }
    private fun enabled() = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        ?.contains(packageName) == true

    private fun hideKb() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(search.windowToken, 0)
        search.clearFocus()
    }

    private fun round(v: View, r: Int) {
        v.clipToOutline = true
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, o: Outline) { o.setRoundRect(0, 0, view.width, view.height, dp(r).toFloat()) }
        }
    }

    private fun pressFx(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> view.animate().scaleX(0.96f).scaleY(0.96f).setDuration(110).setInterpolator(EASE).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.animate().scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(EASE).start()
            }
            false
        }
    }

    private fun enter(v: View, dir: Int) {
        v.alpha = 0f; v.translationX = dp(36) * dir.toFloat()
        v.animate().alpha(1f).translationX(0f).setDuration(300).setInterpolator(EASE).start()
    }

    private fun cascade(vs: List<View>, step: Long = 70L) {
        vs.forEachIndexed { i, v ->
            v.animate().cancel()
            v.alpha = 0f; v.translationY = dp(26).toFloat(); v.scaleX = 0.97f; v.scaleY = 0.97f
            v.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
                .setStartDelay(i * step).setDuration(450).setInterpolator(EASE).start()
        }
    }

    private fun countUp(t: TextView, target: Long, f: (Long) -> String) {
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 900; interpolator = DecelerateInterpolator()
            addUpdateListener { t.text = f((target * (it.animatedValue as Float)).toLong()) }
            start()
        }
    }

    // ---------- нижние панели (вместо стандартных диалогов) ----------
    private fun sheet(title: String?, build: (LinearLayout, () -> Unit) -> Unit) {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val root = FrameLayout(this)
        val rr = dp(28).toFloat()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(mix(over(p.card, p.bg2), p.ac, 0.06f))
                cornerRadii = floatArrayOf(rr, rr, rr, rr, 0f, 0f, 0f, 0f)
                if (p.stroke != 0) setStroke(dp(1), p.stroke)
            }
            alpha = 0f
        }
        fun close() {
            box.animate().translationY(box.height.toFloat()).setDuration(230).setInterpolator(EASE)
                .withEndAction { d.dismiss() }.start()
        }
        val handle = FrameLayout(this)
        handle.addView(View(this).apply {
            background = GradientDrawable().apply { setColor(withA(p.sub, 0x66)); cornerRadius = dp(3).toFloat() }
        }, FrameLayout.LayoutParams(dp(40), dp(5), Gravity.CENTER))
        var y0 = 0f
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> y0 = e.rawY
                MotionEvent.ACTION_MOVE -> box.translationY = maxOf(0f, e.rawY - y0)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    if (box.translationY > dp(100)) close()
                    else box.animate().translationY(0f).setDuration(220).setInterpolator(EASE).start()
            }
            true
        }
        box.addView(handle, lp(-1, dp(26)))
        if (title != null) box.addView(tv(title, 19f, p.tx, true).apply { setPadding(dp(22), dp(2), dp(22), dp(10)) })
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, dp(14), dp(20)) }
        val sv = object : ScrollView(this) {
            override fun onMeasure(w: Int, h: Int) {
                super.onMeasure(w, View.MeasureSpec.makeMeasureSpec((resources.displayMetrics.heightPixels * 0.72f).toInt(), View.MeasureSpec.AT_MOST))
            }
        }
        sv.addView(content)
        box.addView(sv, lp(-1, -2))
        root.addView(box, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        root.setOnClickListener { close() }
        box.setOnClickListener { }
        build(content) { close() }
        d.setContentView(root)
        d.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(-1, -1); setDimAmount(0.55f); setGravity(Gravity.BOTTOM)
        }
        d.setOnShowListener {
            box.post {
                box.translationY = box.height.toFloat(); box.alpha = 1f
                box.animate().translationY(0f).setDuration(360).setInterpolator(EASE).start()
            }
        }
        d.show()
    }

    private fun sheetItem(parent: LinearLayout, icon: String, text: String, selected: Boolean, onClick: () -> Unit) {
        val r = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(13), dp(14), dp(13))
            background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(if (selected) withA(p.ac, 0x26) else 0) }
            setOnClickListener { onClick() }
        }
        r.addView(tv(icon, 20f, p.tx), lp(dp(36), -2))
        r.addView(tv(text, 16f, if (selected) p.ac else p.tx, selected), lp(0, -2, 1f))
        if (selected) r.addView(tv("✓", 18f, p.ac, true))
        pressFx(r)
        parent.addView(r, lp(-1, -2).apply { topMargin = dp(2) })
    }

    private fun sheetBtn(text: String, filled: Int, textCol: Int, onClick: () -> Unit) = tv(text, 16f, textCol, true).apply {
        gravity = Gravity.CENTER; setPadding(dp(16), dp(14), dp(16), dp(14))
        background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(filled) }
        setOnClickListener { onClick() }; pressFx(this)
    }

    // ---------- картинки ----------
    private fun load(name: String, minSide: Int): Bitmap? {
        if (name.isEmpty()) return null
        val f = File(db.coverDir, name)
        if (!f.exists()) return null
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (o.outWidth / (s * 2) >= minSide && o.outHeight / (s * 2) >= minSide) s *= 2
        return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
    }

    private fun loadCap(name: String, cap: Int): Bitmap? {
        if (name.isEmpty()) return null
        val f = File(db.coverDir, name)
        if (!f.exists()) return null
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (maxOf(o.outWidth, o.outHeight) / s > cap) s *= 2
        return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
    }

    private fun bindCover(img: ImageView, name: String) {
        img.tag = name
        val c = if (name.isEmpty()) null else cache.get(name)
        if (c != null) { img.setImageBitmap(c); return }
        img.setImageDrawable(ColorDrawable(withA(p.tx, 0x14)))
        if (name.isEmpty()) return
        pool.execute {
            val bm = load(name, 192)
            if (bm != null) {
                cache.put(name, bm)
                runOnUiThread { if (img.tag == name) img.setImageBitmap(bm) }
            }
        }
    }

    // ---------- данные ----------
    private fun reload() {
        Thread {
            val l = db.all()
            val reps = LinkedHashMap<String, Track>()
            val cnt = HashMap<String, Int>()
            for (t in l) { val k = keyOf(t); if (!reps.containsKey(k)) reps[k] = t; cnt[k] = (cnt[k] ?: 0) + 1 }
            val sorted = reps.entries.map { Row(it.value, cnt[it.key] ?: 1, 0) }.sortedByDescending { it.plays }
            val ag = sorted.mapIndexed { i, r -> Row(r.t, r.plays, i + 1) }
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                val first = all.isEmpty()
                all = l; agg = ag; counts = cnt
                if (first) histAd.lastAnim = -1
                refreshUi()
            }
        }.start()
    }

    private fun refreshUi() { applyFilter(false); updateStats(); updateCalendar(false); updateNow() }

    // ---------- каркас: вкладки + страницы ----------
    private fun buildMain() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = bgDrawable() }
        val titles = listOf("История", "Статистика", "Календарь")
        val tvs = titles.map { tv(it, 16f, p.sub, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(14), 0, dp(14)) } }
        val tabs = LinearLayout(this)
        for (t in tvs) tabs.addView(t, lp(0, -2, 1f))
        val ind = View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(p.ac, p.ac2)).apply { cornerRadius = dp(2).toFloat() }
        }
        val tabWrap = FrameLayout(this)
        tabWrap.addView(tabs, FrameLayout.LayoutParams(-1, -2))
        tabWrap.addView(ind, FrameLayout.LayoutParams(dp(60), dp(3), Gravity.BOTTOM))
        val n = tvs.size
        fun upd(pos2: Float, off: Float) {
            val tw = tabWrap.width
            if (tw == 0) return
            ind.translationX = pos2 * tw / n
            ind.pivotX = ind.width / 2f
            ind.scaleX = 1f + 0.45f * Math.sin(Math.PI * off).toFloat()
            for (i in tvs.indices) {
                val f = (1f - Math.abs(pos2 - i)).coerceIn(0f, 1f)
                tvs[i].setTextColor(mix(p.sub, p.ac, f))
                val s = 0.94f + 0.06f * f
                tvs[i].scaleX = s; tvs[i].scaleY = s
            }
        }
        tabWrap.post {
            val w = tabWrap.width / n - dp(40)
            ind.layoutParams = FrameLayout.LayoutParams(w, dp(3), Gravity.BOTTOM).apply { leftMargin = dp(20) }
            upd(0f, 0f)
        }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(4), dp(4), 0) }
        bar.addView(tabWrap, lp(0, -2, 1f))
        bar.addView(tv("⚙", 24f, p.ac).apply {
            setPadding(dp(14), dp(8), dp(14), dp(8)); setOnClickListener { showSettings() }; pressFx(this)
        })
        root.addView(bar)

        banner = tv("Нужен доступ к уведомлениям — нажми сюда и включи «AIMP История»", 14f, p.tx).apply {
            background = cardBg(); setPadding(dp(14), dp(12), dp(14), dp(12))
            setOnClickListener { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
        }
        root.addView(banner, lp(-1, -2).apply { setMargins(dp(12), dp(8), dp(12), 0) })

        statsPlayed = false; calPlayed = false
        val pager = ViewPager(this)
        pager.adapter = Pg(listOf(buildHistory(), buildStats(), buildCalendar()))
        pager.offscreenPageLimit = 2
        pager.setPageTransformer(false) { page, pos ->
            val a = Math.abs(pos)
            page.alpha = 1f - a * 0.55f
            val s = 0.90f + 0.10f * (1f - a)
            page.scaleX = s; page.scaleY = s
            page.translationX = -pos * page.width * 0.08f
        }
        pager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(pos: Int, off: Float, px: Int) {
                upd(pos + off, off)
                if (pos == 0 && off > 0.05f && !statsPlayed) { statsPlayed = true; playStatsIn() }
                if (pos == 1 && off > 0.05f && !calPlayed) { calPlayed = true; cascade(calCards, 90L) }
            }
            override fun onPageSelected(pos: Int) {
                hideKb()
                if (pos == 0) {
                    statsPlayed = false; calPlayed = false
                    for (c in statCards) c.alpha = 0f
                    for (c in calCards) c.alpha = 0f
                } else if (pos == 1 && !statsPlayed) { statsPlayed = true; playStatsIn() }
                else if (pos == 2 && !calPlayed) { calPlayed = true; cascade(calCards, 90L) }
            }
            override fun onPageScrollStateChanged(s: Int) {}
        })
        tvs.forEachIndexed { i, t -> t.setOnClickListener { pager.setCurrentItem(i, true) } }
        root.addView(pager, lp(-1, 0, 1f))
        mainRoot = root
        refreshUi()
    }

    // ---------- История ----------
    private fun comparator(i: Int): Comparator<Track> {
        val c = Collator.getInstance()
        return when (i) {
            1 -> Comparator { a, b -> a.ts.compareTo(b.ts) }
            2 -> Comparator { a, b -> c.compare(a.artist, b.artist) }
            3 -> Comparator { a, b -> c.compare(b.artist, a.artist) }
            4 -> Comparator { a, b -> c.compare(a.title, b.title) }
            5 -> Comparator { a, b -> c.compare(b.title, a.title) }
            6 -> Comparator { a, b -> c.compare(a.album, b.album) }
            7 -> Comparator { a, b -> c.compare(b.album, a.album) }
            else -> Comparator { a, b -> b.ts.compareTo(a.ts) }
        }
    }

    private fun applyFilter(toTop: Boolean) {
        val q = search.text.toString().trim().lowercase()
        val parts = q.split(' ').filter { it.isNotEmpty() }
        val rows: List<Row>
        if (sortIdx == 8) {
            rows = if (parts.isEmpty()) agg else agg.filter { r -> parts.all { r.t.search.contains(it) } }
        } else {
            var l: List<Track> = all
            if (parts.isNotEmpty()) l = l.filter { t -> parts.all { t.search.contains(it) } }
            rows = l.sortedWith(comparator(sortIdx)).map { Row(it, 0, 0) }
        }
        histAd.items = rows
        histAd.notifyDataSetChanged()
        if (toTop) histRv.scrollToPosition(0)
        val what = if (sortIdx == 8) "уникальных треков" else if (q.isNotEmpty()) "найдено" else "треков"
        countTv.text = "${rows.size} $what  •  ${sortNames[sortIdx]}"
        emptyTv.text = if (all.isEmpty())
            "Пока пусто. Включи музыку в AIMP — трек появится здесь, когда достигнет порога прослушивания."
        else "Ничего не найдено"
        emptyTv.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun styleBadge(b: TextView, rank: Int) {
        val m = metalOf(rank)
        b.text = rank.toString()
        b.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(if (m != 0) m else withA(p.tx, 0x18)) }
        b.setTextColor(if (m != 0) 0xFF1A1A1A.toInt() else p.sub)
    }

    inner class Hist(private val allowSel: Boolean = true) : RecyclerView.Adapter<VH>() {
        var items: List<Row> = emptyList()
        var lastAnim = -1
        override fun getItemCount() = items.size
        override fun onCreateViewHolder(g: ViewGroup, v: Int): VH {
            val wrap = FrameLayout(this@MainActivity).apply {
                setPadding(0, dp(5), 0, dp(5)); layoutParams = RecyclerView.LayoutParams(-1, -2)
            }
            val row = ShimmerCard(this@MainActivity, p.card, dp(p.rad).toFloat(), p.ac).apply {
                setPadding(dp(10), dp(10), dp(12), dp(10)); gravity = Gravity.CENTER_VERTICAL
            }
            val badge = tv("", 13f, p.sub, true).apply { gravity = Gravity.CENTER; visibility = View.GONE }
            row.addView(badge, lp(dp(28), dp(28)).apply { rightMargin = dp(8) })
            val img = ImageView(this@MainActivity).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
            round(img, 12)
            row.addView(img, lp(dp(64), dp(64)))
            val col = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
            fun line(sz: Float, c: Int, bold: Boolean) = tv("", sz, c, bold).apply {
                maxLines = 1; ellipsize = TextUtils.TruncateAt.END
            }
            val t = line(15f, p.tx, true); val a = line(13f, p.sub, false); val i = line(12f, p.ac, false)
            col.addView(t); col.addView(a); col.addView(i)
            row.addView(col, lp(0, -2, 1f))
            wrap.addView(row)
            pressFx(wrap)
            val h = VH(img, t, a, i, badge, row, wrap)
            wrap.setOnClickListener {
                val pos = h.bindingAdapterPosition
                if (pos >= 0) {
                    hideKb()
                    if (allowSel && selSet.isNotEmpty() && sortIdx != 8) toggleSel(items[pos].t.ts) else details(items[pos].t)
                }
            }
            wrap.setOnLongClickListener {
                val pos = h.bindingAdapterPosition
                if (allowSel && pos >= 0 && sortIdx != 8) { hideKb(); toggleSel(items[pos].t.ts); true } else false
            }
            return h
        }
        override fun onBindViewHolder(h: VH, pos: Int) {
            val r = items[pos]; val t = r.t
            h.t.text = "${t.artist} - ${t.title}"
            h.a.text = t.album
            h.a.visibility = if (t.album.isEmpty()) View.GONE else View.VISIBLE
            if (r.plays > 0) {
                h.i.text = "${fmtDur(t.dur)}  •  ${r.plays} ${times(r.plays)}  •  ${fmt.format(Date(t.ts))}"
                h.b.visibility = View.VISIBLE; styleBadge(h.b, r.rank)
                h.card.setMetal(metalOf(r.rank))
            } else {
                h.i.text = "${fmtDur(t.dur)}  •  ${fmt.format(Date(t.ts))}"
                h.b.visibility = View.GONE
                h.card.setMetal(0)
            }
            bindCover(h.img, t.cover)
            h.card.setSel(r.plays == 0 && selSet.contains(t.ts))
            val v = h.itemView
            v.animate().cancel()
            if (pos > lastAnim) {
                lastAnim = pos
                v.alpha = 0f; v.translationY = dp(24).toFloat(); v.scaleX = 0.97f; v.scaleY = 0.97f
                v.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
                    .setDuration(420).setStartDelay(minOf(pos, 6) * 50L).setInterpolator(EASE).start()
            } else { v.alpha = 1f; v.translationY = 0f; v.scaleX = 1f; v.scaleY = 1f }
        }
    }

    // ---------- «сейчас играет» ----------
    private fun buildNow(): View {
        nowBg = NowBg(this, p)
        nowImg = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        round(nowImg, 14)
        nowEq = EqView(this, p.ac)
        nowStatus = tv("", 11f, p.ac, true)
        val sr = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        sr.addView(nowEq, lp(dp(16), dp(14)).apply { rightMargin = dp(8) })
        sr.addView(nowStatus)
        fun line(sz: Float, c: Int, bold: Boolean) = tv("", sz, c, bold).apply {
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        }
        nowTitle = line(15f, p.tx, true); nowSub = line(13f, p.sub, false); nowInfo = line(12f, p.sub, false)
        nowProg = Prog(this, p)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, 0, 0) }
        col.addView(sr); col.addView(nowTitle); col.addView(nowSub); col.addView(nowInfo)
        col.addView(nowProg, lp(-1, dp(4)).apply { topMargin = dp(8) })
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(14), dp(16), dp(14)) }
        row.addView(nowImg, lp(dp(68), dp(68)))
        row.addView(col, lp(0, -2, 1f))
        nowCard = FrameLayout(this).apply { visibility = View.GONE }
        nowCard.addView(nowBg, FrameLayout.LayoutParams(-1, -1))
        nowCard.addView(row, FrameLayout.LayoutParams(-1, -2))
        nowCard.setOnClickListener { openNow() }
        pressFx(nowCard)
        nowKey = ""; lastCover = null
        return nowCard
    }

    private fun applyNowCover(bm: Bitmap) {
        nowImg.setImageBitmap(bm)
        nowBg.setCover(bm)
        Palette.from(bm).maximumColorCount(10).generate { pal ->
            val c = pal?.getVibrantColor(pal.getDominantColor(p.ac)) ?: p.ac
            nowBg.tint(c)
        }
    }

    private fun updateNow() {
        if (!::nowCard.isInitialized || !::histPage.isInitialized) return
        val show = Now.active
        if (show != (nowCard.visibility == View.VISIBLE)) {
            TransitionManager.beginDelayedTransition(histPage)
            nowCard.visibility = if (show) View.VISIBLE else View.GONE
        }
        if (!show) return
        val changed = Now.key != nowKey
        if (changed) {
            nowKey = Now.key
            nowTitle.text = "${Now.artist} - ${Now.title}"
            nowSub.text = Now.album
            nowSub.visibility = if (Now.album.isEmpty()) View.GONE else View.VISIBLE
            nowBg.clear(); lastCover = null
            nowImg.setImageDrawable(ColorDrawable(withA(p.tx, 0x14)))
            val key = Now.key
            val fc = db.coverDir.listFiles { f -> f.name.startsWith(Now.coverBase + ".") }?.firstOrNull()?.name ?: ""
            if (fc.isNotEmpty() && Now.cover == null) {
                pool.execute {
                    val bm = load(fc, 192)
                    if (bm != null) runOnUiThread { if (nowKey == key && lastCover == null) applyNowCover(bm) }
                }
            }
        }
        val cv = Now.cover
        if (cv != null && cv !== lastCover) { lastCover = cv; applyNowCover(cv) }
        nowEq.setPlaying(Now.playing)
        nowStatus.text = if (Now.playing) "СЕЙЧАС ИГРАЕТ" else "НА ПАУЗЕ"
        nowInfo.text = "${fmtDur(Now.pos)} / ${fmtDur(Now.dur)}"
        nowProg.to(if (Now.dur > 0) Now.pos.toFloat() / Now.dur else 0f, changed)
    }

    private fun openNow() {
        if (!Now.active) return
        val fc = db.coverDir.listFiles { f -> f.name.startsWith(Now.coverBase + ".") }?.firstOrNull()?.name ?: ""
        val t = Track(System.currentTimeMillis(), Now.artist, Now.title, Now.album, Now.dur, fc, Now.tags)
        Thread {
            val bm = Now.cover ?: loadCap(fc, 2048)
            runOnUiThread { showDetails(t, bm, true) }
        }.start()
    }

    private fun buildHistory(): View {
        histPage = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), 0) }
        histPage.addView(buildNow(), lp(-1, -2).apply { bottomMargin = dp(10) })
        selBar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; background = cardBg(); setPadding(dp(16), dp(6), dp(6), dp(6))
            visibility = View.GONE
        }
        selCount = tv("", 15f, p.tx, true)
        selBar.addView(selCount, lp(0, -2, 1f))
        fun act(t: String, col: Int, a: () -> Unit) = tv(t, 14f, col, true).apply {
            setPadding(dp(12), dp(10), dp(12), dp(10)); setOnClickListener { a() }; pressFx(this)
        }
        selBar.addView(act("Все", p.ac) { selSet.addAll(histAd.items.map { it.t.ts }); histAd.notifyDataSetChanged(); updateSelBar() })
        selBar.addView(act("Отмена", p.sub) { clearSel() })
        selBar.addView(act("Удалить", 0xFFFF5252.toInt()) { confirmDeleteSel() })
        val sr = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        search = EditText(this).apply {
            hint = "Поиск: артист, трек, альбом, жанр…"
            setHintTextColor(p.sub); setTextColor(p.tx); textSize = 15f
            setSingleLine(true); imeOptions = EditorInfo.IME_ACTION_SEARCH
            background = cardBg(24); setPadding(dp(18), dp(10), dp(18), dp(10))
            if (Build.VERSION.SDK_INT >= 29) {
                textCursorDrawable = GradientDrawable().apply { setColor(p.ac); setSize(dp(2), dp(20)) }
            }
            setOnEditorActionListener { _, _, _ -> hideKb(); true }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { applyFilter(true) }
            })
        }
        sr.addView(search, lp(0, dp(48), 1f))
        sr.addView(tv("⇅", 22f, p.ac).apply {
            background = cardBg(24); gravity = Gravity.CENTER; setOnClickListener { pickSort() }; pressFx(this)
        }, lp(dp(48), dp(48)).apply { leftMargin = dp(8) })
        searchRow = sr
        val topFrame = FrameLayout(this)
        topFrame.addView(sr, FrameLayout.LayoutParams(-1, -2))
        topFrame.addView(selBar, FrameLayout.LayoutParams(-1, dp(48)))
        histPage.addView(topFrame)
        countTv = tv("", 12f, p.sub).apply { setPadding(dp(6), dp(8), 0, dp(4)) }
        histPage.addView(countTv)
        histAd = Hist()
        histRv = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(context)
            adapter = histAd
            edgeEffectFactory = Bounce()
            clipToPadding = false; setPadding(0, 0, 0, dp(16))
            overScrollMode = View.OVER_SCROLL_ALWAYS
            setHasFixedSize(true)
        }
        emptyTv = tv("", 15f, p.sub).apply { gravity = Gravity.CENTER; setPadding(dp(24), dp(40), dp(24), 0) }
        val fl = FrameLayout(this)
        fl.addView(histRv, FrameLayout.LayoutParams(-1, -1))
        fl.addView(emptyTv, FrameLayout.LayoutParams(-1, -2))
        histPage.addView(fl, lp(-1, 0, 1f))
        return histPage
    }

    private fun pickSort() {
        hideKb()
        sheet("Сортировка") { c, close ->
            for (i in sortNames.indices) sheetItem(c, sortIcons[i], sortNames[i], i == sortIdx) {
                sortIdx = i; pr.edit().putInt("sort", i).apply()
                histAd.lastAnim = -1
                applyFilter(true); close()
            }
        }
    }

    // ---------- карточка трека ----------
    private fun details(t: Track) {
        Thread {
            val bm = loadCap(t.cover, 2048)
            runOnUiThread { showDetails(t, bm, false) }
        }.start()
    }

    private fun showDetails(t: Track, bm: Bitmap?, live: Boolean) {
        sheet(null) { col, _ ->
            col.setPadding(dp(20), 0, dp(20), dp(24))
            if (bm != null) {
                col.addView(ImageView(this).apply {
                    adjustViewBounds = true; setImageBitmap(bm)
                    round(this, 20)
                    setOnClickListener { zoom(t.cover, bm) }
                }, lp(-1, -2).apply { bottomMargin = dp(6) })
                col.addView(tv("нажми на обложку, чтобы рассмотреть", 11f, p.sub).apply { gravity = Gravity.CENTER })
            }
            col.addView(tv("${t.artist} - ${t.title}", 20f, p.tx, true).apply { setPadding(0, dp(14), 0, dp(6)) })
            fun row(l: String, v: String) {
                col.addView(View(this).apply { setBackgroundColor(withA(p.tx, 0x14)) }, lp(-1, dp(1)).apply { topMargin = dp(10) })
                col.addView(tv(l, 12f, p.sub).apply { setPadding(0, dp(8), 0, 0) })
                col.addView(tv(v, 15f, p.tx).apply { setTextIsSelectable(true) })
            }
            if (live) row("Статус", if (Now.playing) "Сейчас играет" else "На паузе")
            else row("Прослушан", fmt.format(Date(t.ts)))
            val n = counts[keyOf(t)] ?: 0
            row("Всего прослушиваний", if (n > 0) "$n ${times(n)}" else "ещё не записан")
            row("Длительность", fmtDur(t.dur))
            for (k in t.tags.keys()) {
                if (k == "DURATION" || k in HIDDEN) continue
                row(TAGN[k] ?: k, t.tags.get(k).toString())
            }
        }
    }

    private fun zoom(name: String, small: Bitmap) {
        Thread {
            val big = loadCap(name, 3072) ?: small
            runOnUiThread {
                val z = ZoomView(this)
                z.setBackgroundColor(Color.BLACK)
                z.setImageBitmap(big)
                Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen).apply { setContentView(z); show() }
            }
        }.start()
    }

    // ---------- Статистика ----------
    private fun statCard() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = cardBg(); setPadding(dp(18), dp(16), dp(18), dp(16))
    }

    private fun buildStats(): View {
        statCards.clear()
        val sv = ScrollView(this).apply { overScrollMode = View.OVER_SCROLL_ALWAYS; isVerticalScrollBarEnabled = false }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(2), dp(12), dp(28)); clipChildren = false; clipToPadding = false }
        sv.clipChildren = false; sv.clipToPadding = false
        fun add(v: View) { v.alpha = 0f; statCards.add(v); col.addView(v, lp(-1, -2).apply { topMargin = dp(10) }) }

        // серия
        stkCard = FireCard(this)
        stkCard.translationZ = 2f; stkCard.outlineProvider = null
        val sc = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(18), dp(16)) }
        sc.addView(tv("Серия прослушиваний", 13f, p.sub))
        stkNum = tv("0", 46f, 0xFFFF9800.toInt(), true)
        stkUnit = tv("дней подряд", 15f, p.sub).apply { setPadding(dp(8), 0, 0, dp(8)) }
        val nr = LinearLayout(this).apply { gravity = Gravity.BOTTOM }
        nr.addView(stkNum); nr.addView(stkUnit)
        sc.addView(nr)
        stkDots = LinearLayout(this)
        sc.addView(stkDots, lp(-1, -2).apply { topMargin = dp(10) })
        stkBest = tv("", 13f, p.sub).apply { setPadding(0, dp(12), 0, 0) }
        sc.addView(stkBest)
        stkHint = tv("", 13f, p.tx, true).apply { setPadding(0, dp(4), 0, 0) }
        sc.addView(stkHint)
        stkCard.addView(sc, FrameLayout.LayoutParams(-1, -2))
        stkFlame = FlameView(this)
        stkCard.addView(stkFlame, FrameLayout.LayoutParams(dp(66), dp(78), Gravity.TOP or Gravity.END).apply { topMargin = dp(10); rightMargin = dp(14) })
        add(stkCard)

        val hero = statCard()
        hero.addView(tv("Общее время прослушивания", 13f, p.sub))
        stTime = tv("—", 32f, p.ac, true); hero.addView(stTime)
        add(hero)

        val a = statCard(); a.addView(tv("Треков", 13f, p.sub))
        stTracks = tv("0", 26f, p.tx, true); a.addView(stTracks)
        val b = statCard(); b.addView(tv("Артистов", 13f, p.sub))
        stArtists = tv("0", 26f, p.tx, true); b.addView(stArtists)
        val tiles = LinearLayout(this)
        tiles.addView(a, lp(0, -2, 1f).apply { rightMargin = dp(5) })
        tiles.addView(b, lp(0, -2, 1f).apply { leftMargin = dp(5) })
        add(tiles)

        // итоги месяца / года
        val sm = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(18), dp(16))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(mix(over(p.card, p.bg2), p.ac, 0.30f), mix(over(p.card, p.bg2), p.ac2, 0.10f))).apply {
                cornerRadius = dp(p.rad + 4).toFloat()
                if (p.stroke != 0) setStroke(dp(1), p.stroke)
            }
        }
        val sh = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        sh.addView(tv("✨ Итоги", 14f, p.tx, true), lp(0, -2, 1f))
        val seg = LinearLayout(this).apply { background = GradientDrawable().apply { setColor(withA(p.tx, 0x18)); cornerRadius = dp(18).toFloat() }; setPadding(dp(3), dp(3), dp(3), dp(3)) }
        sumM = tv("Месяц", 13f, p.sub, true).apply { setPadding(dp(14), dp(6), dp(14), dp(6)) }
        sumY = tv("Год", 13f, p.sub, true).apply { setPadding(dp(14), dp(6), dp(14), dp(6)) }
        seg.addView(sumM); seg.addView(sumY)
        sumM.setOnClickListener { if (sumYear) { sumYear = false; sumOff = 0; updateSummary(true) } }
        sumY.setOnClickListener { if (!sumYear) { sumYear = true; sumOff = 0; updateSummary(true) } }
        sh.addView(seg)
        sm.addView(sh)
        val nav = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val sl = tv("‹", 30f, p.tx).apply { setPadding(dp(8), 0, dp(12), 0); setOnClickListener { shiftSum(-1) } }
        sumRight = tv("›", 30f, p.tx).apply { setPadding(dp(12), 0, dp(8), 0); setOnClickListener { shiftSum(1) } }
        sumTitle = tv("", 18f, p.tx, true).apply { gravity = Gravity.CENTER }
        nav.addView(sl); nav.addView(sumTitle, lp(0, -2, 1f)); nav.addView(sumRight)
        sm.addView(nav, lp(-1, -2).apply { topMargin = dp(8) })
        sumBody = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        sumHours = tv("", 34f, p.ac, true).apply { setPadding(0, dp(6), 0, 0) }
        sumDelta = tv("", 13f, p.sub, true)
        sumFacts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        sumBody.addView(sumHours); sumBody.addView(sumDelta)
        sumBody.addView(sumFacts, lp(-1, -2).apply { topMargin = dp(12) })
        sm.addView(sumBody)
        add(sm)

        // неделя
        val w = statCard()
        w.addView(tv("Активность по неделям", 13f, p.sub))
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val left = tv("‹", 32f, p.ac).apply { setPadding(dp(12), 0, dp(12), 0); setOnClickListener { shiftWeek(-1) } }
        wkRight = tv("›", 32f, p.ac).apply { setPadding(dp(12), 0, dp(12), 0); setOnClickListener { shiftWeek(1) } }
        wkSub = tv("", 12f, p.sub).apply { gravity = Gravity.CENTER }
        wkTitle = tv("", 17f, p.tx, true).apply { gravity = Gravity.CENTER }
        val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        mid.addView(wkSub, lp(-1, -2)); mid.addView(wkTitle, lp(-1, -2))
        head.addView(left); head.addView(mid, lp(0, -2, 1f)); head.addView(wkRight)
        w.addView(head, lp(-1, -2).apply { topMargin = dp(6) })
        wkChart = WeekChart(this, p)
        w.addView(wkChart, lp(-1, dp(180)).apply { topMargin = dp(8) })
        wkTotal = tv("", 13f, p.sub).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) }
        w.addView(wkTotal, lp(-1, -2))
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onFling(a: MotionEvent?, b: MotionEvent, vx: Float, vy: Float): Boolean {
                if (a == null) return false
                val dx = b.x - a.x; val dy = b.y - a.y
                if (Math.abs(dx) > dp(50) && Math.abs(dx) > Math.abs(dy) * 1.2f) { shiftWeek(if (dx > 0) -1 else 1); return true }
                return false
            }
        })
        var sx = 0f; var sy = 0f
        w.setOnTouchListener { v, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) { sx = e.x; sy = e.y; v.parent.requestDisallowInterceptTouchEvent(true) }
            else if (e.actionMasked == MotionEvent.ACTION_MOVE &&
                Math.abs(e.y - sy) > Math.abs(e.x - sx) && Math.abs(e.y - sy) > dp(12)) {
                v.parent.requestDisallowInterceptTouchEvent(false)
            }
            gd.onTouchEvent(e)
            true
        }
        add(w)

        // время суток
        val dc = statCard()
        dc.addView(tv("Активность по времени суток", 13f, p.sub))
        val drow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        dayDonut = DayDonut(this, p)
        drow.addView(dayDonut, lp(dp(150), dp(150)))
        dayLegend = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        drow.addView(dayLegend, lp(0, -2, 1f).apply { leftMargin = dp(16) })
        dc.addView(drow, lp(-1, -2).apply { topMargin = dp(8) })
        dayInsight = tv("", 14f, p.ac, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, 0) }
        dc.addView(dayInsight, lp(-1, -2))
        add(dc)

        // жанры
        val g = statCard()
        g.addView(tv("Любимые жанры", 13f, p.sub))
        genBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        g.addView(genBox, lp(-1, -2).apply { topMargin = dp(6) })
        add(g)

        // топ треков
        val tt = statCard()
        val th = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setOnClickListener { openTop100() } }
        th.addView(tv("Топ-5 треков", 13f, p.sub), lp(0, -2, 1f))
        th.addView(tv("Топ-100 ›", 13f, p.ac, true))
        pressFx(th)
        tt.addView(th)
        topBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tt.addView(topBox, lp(-1, -2).apply { topMargin = dp(8) })
        tt.addView(tv("Открыть топ-100 треков  ›", 14f, p.ac, true).apply {
            gravity = Gravity.CENTER; setPadding(dp(16), dp(12), dp(16), dp(12))
            background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(withA(p.ac, 0x22)) }
            setOnClickListener { openTop100() }; pressFx(this)
        }, lp(-1, -2).apply { topMargin = dp(12) })
        add(tt)

        sv.addView(col)
        return sv
    }

    private fun openTop100() {
        val d = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = bgDrawable(); setPadding(dp(12), dp(14), dp(12), 0)
        }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(8), dp(4), dp(12)) }
        head.addView(tv("‹", 34f, p.ac).apply { setPadding(dp(6), 0, dp(18), 0); setOnClickListener { d.dismiss() } })
        val tc = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val n = minOf(100, agg.size)
        tc.addView(tv("Топ-100 треков", 22f, p.tx, true))
        tc.addView(tv("$n из ${agg.size} уникальных • по числу прослушиваний", 12f, p.sub))
        head.addView(tc, lp(0, -2, 1f))
        root.addView(head)
        val ad = Hist(false)
        ad.items = agg.take(100)
        val rv = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(context)
            adapter = ad
            edgeEffectFactory = Bounce()
            clipToPadding = false; setPadding(0, 0, 0, dp(16))
            overScrollMode = View.OVER_SCROLL_ALWAYS
        }
        if (agg.isEmpty()) root.addView(tv("Пока нет прослушанных треков.", 15f, p.sub).apply { setPadding(dp(8), dp(24), dp(8), 0) })
        root.addView(rv, lp(-1, 0, 1f))
        d.setContentView(root)
        d.window?.setBackgroundDrawable(ColorDrawable(p.bg))
        d.show()
        root.alpha = 0f; root.translationY = dp(36).toFloat()
        root.animate().alpha(1f).translationY(0f).setDuration(340).setInterpolator(EASE).start()
    }

    private fun playStatsIn() {
        cascade(statCards, 75L)
        updateStats()
        countUp(stTime, all.sumOf { it.dur }) { hm(it) }
        countUp(stTracks, all.size.toLong()) { it.toString() }
        countUp(stArtists, all.map { it.artist.trim().lowercase() }.toSet().size.toLong()) { it.toString() }
        countUp(stkNum, streakVal.toLong()) { it.toString() }
        stkFlame.scaleX = 0.2f; stkFlame.scaleY = 0.2f
        stkFlame.animate().scaleX(1f).scaleY(1f).setStartDelay(150).setDuration(700)
            .setInterpolator(android.view.animation.OvershootInterpolator(2.2f)).start()
    }

    private fun shiftWeek(d: Int) {
        if (weekOffset + d > 0) return
        weekOffset += d
        val shift = wkChart.width * 0.35f * d
        wkChart.animate().translationX(-shift).alpha(0f).setDuration(120).setInterpolator(EASE).withEndAction {
            updateWeek()
            wkChart.translationX = shift
            wkChart.animate().translationX(0f).alpha(1f).setDuration(220).setInterpolator(EASE).start()
        }.start()
    }

    private fun dayIdx(c: Calendar) = (c.get(Calendar.DAY_OF_WEEK) + 5) % 7

    private fun updateWeek() {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        cal.add(Calendar.DAY_OF_YEAR, -dayIdx(cal))
        cal.add(Calendar.DAY_OF_YEAR, weekOffset * 7)
        val start = cal.timeInMillis
        cal.add(Calendar.DAY_OF_YEAR, 7)
        val end = cal.timeInMillis
        val vals = FloatArray(7)
        var sum = 0L
        val c2 = Calendar.getInstance()
        for (t in all) {
            if (t.ts < start || t.ts >= end) continue
            c2.timeInMillis = t.ts
            vals[dayIdx(c2)] += t.dur / 3600000f
            sum += t.dur
        }
        val today = if (weekOffset == 0) dayIdx(Calendar.getInstance()) else -1
        wkChart.set(vals, today)
        val f1 = SimpleDateFormat("d MMM", Locale.getDefault())
        val f2 = SimpleDateFormat("d MMM yyyy", Locale.getDefault())
        wkTitle.text = "${f1.format(Date(start))} – ${f2.format(Date(end - 1))}"
        wkSub.text = when (weekOffset) { 0 -> "Эта неделя"; -1 -> "Прошлая неделя"; else -> "${-weekOffset} нед. назад" }
        wkTotal.text = "Всего за неделю: ${hm(sum)}  •  часы по дням"
        wkRight.alpha = if (weekOffset == 0) 0.25f else 1f
    }

    // ----- итоги -----
    private class Sum(val ms: Long, val n: Int, val artist: String, val artistN: Int, val track: String,
                      val trackN: Int, val genre: String, val day: String, val dayN: Int, val active: Int, val uniq: Int)

    private fun bounds(year: Boolean, off: Int): Pair<Long, Long> {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        cal.set(Calendar.DAY_OF_MONTH, 1)
        if (year) { cal.set(Calendar.MONTH, Calendar.JANUARY); cal.add(Calendar.YEAR, off) } else cal.add(Calendar.MONTH, off)
        val s = cal.timeInMillis
        if (year) cal.add(Calendar.YEAR, 1) else cal.add(Calendar.MONTH, 1)
        return Pair(s, cal.timeInMillis)
    }

    private fun summarize(s: Long, e: Long): Sum {
        val zone = ZoneId.systemDefault()
        val artistC = HashMap<String, Int>(); val artistName = HashMap<String, String>()
        val trackC = HashMap<String, Int>(); val trackName = HashMap<String, String>()
        val genreC = HashMap<String, Int>(); val dayC = HashMap<Long, Int>()
        var ms = 0L; var n = 0
        for (t in all) {
            if (t.ts < s || t.ts >= e) continue
            n++; ms += t.dur
            val ak = t.artist.trim().lowercase(); artistC[ak] = (artistC[ak] ?: 0) + 1; artistName[ak] = t.artist
            val tk = keyOf(t); trackC[tk] = (trackC[tk] ?: 0) + 1; trackName[tk] = "${t.artist} - ${t.title}"
            for (g in t.genres) { val k = g.lowercase().replaceFirstChar { it.uppercase() }; genreC[k] = (genreC[k] ?: 0) + 1 }
            val dk = Instant.ofEpochMilli(t.ts).atZone(zone).toLocalDate().toEpochDay()
            dayC[dk] = (dayC[dk] ?: 0) + 1
        }
        val ba = artistC.entries.maxByOrNull { it.value }
        val bt = trackC.entries.maxByOrNull { it.value }
        val bg = genreC.entries.maxByOrNull { it.value }
        val bd = dayC.entries.maxByOrNull { it.value }
        val dayLabel = if (bd == null) "—" else LocalDate.ofEpochDay(bd.key).format(DateTimeFormatter.ofPattern("d MMM", Locale.getDefault()))
        return Sum(ms, n, ba?.let { artistName[it.key] } ?: "—", ba?.value ?: 0, bt?.let { trackName[it.key] } ?: "—",
            bt?.value ?: 0, bg?.key ?: "—", dayLabel, bd?.value ?: 0, dayC.size, artistC.size)
    }

    private fun shiftSum(d: Int) {
        if (sumOff + d > 0) return
        sumOff += d
        updateSummary(true)
    }

    private fun segStyle(t: TextView, on: Boolean) {
        t.background = GradientDrawable().apply { cornerRadius = dp(15).toFloat(); setColor(if (on) p.ac else 0) }
        t.setTextColor(if (on) contrast() else p.sub)
    }

    private fun tile(label: String, value: String, sub: String): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(10))
        background = GradientDrawable().apply { setColor(withA(p.tx, 0x14)); cornerRadius = dp(14).toFloat() }
        addView(tv(label, 11f, p.sub))
        addView(tv(value, 14f, p.tx, true).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END })
        if (sub.isNotEmpty()) addView(tv(sub, 11f, p.ac))
    }

    private fun updateSummary(anim: Boolean) {
        if (!::sumTitle.isInitialized) return
        segStyle(sumM, !sumYear); segStyle(sumY, sumYear)
        val (s, e) = bounds(sumYear, sumOff)
        val (ps, pe) = bounds(sumYear, sumOff - 1)
        val cur = summarize(s, e)
        val prev = summarize(ps, pe)
        val render = {
            sumTitle.text = if (sumYear) "${Date(s).let { SimpleDateFormat("yyyy", Locale.getDefault()).format(it) }} год"
            else SimpleDateFormat("LLLL yyyy", Locale.getDefault()).format(Date(s)).replaceFirstChar { it.uppercase() }
            sumRight.alpha = if (sumOff == 0) 0.25f else 1f
            sumHours.text = hm(cur.ms)
            val what = if (sumYear) "прошлым годом" else "прошлым месяцем"
            when {
                cur.n == 0 -> { sumDelta.text = "Нет прослушиваний за этот период"; sumDelta.setTextColor(p.sub) }
                prev.ms == 0L -> { sumDelta.text = "Первый период с данными"; sumDelta.setTextColor(p.sub) }
                else -> {
                    val pct = ((cur.ms - prev.ms) * 100 / prev.ms).toInt()
                    if (pct >= 0) { sumDelta.text = "▲ на $pct% больше, чем $what"; sumDelta.setTextColor(0xFF4CAF50.toInt()) }
                    else { sumDelta.text = "▼ на ${-pct}% меньше, чем $what"; sumDelta.setTextColor(0xFFFF7043.toInt()) }
                }
            }
            sumFacts.removeAllViews()
            val tiles = listOf(
                tile("Любимый артист", cur.artist, if (cur.artistN > 0) "${cur.artistN} ${times(cur.artistN)}" else ""),
                tile("Любимый трек", cur.track, if (cur.trackN > 0) "${cur.trackN} ${times(cur.trackN)}" else ""),
                tile("Любимый жанр", cur.genre, ""),
                tile("Лучший день", cur.day, if (cur.dayN > 0) "${cur.dayN} ${if (cur.dayN % 10 == 1 && cur.dayN % 100 != 11) "трек" else "треков"}" else ""),
                tile("Активных дней", cur.active.toString(), ""),
                tile("Треков / артистов", "${cur.n} / ${cur.uniq}", "")
            )
            for (i in 0 until tiles.size step 2) {
                val r = LinearLayout(this)
                r.addView(tiles[i], lp(0, -1, 1f).apply { rightMargin = dp(4) })
                r.addView(tiles[i + 1], lp(0, -1, 1f).apply { leftMargin = dp(4) })
                sumFacts.addView(r, lp(-1, -2).apply { topMargin = dp(8) })
            }
        }
        if (anim) {
            sumBody.animate().alpha(0f).translationY(dp(8).toFloat()).setDuration(110).withEndAction {
                render()
                sumBody.animate().alpha(1f).translationY(0f).setDuration(260).setInterpolator(EASE).start()
            }.start()
        } else render()
    }

    // ----- серия -----
    private fun updateStreak() {
        if (!::stkNum.isInitialized) return
        val zone = ZoneId.systemDefault()
        val set = TreeSet<Long>()
        for (t in all) set.add(Instant.ofEpochMilli(t.ts).atZone(zone).toLocalDate().toEpochDay())
        val today = LocalDate.now().toEpochDay()
        var d = if (set.contains(today)) today else if (set.contains(today - 1)) today - 1 else -1L
        var cur = 0
        if (d >= 0) while (set.contains(d)) { cur++; d-- }
        var best = 0; var run = 0; var prevD = Long.MIN_VALUE
        for (x in set) { run = if (x == prevD + 1) run + 1 else 1; if (run > best) best = run; prevD = x }
        streakVal = cur
        val active = cur > 0
        stkNum.text = cur.toString()
        stkNum.setTextColor(if (cur >= 100) 0xFF42A5F5.toInt() else if (active) 0xFFFF9800.toInt() else p.sub)
        stkUnit.text = daysW(cur) + " подряд"
        stkFlame.setStreak(cur)
        val tierN = if (cur >= 100) 3 else if (cur >= 30) 2 else if (cur >= 7) 1 else 0
        stkCard.setTier(tierN)
        val base = over(p.card, p.bg2)
        stkCard.background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(if (active) mix(base, if (tierN >= 3) 0xFF1E88E5.toInt() else 0xFFFF7A00.toInt(), 0.30f + 0.05f * tierN) else base, base)).apply {
            cornerRadius = dp(p.rad + 4).toFloat()
            if (p.stroke != 0) setStroke(dp(1), p.stroke)
        }
        stkBest.text = "Лучшая серия: $best ${daysW(best)}"
        stkHint.text = when {
            cur == 0 -> "Послушай трек сегодня — и начнётся новая серия"
            !set.contains(today) -> "Послушай что-нибудь сегодня, чтобы не потерять серию"
            cur >= 100 -> "Синее пламя — больше 100 дней подряд! 🔵🔥"
            cur >= 30 -> "Месяц огня — ты в ударе! 🔥"
            cur >= 7 -> "Неделя в огне! Так держать 🔥"
            else -> "Серия продолжается — так держать!"
        }
        stkHint.setTextColor(if (active) 0xFFFF9800.toInt() else p.sub)
        stkDots.removeAllViews()
        val letters = arrayOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")
        for (i in 6 downTo 0) {
            val day = today - i
            val on = set.contains(day)
            val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
            c.addView(View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    if (on) setColor(0xFFFF9800.toInt()) else setColor(withA(p.tx, 0x14))
                    if (i == 0 && !on) setStroke(dp(2), 0xFFFF9800.toInt())
                }
            }, lp(dp(26), dp(26)))
            c.addView(tv(letters[LocalDate.ofEpochDay(day).dayOfWeek.value - 1], 11f, if (i == 0) p.tx else p.sub, i == 0).apply { setPadding(0, dp(4), 0, 0) })
            stkDots.addView(c, lp(0, -2, 1f))
        }
    }

    private fun topRow(r: Row): View {
        val row = ShimmerCard(this, withA(p.tx, 0x0E), dp(14).toFloat(), p.ac).apply {
            setPadding(dp(10), dp(8), dp(12), dp(8)); gravity = Gravity.CENTER_VERTICAL
            setMetal(metalOf(r.rank))
        }
        val badge = tv("", 13f, p.sub, true).apply { gravity = Gravity.CENTER }
        styleBadge(badge, r.rank)
        row.addView(badge, lp(dp(28), dp(28)).apply { rightMargin = dp(10) })
        val img = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        round(img, 10)
        bindCover(img, r.t.cover)
        row.addView(img, lp(dp(46), dp(46)))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, dp(6), 0) }
        col.addView(tv("${r.t.artist} - ${r.t.title}", 14f, p.tx, true).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
        if (r.t.album.isNotEmpty()) col.addView(tv(r.t.album, 12f, p.sub).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
        row.addView(col, lp(0, -2, 1f))
        row.addView(tv("${r.plays} ${times(r.plays)}", 13f, p.ac, true))
        row.setOnClickListener { details(r.t) }
        pressFx(row)
        return row
    }

    private fun updateStats() {
        if (!::stTime.isInitialized) return
        stTime.text = hm(all.sumOf { it.dur })
        stTracks.text = all.size.toString()
        stArtists.text = all.map { it.artist.trim().lowercase() }.toSet().size.toString()
        updateStreak()
        updateSummary(false)
        updateWeek()

        val per = IntArray(4)
        val perMs = LongArray(4)
        val c3 = Calendar.getInstance()
        for (t in all) {
            c3.timeInMillis = t.ts
            val hr = c3.get(Calendar.HOUR_OF_DAY)
            val idx = when { hr in 6..11 -> 0; hr in 12..17 -> 1; hr in 18..23 -> 2; else -> 3 }
            per[idx]++; perMs[idx] += t.dur
        }
        dayDonut.set(per, FloatArray(4) { perMs[it] / 3600000f })
        dayLegend.removeAllViews()
        val names = arrayOf("Утро", "День", "Вечер", "Ночь")
        val ranges = arrayOf("6–12", "12–18", "18–24", "0–6")
        val total = per.sum()
        for (i in 0..3) {
            val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(5), 0, dp(5)) }
            r.addView(View(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(dayDonut.colors[i]) }
            }, lp(dp(10), dp(10)).apply { rightMargin = dp(10) })
            val nm = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val nline = LinearLayout(this).apply { gravity = Gravity.BOTTOM }
            nline.addView(tv(names[i], 14f, p.tx, true))
            nline.addView(tv("(${per[i]})", 13f, p.sub).apply { setPadding(dp(5), 0, 0, 0) })
            nm.addView(nline); nm.addView(tv("${ranges[i]} · ${perMs[i] / 3600000}ч ${perMs[i] / 60000 % 60}м", 11f, p.sub))
            r.addView(nm, lp(0, -2, 1f))
            r.addView(tv(if (total > 0) "${per[i] * 100 / total}%" else "0%", 14f, p.tx, true))
            dayLegend.addView(r)
        }
        if (total > 0) {
            var best = 0
            for (i in 1..3) if (per[i] > per[best]) best = i
            val ph = arrayOf("🌅 Чаще всего ты слушаешь музыку утром", "☀️ Чаще всего ты слушаешь музыку днём",
                "🌇 Чаще всего ты слушаешь музыку вечером", "🌙 Чаще всего ты слушаешь музыку ночью")
            dayInsight.text = ph[best]
        } else dayInsight.text = "Пока нет данных"

        genBox.removeAllViews()
        val cnt = HashMap<String, Int>()
        for (t in all) for (g in t.genres) {
            val k = g.lowercase().replaceFirstChar { it.uppercase() }
            cnt[k] = (cnt[k] ?: 0) + 1
        }
        val top = cnt.entries.sortedByDescending { it.value }.take(5)
        if (top.isEmpty()) {
            genBox.addView(tv("Нет данных: в тегах прослушанных треков не указан жанр.", 14f, p.sub))
        } else {
            val mx = top[0].value
            val track = withA(p.tx, 0x22)
            for (e in top) {
                val r = LinearLayout(this).apply { setPadding(0, dp(8), 0, dp(4)) }
                r.addView(tv(e.key, 15f, p.tx), lp(0, -2, 1f))
                r.addView(tv("${e.value * 100 / all.size}%", 13f, p.sub))
                genBox.addView(r)
                val bar = LinearLayout(this).apply {
                    background = GradientDrawable().apply { setColor(track); cornerRadius = dp(4).toFloat() }
                }
                bar.addView(View(this).apply {
                    background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(p.ac, p.ac2)).apply { cornerRadius = dp(4).toFloat() }
                }, lp(0, dp(8), e.value.toFloat()))
                bar.addView(View(this), lp(0, dp(8), (mx - e.value).toFloat()))
                genBox.addView(bar, lp(-1, dp(8)))
            }
        }

        topBox.removeAllViews()
        if (agg.isEmpty()) topBox.addView(tv("Пока нет прослушанных треков.", 14f, p.sub))
        else for (r in agg.take(5)) topBox.addView(topRow(r), lp(-1, -2).apply { topMargin = dp(6) })
    }

    // ---------- Календарь ----------
    private fun buildCalendar(): View {
        calCards.clear()
        val sv = ScrollView(this).apply { overScrollMode = View.OVER_SCROLL_ALWAYS; isVerticalScrollBarEnabled = false }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(28)) }
        val card = statCard()
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val left = tv("‹", 32f, p.ac).apply { setPadding(dp(10), 0, dp(14), 0); setOnClickListener { shiftMonth(-1) } }
        calRight = tv("›", 32f, p.ac).apply { setPadding(dp(14), 0, dp(10), 0); setOnClickListener { shiftMonth(1) } }
        calTitle = tv("", 19f, p.tx, true).apply { gravity = Gravity.CENTER }
        calSub = tv("", 12f, p.sub).apply { gravity = Gravity.CENTER }
        val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        mid.addView(calTitle, lp(-1, -2)); mid.addView(calSub, lp(-1, -2))
        head.addView(left); head.addView(mid, lp(0, -2, 1f)); head.addView(calRight)
        card.addView(head)
        calGrid = CalView(this, p)
        var csx = 0f; var csy = 0f
        calGrid.setOnTouchListener { v, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) { csx = e.x; csy = e.y; v.parent.requestDisallowInterceptTouchEvent(true) }
            else if (e.actionMasked == MotionEvent.ACTION_MOVE && Math.abs(e.y - csy) > Math.abs(e.x - csx) && Math.abs(e.y - csy) > dp(12))
                v.parent.requestDisallowInterceptTouchEvent(false)
            false
        }
        calGrid.onPick = { day -> calSel = day; updateCalendar(true) }
        calGrid.onSwipe = { d -> shiftMonth(d) }
        card.addView(calGrid, lp(-1, -2).apply { topMargin = dp(8) })
        card.alpha = 0f; calCards.add(card)
        col.addView(card, lp(-1, -2))

        val dw = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        calDayTitle = tv("", 17f, p.tx, true).apply { setPadding(dp(6), dp(16), 0, dp(6)) }
        calDayBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        dw.addView(calDayTitle); dw.addView(calDayBox)
        dw.alpha = 0f; calCards.add(dw)
        col.addView(dw, lp(-1, -2))
        sv.addView(col)
        return sv
    }

    private fun shiftMonth(d: Int) {
        if (calOffset + d > 0) return
        calOffset += d; calSel = -1
        val shift = calGrid.width * 0.3f * d
        calGrid.animate().translationX(-shift).alpha(0f).setDuration(110).setInterpolator(EASE).withEndAction {
            updateCalendar(false)
            calGrid.translationX = shift
            calGrid.animate().translationX(0f).alpha(1f).setDuration(220).setInterpolator(EASE).start()
        }.start()
    }

    private fun plate(t: Track): View {
        val row = ShimmerCard(this, p.card, dp(p.rad).toFloat(), p.ac).apply {
            setPadding(dp(10), dp(10), dp(12), dp(10)); gravity = Gravity.CENTER_VERTICAL
        }
        val img = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        round(img, 12)
        bindCover(img, t.cover)
        row.addView(img, lp(dp(56), dp(56)))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        col.addView(tv("${t.artist} - ${t.title}", 15f, p.tx, true).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
        if (t.album.isNotEmpty()) col.addView(tv(t.album, 13f, p.sub).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
        col.addView(tv(fmtDur(t.dur), 12f, p.ac))
        row.addView(col, lp(0, -2, 1f))
        row.setOnClickListener { details(t) }
        pressFx(row)
        return row
    }

    private fun updateCalendar(animateDay: Boolean) {
        if (!::calGrid.isInitialized) return
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.add(Calendar.MONTH, calOffset)
        val start = cal.timeInMillis
        val offset = dayIdx(cal)
        val days = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        val year = cal.get(Calendar.YEAR); val month = cal.get(Calendar.MONTH)
        cal.add(Calendar.MONTH, 1)
        val end = cal.timeInMillis
        val cnts = IntArray(32)
        var total = 0; var dur = 0L
        val c2 = Calendar.getInstance()
        val inMonth = ArrayList<Track>()
        for (t in all) {
            if (t.ts < start || t.ts >= end) continue
            c2.timeInMillis = t.ts
            cnts[c2.get(Calendar.DAY_OF_MONTH)]++
            total++; dur += t.dur; inMonth.add(t)
        }
        val now = Calendar.getInstance()
        val todayDay = if (now.get(Calendar.YEAR) == year && now.get(Calendar.MONTH) == month) now.get(Calendar.DAY_OF_MONTH) else -1
        if (calSel !in 1..days) calSel = todayDay
        calTitle.text = SimpleDateFormat("LLLL yyyy", Locale.getDefault()).format(Date(start)).replaceFirstChar { it.uppercase() }
        calSub.text = "$total ${if (total % 10 == 1 && total % 100 != 11) "трек" else "треков"}  •  ${hm(dur)}"
        calRight.alpha = if (calOffset == 0) 0.25f else 1f
        calGrid.setData(year, month, cnts, if (calSel in 1..days) calSel else 0, if (todayDay > 0) todayDay else 0)

        calDayBox.removeAllViews()
        if (calSel in 1..days) {
            val dayTracks = inMonth.filter { t -> c2.timeInMillis = t.ts; c2.get(Calendar.DAY_OF_MONTH) == calSel }.sortedBy { it.ts }
            val dateCal = Calendar.getInstance().apply { timeInMillis = start; set(Calendar.DAY_OF_MONTH, calSel) }
            val title = SimpleDateFormat("d MMMM, EEEE", Locale.getDefault()).format(dateCal.time)
            val sumMs = dayTracks.sumOf { it.dur }
            calDayTitle.text = if (dayTracks.isEmpty()) "$title\nВ этот день ничего не слушали"
            else "$title\n${dayTracks.size} ${if (dayTracks.size % 10 == 1 && dayTracks.size % 100 != 11) "трек" else "треков"}  •  ${hm(sumMs)}"
            val rows = ArrayList<View>()
            for (t in dayTracks) {
                val v = plate(t); rows.add(v)
                calDayBox.addView(v, lp(-1, -2).apply { topMargin = dp(8) })
            }
            if (animateDay) cascade(rows, 40L)
        } else calDayTitle.text = "Выбери день в календаре"
    }

    // ---------- настройки ----------
    private fun setCard(title: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = cardBg(); setPadding(dp(16), dp(14), dp(16), dp(14))
        addView(tv(title, 12f, p.sub, true).apply { setPadding(0, 0, 0, dp(6)) })
    }

    private fun setRow(parent: LinearLayout, icon: String, title: String, sub: String, color: Int, onClick: () -> Unit) {
        val r = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(12), dp(4), dp(12)); setOnClickListener { onClick() }
        }
        r.addView(tv(icon, 20f, p.tx), lp(dp(36), -2))
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        c.addView(tv(title, 16f, color, true))
        if (sub.isNotEmpty()) c.addView(tv(sub, 12f, p.sub))
        r.addView(c, lp(0, -2, 1f))
        r.addView(tv("›", 20f, p.sub))
        pressFx(r)
        parent.addView(r)
    }

    private fun pickTheme() {
        sheet("Тема оформления") { c, close ->
            val cur = pr.getInt("theme", 0)
            for (i in PALS.indices step 2) {
                val row = LinearLayout(this)
                for (j in 0..1) {
                    val idx = i + j
                    if (idx >= PALS.size) { row.addView(View(this), lp(0, dp(110), 1f)); continue }
                    val v = ThemePreview(this, PALS[idx], idx == cur)
                    v.setOnClickListener {
                        pr.edit().putInt("theme", idx).apply()
                        close()
                        applyTheme(); buildMain(); showSettings()
                    }
                    pressFx(v)
                    row.addView(v, lp(0, dp(110), 1f).apply { setMargins(dp(5), dp(5), dp(5), dp(5)) })
                }
                c.addView(row)
            }
        }
    }

    private fun confirmDelete() {
        sheet("Удалить всю историю?") { c, close ->
            c.addView(tv("Все записи и обложки будут удалены. Это нельзя отменить — сначала можно сделать бэкап.", 14f, p.sub).apply { setPadding(dp(8), 0, dp(8), dp(16)) })
            val r = LinearLayout(this)
            r.addView(sheetBtn("Отмена", withA(p.tx, 0x18), p.tx) { close() }, lp(0, -2, 1f).apply { rightMargin = dp(6) })
            r.addView(sheetBtn("Удалить", 0xFFE53935.toInt(), 0xFFFFFFFF.toInt()) {
                db.clear(); cache.evictAll(); toast("История удалена"); close()
            }, lp(0, -2, 1f).apply { leftMargin = dp(6) })
            c.addView(r)
        }
    }

    private fun closeSettings() { inSettings = false; setContentView(mainRoot); enter(mainRoot, -1) }

    private fun showSettings() {
        hideKb()
        inSettings = true
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(8), dp(14), dp(28)) }
        fun add(v: View) = col.addView(v, lp(-1, -2).apply { topMargin = dp(12) })
        col.addView(tv("‹ Назад", 18f, p.ac).apply { setPadding(dp(4), dp(8), 0, dp(8)); setOnClickListener { closeSettings() } })
        col.addView(tv("Настройки", 26f, p.tx, true).apply { setPadding(dp(4), 0, 0, 0) })

        val th = pr.getInt("th", 60)
        val rec = setCard("ЗАПИСЬ")
        val thv = tv("$th%", 30f, p.ac, true)
        rec.addView(tv("Порог прослушивания", 16f, p.tx, true))
        rec.addView(thv)
        rec.addView(SeekBar(this).apply {
            max = 100; progress = th
            progressTintList = ColorStateList.valueOf(p.ac)
            thumbTintList = ColorStateList.valueOf(p.ac)
            progressBackgroundTintList = ColorStateList.valueOf(withA(p.tx, 0x30))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) {
                    thv.text = "$v%"; pr.edit().putInt("th", v).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        rec.addView(tv("С какого процента трек считается прослушанным и попадает в историю (0–100).", 12f, p.sub))
        add(rec)

        val look = setCard("ОФОРМЛЕНИЕ")
        setRow(look, "🎨", "Тема оформления", p.n, p.tx) { pickTheme() }
        add(look)

        val data = setCard("ДАННЫЕ")
        setRow(data, "💾", "Создать бэкап", "Сохранить историю и обложки в файл", p.tx) {
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "application/zip"
                putExtra(Intent.EXTRA_TITLE, "aimp-history-" + SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date()) + ".zip")
            }, 1)
        }
        setRow(data, "📥", "Восстановить из бэкапа", "Заменит текущую историю", p.tx) {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            }, 2)
        }
        add(data)

        val bgc = setCard("РАБОТА В ФОНЕ")
        val okTrack = enabled() && Listener.connected
        bgc.addView(tv(
            if (okTrack) "● Отслеживание работает" else if (!enabled()) "● Нет доступа к уведомлениям" else "● Служба не подключена — нажми «Переподключить»",
            14f, if (okTrack) 0xFF4CAF50.toInt() else 0xFFFF7043.toInt(), true).apply { setPadding(dp(4), 0, 0, dp(8)) })
        val swRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(8), dp(4), dp(8)) }
        swRow.addView(tv("🔒", 20f, p.tx), lp(dp(36), -2))
        val swc = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        swc.addView(tv("Постоянное уведомление", 16f, p.tx, true))
        swc.addView(tv("Не даёт системе выгрузить приложение", 12f, p.sub))
        swRow.addView(swc, lp(0, -2, 1f))
        swRow.addView(Switch(this).apply {
            isChecked = Keep.on(this@MainActivity)
            thumbTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(p.ac, p.sub))
            trackTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(withA(p.ac, 0x66), withA(p.tx, 0x30)))
            setOnCheckedChangeListener { _, on ->
                pr.edit().putBoolean("keep", on).apply()
                if (on) Keep.startFgs(this@MainActivity) else Keep.stopFgs(this@MainActivity)
            }
        })
        bgc.addView(swRow)
        setRow(bgc, "🔄", "Переподключить службу", "Если трек не определяется", p.tx) {
            Keep.rebind(this); toast("Запрос на переподключение отправлен")
        }
        setRow(bgc, "🔋", "Батарея: без ограничений", "Чтобы система не усыпляла приложение", p.tx) { openBattery() }
        setRow(bgc, "🚀", "Автозапуск (Xiaomi)", "Разреши приложению запускаться самому", p.tx) { openAutostart() }
        setRow(bgc, "⚙️", "Настройки приложения", "", p.tx) { openAppInfo() }
        bgc.addView(tv("Xiaomi: в «Недавних» потяни карточку приложения вниз и нажми замок 🔒 — тогда система его не закроет.", 12f, p.sub).apply { setPadding(dp(4), dp(8), dp(4), 0) })
        add(bgc)

        val acc = setCard("ДОСТУП")
        setRow(acc, "🔔", "Доступ к уведомлениям", "Нужен, чтобы видеть, что играет в AIMP", p.tx) {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }
        add(acc)

        val danger = setCard("ОПАСНАЯ ЗОНА")
        setRow(danger, "🗑️", "Удалить всю историю", "", 0xFFFF5252.toInt()) { confirmDelete() }
        add(danger)

        val sv = ScrollView(this).apply { background = bgDrawable(); addView(col) }
        setContentView(sv)
        enter(sv, 1)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        val uri = data?.data ?: return
        if (res != RESULT_OK) return
        if (rc == 1) Thread {
            try {
                contentResolver.openOutputStream(uri)!!.use { o ->
                    ZipOutputStream(o).use { z ->
                        z.putNextEntry(ZipEntry("history.json")); z.write(db.toJson().toByteArray()); z.closeEntry()
                        db.coverDir.listFiles()?.forEach { f ->
                            z.putNextEntry(ZipEntry("covers/" + f.name)); f.inputStream().use { it.copyTo(z) }; z.closeEntry()
                        }
                    }
                }
                toast("Бэкап сохранён")
            } catch (e: Exception) { toast("Ошибка: ${e.message}") }
        }.start()
        if (rc == 2) Thread {
            try {
                var json: String? = null
                ZipInputStream(contentResolver.openInputStream(uri)!!).use { z ->
                    var e = z.nextEntry
                    while (e != null) {
                        val n = e.name
                        if (n == "history.json") json = z.readBytes().toString(Charsets.UTF_8)
                        else if (n.startsWith("covers/") && !e.isDirectory)
                            File(db.coverDir, File(n).name).outputStream().use { z.copyTo(it) }
                        e = z.nextEntry
                    }
                }
                if (json == null) throw Exception("в архиве нет history.json")
                db.restore(json!!)
                cache.evictAll()
                toast("История восстановлена")
            } catch (e: Exception) { toast("Ошибка: ${e.message}") }
        }.start()
    }
}
