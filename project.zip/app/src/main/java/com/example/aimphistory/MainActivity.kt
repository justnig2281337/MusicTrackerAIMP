package com.example.aimphistory

import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.transition.TransitionManager
import android.util.LruCache
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.SimpleItemAnimator
import androidx.viewpager.widget.PagerAdapter
import androidx.viewpager.widget.ViewPager
import java.io.File
import java.text.Collator
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors
import java.util.zip.*

class Pg(private val views: List<View>) : PagerAdapter() {
    override fun getCount() = views.size
    override fun isViewFromObject(v: View, o: Any) = v === o
    override fun instantiateItem(c: ViewGroup, i: Int): Any { c.addView(views[i]); return views[i] }
    override fun destroyItem(c: ViewGroup, i: Int, o: Any) { c.removeView(o as View) }
}

fun times(n: Int) = if (n % 10 in 2..4 && n % 100 !in 12..14) "раза" else "раз"

class MainActivity : Activity() {
    private lateinit var db: Db
    private lateinit var pr: SharedPreferences
    private lateinit var p: P
    private lateinit var mainRoot: View
    private lateinit var banner: TextView
    private lateinit var search: EditText
    private lateinit var countTv: TextView
    private lateinit var emptyTv: TextView
    private lateinit var histRv: RecyclerView
    private lateinit var histAd: Hist
    private lateinit var histPage: LinearLayout
    // сейчас играет
    private lateinit var nowCard: LinearLayout
    private lateinit var nowImg: ImageView
    private lateinit var nowEq: EqView
    private lateinit var nowStatus: TextView
    private lateinit var nowTitle: TextView
    private lateinit var nowSub: TextView
    private lateinit var nowInfo: TextView
    private lateinit var nowProg: Prog
    private var nowKey = ""
    private var lastCover: Bitmap? = null
    // статистика
    private lateinit var stTime: TextView
    private lateinit var stTracks: TextView
    private lateinit var stArtists: TextView
    private lateinit var wkTitle: TextView
    private lateinit var wkSub: TextView
    private lateinit var wkTotal: TextView
    private lateinit var wkRight: TextView
    private lateinit var wkChart: WeekChart
    private lateinit var dayDonut: DayDonut
    private lateinit var dayLegend: LinearLayout
    private lateinit var dayInsight: TextView
    private lateinit var genBox: LinearLayout
    private lateinit var topBox: LinearLayout
    private val statCards = ArrayList<View>()
    private var statsPlayed = false

    private var all: List<Track> = emptyList()
    private var agg: List<Row> = emptyList()
    private var counts: Map<String, Int> = HashMap()
    private var inSettings = false
    private var inCalendar = false
    private var selecting = false
    private val selection = HashSet<Long>()
    private lateinit var barBox: FrameLayout
    private lateinit var selBar: LinearLayout
    private lateinit var selCount: TextView
    private lateinit var calView: CalView
    private lateinit var calMonthTv: TextView
    private lateinit var calSubTv: TextView
    private lateinit var calDayTv: TextView
    private lateinit var calEmpty: TextView
    private lateinit var calRv: RecyclerView
    private lateinit var calAd: Hist
    private val calNow = Calendar.getInstance()
    private var calYear = calNow.get(Calendar.YEAR)
    private var calMonth = calNow.get(Calendar.MONTH)
    private var calDay = calNow.get(Calendar.DAY_OF_MONTH)
    private var sortIdx = 0
    private var weekOffset = 0

    private val fmt = SimpleDateFormat("dd.MM.yyyy  HH:mm:ss", Locale.getDefault())
    private val pool = Executors.newFixedThreadPool(2)
    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 8 / 1024).toInt()) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount / 1024
    }
    private val sortNames = arrayOf(
        "Сначала новые", "Сначала старые", "Артист: А → Я", "Артист: Я → А",
        "Название: А → Я", "Название: Я → А", "Альбом: А → Я", "Альбом: Я → А",
        "🏆 Топ по прослушиваниям"
    )

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun lp(w: Int, h: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt)
    private fun keyOf(t: Track) = (t.artist.trim() + "|" + t.title.trim()).lowercase()

    override fun onCreate(b: android.os.Bundle?) {
        super.onCreate(b)
        db = Db.get(this)
        pr = getSharedPreferences("p", 0)
        sortIdx = pr.getInt("sort", 0).coerceIn(0, sortNames.size - 1)
        Db.onChange = { reload() }
        Now.onChange = { updateNow() }
        applyTheme()
        buildMain()
        setContentView(mainRoot)
    }

    override fun onResume() {
        super.onResume()
        banner.visibility = if (enabled()) View.GONE else View.VISIBLE
        reload()
        updateNow()
    }

    override fun onDestroy() { Db.onChange = null; Now.onChange = null; super.onDestroy() }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (selecting) exitSelection() else if (inCalendar) closeCalendar()
        else if (inSettings) closeSettings() else super.onBackPressed()
    }

    private fun applyTheme() {
        p = PALS[pr.getInt("theme", 0).coerceIn(0, PALS.lastIndex)]
        window.statusBarColor = p.bg
        window.navigationBarColor = p.bg
        var f = 0
        if (p.light) f = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        window.decorView.systemUiVisibility = f
    }

    private fun tv(t: String, sz: Float, col: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sz; setTextColor(col)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun cardBg(r: Int = 16) = GradientDrawable().apply { setColor(p.card); cornerRadius = dp(r).toFloat() }
    private fun fmtDur(ms: Long): String { val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60) }
    private fun hm(ms: Long) = "${ms / 3600000} ч ${ms / 60000 % 60} мин"
    private fun toast(s: String) = runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_LONG).show() }
    private fun enabled() = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        ?.contains(packageName) == true

    private fun hideKb() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(search.windowToken, 0)
        search.clearFocus()
    }

    private fun round(v: View, r: Int) {
        v.clipToOutline = true
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, o: Outline) { o.setRoundRect(0, 0, view.width, view.height, dp(r).toFloat()) }
        }
    }

    /** Лёгкое «нажатие» плашки. */
    private fun pressFx(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> view.animate().scaleX(0.96f).scaleY(0.96f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.animate().scaleX(1f).scaleY(1f).setDuration(180).start()
            }
            false
        }
    }

    private fun enter(v: View, dir: Int) {
        v.alpha = 0f; v.translationX = dp(36) * dir.toFloat()
        v.animate().alpha(1f).translationX(0f).setDuration(260).setInterpolator(DecelerateInterpolator()).start()
    }

    private fun countUp(t: TextView, target: Long, f: (Long) -> String) {
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 900; interpolator = DecelerateInterpolator()
            addUpdateListener { t.text = f((target * (it.animatedValue as Float)).toLong()) }
            start()
        }
    }

    // ---------- картинки ----------
    private fun load(name: String, minSide: Int): Bitmap? {
        if (name.isEmpty()) return null
        val f = File(db.coverDir, name)
        if (!f.exists()) return null
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (o.outWidth / (s * 2) >= minSide && o.outHeight / (s * 2) >= minSide) s *= 2
        return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
    }

    private fun loadCap(name: String, cap: Int): Bitmap? {
        if (name.isEmpty()) return null
        val f = File(db.coverDir, name)
        if (!f.exists()) return null
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (maxOf(o.outWidth, o.outHeight) / s > cap) s *= 2
        return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
    }

    private fun bindCover(img: ImageView, name: String) {
        img.tag = name
        val c = if (name.isEmpty()) null else cache.get(name)
        if (c != null) { img.setImageBitmap(c); return }
        img.setImageDrawable(ColorDrawable(p.bg))
        if (name.isEmpty()) return
        pool.execute {
            val bm = load(name, 192)
            if (bm != null) {
                cache.put(name, bm)
                runOnUiThread { if (img.tag == name) img.setImageBitmap(bm) }
            }
        }
    }

    // ---------- данные ----------
    private fun reload() {
        Thread {
            val l = db.all()
            val reps = LinkedHashMap<String, Track>()
            val cnt = HashMap<String, Int>()
            for (t in l) { val k = keyOf(t); if (!reps.containsKey(k)) reps[k] = t; cnt[k] = (cnt[k] ?: 0) + 1 }
            val sorted = reps.entries.map { Row(it.value, cnt[it.key] ?: 1, 0) }.sortedByDescending { it.plays }
            val ag = sorted.mapIndexed { i, r -> Row(r.t, r.plays, i + 1) }
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                val first = all.isEmpty()
                all = l; agg = ag; counts = cnt
                if (first) histAd.lastAnim = -1
                refreshUi()
            }
        }.start()
    }

    private fun refreshUi() { applyFilter(false); updateStats(); updateNow(); if (inCalendar) refreshCalendar(false) }

    // ---------- каркас: вкладки + страницы ----------
    private fun buildMain() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(p.bg) }
        val t0 = tv("История", 17f, p.ac, true)
        val t1 = tv("Статистика", 17f, p.sub, true)
        val tabs = LinearLayout(this)
        for (t in listOf(t0, t1)) {
            t.gravity = Gravity.CENTER; t.setPadding(0, dp(14), 0, dp(14))
            tabs.addView(t, lp(0, -2, 1f))
        }
        val ind = View(this).apply { background = GradientDrawable().apply { setColor(p.ac); cornerRadius = dp(2).toFloat() } }
        val tabWrap = FrameLayout(this)
        tabWrap.addView(tabs, FrameLayout.LayoutParams(-1, -2))
        tabWrap.addView(ind, FrameLayout.LayoutParams(dp(60), dp(3), Gravity.BOTTOM))
        tabWrap.post {
            val w = tabWrap.width / 2 - dp(40)
            ind.layoutParams = FrameLayout.LayoutParams(w, dp(3), Gravity.BOTTOM).apply { leftMargin = dp(20) }
        }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(4), dp(4), 0) }
        bar.addView(tabWrap, lp(0, -2, 1f))
        bar.addView(tv("📅", 22f, p.ac).apply {
            setPadding(dp(10), dp(8), dp(6), dp(8)); setOnClickListener { showCalendar() }; pressFx(this)
        })
        bar.addView(tv("⚙", 24f, p.ac).apply {
            setPadding(dp(10), dp(8), dp(14), dp(8)); setOnClickListener { showSettings() }; pressFx(this)
        })
        selBar = buildSelBar()
        barBox = FrameLayout(this)
        barBox.addView(bar, FrameLayout.LayoutParams(-1, -2))
        barBox.addView(selBar, FrameLayout.LayoutParams(-1, -1))
        root.addView(barBox)

        banner = tv("Нужен доступ к уведомлениям — нажми сюда и включи «AIMP История»", 14f, p.tx).apply {
            background = cardBg(); setPadding(dp(14), dp(12), dp(14), dp(12))
            setOnClickListener { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
        }
        root.addView(banner, lp(-1, -2).apply { setMargins(dp(12), dp(8), dp(12), 0) })

        statsPlayed = false
        selecting = false; selection.clear()
        val pager = ViewPager(this)
        pager.adapter = Pg(listOf(buildHistory(), buildStats()))
        pager.setPageTransformer(false) { page, pos ->
            val a = Math.abs(pos)
            page.alpha = 1f - a * 0.5f
            val s = 0.92f + 0.08f * (1f - a)
            page.scaleX = s; page.scaleY = s
        }
        pager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(pos: Int, off: Float, px: Int) {
                ind.translationX = (pos + off) * tabWrap.width / 2f
                if (pos == 0 && off > 0.05f && !statsPlayed) { statsPlayed = true; playStatsIn() }
            }
            override fun onPageSelected(pos: Int) {
                t0.setTextColor(if (pos == 0) p.ac else p.sub)
                t1.setTextColor(if (pos == 1) p.ac else p.sub)
                hideKb()
                if (pos == 0) { statsPlayed = false; for (c in statCards) c.alpha = 0f }
                else if (!statsPlayed) { statsPlayed = true; playStatsIn() }
            }
            override fun onPageScrollStateChanged(s: Int) {}
        })
        t0.setOnClickListener { pager.setCurrentItem(0, true) }
        t1.setOnClickListener { pager.setCurrentItem(1, true) }
        root.addView(pager, lp(-1, 0, 1f))
        mainRoot = root
        refreshUi()
    }

    // ---------- История ----------
    private fun comparator(i: Int): Comparator<Track> {
        val c = Collator.getInstance()
        return when (i) {
            1 -> Comparator { a, b -> a.ts.compareTo(b.ts) }
            2 -> Comparator { a, b -> c.compare(a.artist, b.artist) }
            3 -> Comparator { a, b -> c.compare(b.artist, a.artist) }
            4 -> Comparator { a, b -> c.compare(a.title, b.title) }
            5 -> Comparator { a, b -> c.compare(b.title, a.title) }
            6 -> Comparator { a, b -> c.compare(a.album, b.album) }
            7 -> Comparator { a, b -> c.compare(b.album, a.album) }
            else -> Comparator { a, b -> b.ts.compareTo(a.ts) }
        }
    }

    private fun applyFilter(toTop: Boolean) {
        val q = search.text.toString().trim().lowercase()
        val parts = q.split(' ').filter { it.isNotEmpty() }
        val rows: List<Row>
        if (sortIdx == 8) {
            rows = if (parts.isEmpty()) agg else agg.filter { r -> parts.all { r.t.search.contains(it) } }
        } else {
            var l: List<Track> = all
            if (parts.isNotEmpty()) l = l.filter { t -> parts.all { t.search.contains(it) } }
            rows = l.sortedWith(comparator(sortIdx)).map { Row(it, 0, 0) }
        }
        histAd.items = rows
        histAd.notifyDataSetChanged()
        if (toTop) histRv.scrollToPosition(0)
        val what = if (sortIdx == 8) "уникальных треков" else if (q.isNotEmpty()) "найдено" else "треков"
        countTv.text = "${rows.size} $what  •  ${sortNames[sortIdx]}"
        emptyTv.text = if (all.isEmpty())
            "Пока пусто. Включи музыку в AIMP — трек появится здесь, когда достигнет порога прослушивания."
        else "Ничего не найдено"
        emptyTv.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun onAccent() = if (lum(p.ac) > 150) 0xFF101010.toInt() else 0xFFFFFFFF.toInt()

    private fun styleBadge(b: TextView, rank: Int) {
        val m = metalOf(rank)
        b.text = rank.toString()
        b.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            if (m != 0) intArrayOf(metalLight(m), m, metalDark(m)) else intArrayOf(p.bg, p.bg)
        ).apply { shape = GradientDrawable.OVAL }
        b.setTextColor(if (m != 0) 0xFF1A1A1A.toInt() else p.sub)
    }

    private fun styleCheck(b: TextView, on: Boolean) {
        b.text = if (on) "✓" else ""
        b.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            if (on) setColor(p.ac) else { setColor(Color.TRANSPARENT); setStroke(dp(2), p.sub) }
        }
        b.setTextColor(if (on) onAccent() else p.sub)
    }

    // ---------- выделение и удаление ----------
    private fun buildSelBar(): LinearLayout {
        val b = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(p.bg); visibility = View.GONE
            setPadding(dp(4), 0, dp(4), 0)
        }
        b.addView(tv("✕", 22f, p.tx).apply { setPadding(dp(14), dp(8), dp(14), dp(8)); setOnClickListener { exitSelection() } })
        selCount = tv("", 17f, p.tx, true)
        b.addView(selCount, lp(0, -2, 1f))
        b.addView(tv("Все", 15f, p.ac, true).apply { setPadding(dp(12), dp(8), dp(12), dp(8)); setOnClickListener { selectAll() } })
        b.addView(tv("🗑", 22f, p.tx).apply { setPadding(dp(12), dp(8), dp(14), dp(8)); setOnClickListener { askDeleteSelected() } })
        return b
    }

    private fun setSelBar(on: Boolean) {
        TransitionManager.beginDelayedTransition(barBox, android.transition.Fade())
        barBox.getChildAt(0).visibility = if (on) View.GONE else View.VISIBLE
        selBar.visibility = if (on) View.VISIBLE else View.GONE
    }

    private fun startSelection() { selecting = true; setSelBar(true) }

    private fun exitSelection() {
        if (!selecting) return
        selecting = false; selection.clear()
        setSelBar(false)
        histAd.notifyDataSetChanged()
    }

    private fun toggleSel(pos: Int, r: Row) {
        if (!selection.add(r.t.ts)) selection.remove(r.t.ts)
        if (selection.isEmpty()) { exitSelection(); return }
        selCount.text = "Выбрано: ${selection.size}"
        histAd.notifyItemChanged(pos)
    }

    private fun selectAll() {
        for (r in histAd.items) selection.add(r.t.ts)
        selCount.text = "Выбрано: ${selection.size}"
        histAd.notifyDataSetChanged()
    }

    private fun confirmDelete(ts: List<Long>, msg: String, onDone: () -> Unit = {}) {
        val d = AlertDialog.Builder(this).setMessage(msg)
            .setPositiveButton("Удалить") { _, _ ->
                Thread { db.deleteByTs(ts) }.start()
                onDone(); toast("Удалено записей: ${ts.size}")
            }
            .setNegativeButton("Отмена", null).show()
        d.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(0xFFFF5252.toInt())
    }

    private fun askDeleteSelected() {
        if (selection.isEmpty()) return
        val n = selection.size
        if (sortIdx == 8) {
            val keys = agg.filter { it.t.ts in selection }.map { keyOf(it.t) }.toSet()
            val ts = all.filter { keyOf(it) in keys }.map { it.ts }
            confirmDelete(ts, "Удалить выбранные треки ($n) вместе со всеми их прослушиваниями (${ts.size})? Это нельзя отменить.") { exitSelection() }
        } else {
            confirmDelete(selection.toList(), "Удалить выбранные записи ($n) из истории? Это нельзя отменить.") { exitSelection() }
        }
    }

    inner class Hist(private val selectable: Boolean) : RecyclerView.Adapter<VH>() {
        var items: List<Row> = emptyList()
        var lastAnim = -1
        override fun getItemCount() = items.size
        override fun onCreateViewHolder(g: ViewGroup, v: Int): VH {
            val wrap = FrameLayout(this@MainActivity).apply {
                setPadding(0, dp(5), 0, dp(5)); layoutParams = RecyclerView.LayoutParams(-1, -2)
            }
            val row = ShimmerCard(this@MainActivity, p.card, dp(16).toFloat(), p.ac).apply {
                setPadding(dp(10), dp(10), dp(12), dp(10)); gravity = Gravity.CENTER_VERTICAL
            }
            val badge = tv("", 13f, p.sub, true).apply { gravity = Gravity.CENTER; visibility = View.GONE }
            row.addView(badge, lp(dp(28), dp(28)).apply { rightMargin = dp(8) })
            val img = ImageView(this@MainActivity).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
            round(img, 10)
            row.addView(img, lp(dp(64), dp(64)))
            val col = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
            fun line(sz: Float, c: Int, bold: Boolean) = tv("", sz, c, bold).apply {
                maxLines = 1; ellipsize = TextUtils.TruncateAt.END
            }
            val t = line(15f, p.tx, true); val a = line(13f, p.sub, false); val i = line(12f, p.ac, false)
            col.addView(t); col.addView(a); col.addView(i)
            row.addView(col, lp(0, -2, 1f))
            wrap.addView(row)
            pressFx(wrap)
            val h = VH(img, t, a, i, badge, row, wrap)
            wrap.setOnClickListener {
                val pos = h.bindingAdapterPosition
                if (pos < 0) return@setOnClickListener
                if (selectable && selecting) toggleSel(pos, items[pos])
                else { hideKb(); details(items[pos].t) }
            }
            if (selectable) wrap.setOnLongClickListener {
                val pos = h.bindingAdapterPosition
                if (pos < 0) return@setOnLongClickListener false
                wrap.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                if (!selecting) startSelection()
                toggleSel(pos, items[pos])
                true
            }
            return h
        }
        override fun onBindViewHolder(h: VH, pos: Int) {
            val r = items[pos]; val t = r.t
            h.t.text = "${t.artist} - ${t.title}"
            h.a.text = t.album
            h.a.visibility = if (t.album.isEmpty()) View.GONE else View.VISIBLE
            val selMode = selectable && selecting
            val isSel = selMode && selection.contains(t.ts)
            h.card.setSel(isSel)
            if (r.plays > 0) {
                h.i.text = "${fmtDur(t.dur)}  •  ${r.plays} ${times(r.plays)}  •  ${fmt.format(Date(t.ts))}"
                h.card.setMetal(metalOf(r.rank))
            } else {
                h.i.text = "${fmtDur(t.dur)}  •  ${fmt.format(Date(t.ts))}"
                h.card.setMetal(0)
            }
            if (selMode) { h.b.visibility = View.VISIBLE; styleCheck(h.b, isSel) }
            else if (r.plays > 0) { h.b.visibility = View.VISIBLE; styleBadge(h.b, r.rank) }
            else h.b.visibility = View.GONE
            bindCover(h.img, t.cover)
            val v = h.itemView
            v.animate().cancel()
            if (pos > lastAnim) {
                lastAnim = pos
                v.alpha = 0f; v.translationY = dp(26).toFloat()
                v.animate().alpha(1f).translationY(0f).setDuration(340).setStartDelay(minOf(pos, 6) * 45L)
                    .setInterpolator(DecelerateInterpolator(1.5f)).start()
            } else { v.alpha = 1f; v.translationY = 0f }
        }
    }

    private fun buildNow(): View {
        nowImg = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        round(nowImg, 12)
        nowEq = EqView(this, p.ac)
        nowStatus = tv("", 11f, p.ac, true)
        val sr = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        sr.addView(nowEq, lp(dp(16), dp(14)).apply { rightMargin = dp(8) })
        sr.addView(nowStatus)
        fun line(sz: Float, c: Int, bold: Boolean) = tv("", sz, c, bold).apply {
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        }
        nowTitle = line(15f, p.tx, true); nowSub = line(13f, p.sub, false); nowInfo = line(12f, p.sub, false)
        nowProg = Prog(this, p)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        col.addView(sr); col.addView(nowTitle); col.addView(nowSub); col.addView(nowInfo)
        col.addView(nowProg, lp(-1, dp(4)).apply { topMargin = dp(8) })
        nowCard = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(12), dp(14), dp(12))
            background = GradientDrawable().apply {
                setColor(p.card); cornerRadius = dp(18).toFloat()
                setStroke(dp(1), (p.ac and 0xFFFFFF) or (0x88 shl 24))
            }
            visibility = View.GONE
        }
        nowCard.addView(nowImg, lp(dp(64), dp(64)))
        nowCard.addView(col, lp(0, -2, 1f))
        nowKey = ""; lastCover = null
        return nowCard
    }

    private fun updateNow() {
        if (!::nowCard.isInitialized || !::histPage.isInitialized) return
        val show = Now.active
        if (show != (nowCard.visibility == View.VISIBLE)) {
            TransitionManager.beginDelayedTransition(histPage)
            nowCard.visibility = if (show) View.VISIBLE else View.GONE
        }
        if (!show) return
        val changed = Now.key != nowKey
        if (changed) {
            nowKey = Now.key
            nowTitle.text = "${Now.artist} - ${Now.title}"
            nowSub.text = Now.album
            nowSub.visibility = if (Now.album.isEmpty()) View.GONE else View.VISIBLE
            lastCover = null
            val fileCover = db.coverDir.listFiles { f -> f.name.startsWith(Now.coverBase + ".") }?.firstOrNull()?.name ?: ""
            bindCover(nowImg, fileCover)
        }
        val cv = Now.cover
        if (cv != null && cv !== lastCover) { lastCover = cv; nowImg.tag = "live"; nowImg.setImageBitmap(cv) }
        nowEq.setPlaying(Now.playing)
        nowStatus.text = if (Now.playing) "СЕЙЧАС ИГРАЕТ" else "НА ПАУЗЕ"
        nowInfo.text = "${fmtDur(Now.pos)} / ${fmtDur(Now.dur)}  •  " +
            if (Now.done) "✓ записан в историю" else "запишется после ${Now.threshold}%"
        nowProg.to(if (Now.dur > 0) Now.pos.toFloat() / Now.dur else 0f, changed)
    }

    private fun buildHistory(): View {
        histPage = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), 0) }
        histPage.addView(buildNow(), lp(-1, -2).apply { bottomMargin = dp(10) })
        val sr = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        search = EditText(this).apply {
            hint = "Поиск: артист, трек, альбом, жанр…"
            setHintTextColor(p.sub); setTextColor(p.tx); textSize = 15f
            setSingleLine(true); imeOptions = EditorInfo.IME_ACTION_SEARCH
            background = cardBg(24); setPadding(dp(18), dp(10), dp(18), dp(10))
            if (Build.VERSION.SDK_INT >= 29) {
                textCursorDrawable = GradientDrawable().apply { setColor(p.ac); setSize(dp(2), dp(20)) }
            }
            setOnEditorActionListener { _, _, _ -> hideKb(); true }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { applyFilter(true) }
            })
        }
        sr.addView(search, lp(0, dp(46), 1f))
        sr.addView(tv("⇅", 22f, p.ac).apply {
            background = cardBg(24); gravity = Gravity.CENTER; setOnClickListener { pickSort() }; pressFx(this)
        }, lp(dp(46), dp(46)).apply { leftMargin = dp(8) })
        histPage.addView(sr)
        countTv = tv("", 12f, p.sub).apply { setPadding(dp(6), dp(8), 0, dp(4)) }
        histPage.addView(countTv)
        histAd = Hist(true)
        histRv = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(context)
            adapter = histAd
            edgeEffectFactory = Bounce()
            clipToPadding = false; setPadding(0, 0, 0, dp(16))
            overScrollMode = View.OVER_SCROLL_ALWAYS
            setHasFixedSize(true)
            (itemAnimator as? SimpleItemAnimator)?.supportsChangeAnimations = false
        }
        emptyTv = tv("", 15f, p.sub).apply { gravity = Gravity.CENTER; setPadding(dp(24), dp(40), dp(24), 0) }
        val fl = FrameLayout(this)
        fl.addView(histRv, FrameLayout.LayoutParams(-1, -1))
        fl.addView(emptyTv, FrameLayout.LayoutParams(-1, -2))
        histPage.addView(fl, lp(-1, 0, 1f))
        return histPage
    }

    private fun pickSort() {
        hideKb()
        AlertDialog.Builder(this).setTitle("Сортировка")
            .setSingleChoiceItems(sortNames, sortIdx) { d, i ->
                sortIdx = i; pr.edit().putInt("sort", i).apply()
                histAd.lastAnim = -1
                applyFilter(true); d.dismiss()
            }.show()
    }

    // ---------- карточка трека ----------
    private fun details(t: Track) {
        Thread {
            val bm = loadCap(t.cover, 2048)
            runOnUiThread { showDetails(t, bm) }
        }.start()
    }

    private fun showDetails(t: Track, bm: Bitmap?) {
        val sv = ScrollView(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(8)) }
        if (bm != null) {
            col.addView(ImageView(this).apply {
                adjustViewBounds = true; setImageBitmap(bm)
                round(this, 12)
                setOnClickListener { zoom(t.cover, bm) }
            }, lp(-1, -2).apply { bottomMargin = dp(4) })
            col.addView(tv("нажми на обложку, чтобы рассмотреть", 11f, p.sub))
        }
        col.addView(tv("${t.artist} - ${t.title}", 18f, p.tx, true).apply { setPadding(0, dp(12), 0, dp(8)) })
        fun row(l: String, v: String) {
            col.addView(tv(l, 12f, p.sub).apply { setPadding(0, dp(8), 0, 0) })
            col.addView(tv(v, 15f, p.tx).apply { setTextIsSelectable(true) })
        }
        row("Прослушан", fmt.format(Date(t.ts)))
        val n = counts[keyOf(t)] ?: 1
        row("Всего прослушиваний", "$n ${times(n)}")
        row("Длительность", fmtDur(t.dur))
        for (k in t.tags.keys()) {
            if (k == "DURATION" || k in HIDDEN) continue
            row(TAGN[k] ?: k, t.tags.get(k).toString())
        }
        sv.addView(col)
        val d = AlertDialog.Builder(this).setView(sv).setPositiveButton("Закрыть", null)
            .setNeutralButton("Удалить запись") { _, _ ->
                confirmDelete(listOf(t.ts), "Удалить эту запись из истории? Это нельзя отменить.")
            }.create()
        d.window?.setBackgroundDrawable(cardBg(20))
        d.show()
        d.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(p.ac)
        d.getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(0xFFFF5252.toInt())
    }

    private fun zoom(name: String, small: Bitmap) {
        Thread {
            val big = loadCap(name, 3072) ?: small
            runOnUiThread {
                val z = ZoomView(this)
                z.setBackgroundColor(Color.BLACK)
                z.setImageBitmap(big)
                Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen).apply { setContentView(z); show() }
            }
        }.start()
    }

    // ---------- Статистика ----------
    private fun buildStats(): View {
        statCards.clear()
        val sv = ScrollView(this).apply { overScrollMode = View.OVER_SCROLL_ALWAYS; isVerticalScrollBarEnabled = false }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(2), dp(12), dp(24)) }
        fun card() = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = cardBg(20); setPadding(dp(18), dp(16), dp(18), dp(16))
        }
        fun add(v: View) { v.alpha = 0f; statCards.add(v); col.addView(v, lp(-1, -2).apply { topMargin = dp(10) }) }

        val hero = card()
        hero.addView(tv("Общее время прослушивания", 13f, p.sub))
        stTime = tv("—", 32f, p.ac, true); hero.addView(stTime)
        add(hero)

        val a = card(); a.addView(tv("Треков", 13f, p.sub))
        stTracks = tv("0", 26f, p.tx, true); a.addView(stTracks)
        val b = card(); b.addView(tv("Артистов", 13f, p.sub))
        stArtists = tv("0", 26f, p.tx, true); b.addView(stArtists)
        val tiles = LinearLayout(this)
        tiles.addView(a, lp(0, -2, 1f).apply { rightMargin = dp(5) })
        tiles.addView(b, lp(0, -2, 1f).apply { leftMargin = dp(5) })
        add(tiles)

        // неделя
        val w = card()
        w.addView(tv("Активность по неделям", 13f, p.sub))
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val left = tv("‹", 32f, p.ac).apply { setPadding(dp(12), 0, dp(12), 0); setOnClickListener { shiftWeek(-1) } }
        wkRight = tv("›", 32f, p.ac).apply { setPadding(dp(12), 0, dp(12), 0); setOnClickListener { shiftWeek(1) } }
        wkSub = tv("", 12f, p.sub).apply { gravity = Gravity.CENTER }
        wkTitle = tv("", 17f, p.tx, true).apply { gravity = Gravity.CENTER }
        val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        mid.addView(wkSub, lp(-1, -2)); mid.addView(wkTitle, lp(-1, -2))
        head.addView(left); head.addView(mid, lp(0, -2, 1f)); head.addView(wkRight)
        w.addView(head, lp(-1, -2).apply { topMargin = dp(6) })
        wkChart = WeekChart(this, p)
        w.addView(wkChart, lp(-1, dp(180)).apply { topMargin = dp(8) })
        wkTotal = tv("", 13f, p.sub).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) }
        w.addView(wkTotal, lp(-1, -2))
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onFling(a: MotionEvent?, b: MotionEvent, vx: Float, vy: Float): Boolean {
                if (a == null) return false
                val dx = b.x - a.x; val dy = b.y - a.y
                if (Math.abs(dx) > dp(50) && Math.abs(dx) > Math.abs(dy) * 1.2f) { shiftWeek(if (dx > 0) -1 else 1); return true }
                return false
            }
        })
        var sx = 0f; var sy = 0f
        w.setOnTouchListener { v, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) { sx = e.x; sy = e.y; v.parent.requestDisallowInterceptTouchEvent(true) }
            else if (e.actionMasked == MotionEvent.ACTION_MOVE &&
                Math.abs(e.y - sy) > Math.abs(e.x - sx) && Math.abs(e.y - sy) > dp(12)) {
                v.parent.requestDisallowInterceptTouchEvent(false)
            }
            gd.onTouchEvent(e)
            true
        }
        add(w)

        // время суток
        val dc = card()
        dc.addView(tv("Активность по времени суток", 13f, p.sub))
        val drow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        dayDonut = DayDonut(this, p)
        drow.addView(dayDonut, lp(dp(150), dp(150)))
        dayLegend = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        drow.addView(dayLegend, lp(0, -2, 1f).apply { leftMargin = dp(16) })
        dc.addView(drow, lp(-1, -2).apply { topMargin = dp(8) })
        dayInsight = tv("", 14f, p.ac, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, 0) }
        dc.addView(dayInsight, lp(-1, -2))
        add(dc)

        // жанры
        val g = card()
        g.addView(tv("Любимые жанры", 13f, p.sub))
        genBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        g.addView(genBox, lp(-1, -2).apply { topMargin = dp(6) })
        add(g)

        // топ треков
        val tt = card()
        tt.addView(tv("Топ-5 треков", 13f, p.sub))
        topBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tt.addView(topBox, lp(-1, -2).apply { topMargin = dp(8) })
        add(tt)

        sv.addView(col)
        return sv
    }

    private fun playStatsIn() {
        statCards.forEachIndexed { i, v ->
            v.animate().cancel()
            v.alpha = 0f; v.translationY = dp(30).toFloat()
            v.animate().alpha(1f).translationY(0f).setStartDelay(i * 80L).setDuration(420)
                .setInterpolator(DecelerateInterpolator(1.6f)).start()
        }
        updateStats()
        countUp(stTime, all.sumOf { it.dur }) { hm(it) }
        countUp(stTracks, all.size.toLong()) { it.toString() }
        countUp(stArtists, all.map { it.artist.trim().lowercase() }.toSet().size.toLong()) { it.toString() }
    }

    private fun shiftWeek(d: Int) {
        if (weekOffset + d > 0) return
        weekOffset += d
        val shift = wkChart.width * 0.35f * d
        wkChart.animate().translationX(-shift).alpha(0f).setDuration(110).withEndAction {
            updateWeek()
            wkChart.translationX = shift
            wkChart.animate().translationX(0f).alpha(1f).setDuration(170).start()
        }.start()
    }

    private fun dayIdx(c: Calendar) = (c.get(Calendar.DAY_OF_WEEK) + 5) % 7

    private fun updateWeek() {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        cal.add(Calendar.DAY_OF_YEAR, -dayIdx(cal))
        cal.add(Calendar.DAY_OF_YEAR, weekOffset * 7)
        val start = cal.timeInMillis
        cal.add(Calendar.DAY_OF_YEAR, 7)
        val end = cal.timeInMillis
        val vals = FloatArray(7)
        var sum = 0L
        val c2 = Calendar.getInstance()
        for (t in all) {
            if (t.ts < start || t.ts >= end) continue
            c2.timeInMillis = t.ts
            vals[dayIdx(c2)] += t.dur / 3600000f
            sum += t.dur
        }
        val today = if (weekOffset == 0) dayIdx(Calendar.getInstance()) else -1
        wkChart.set(vals, today)
        val f1 = SimpleDateFormat("d MMM", Locale.getDefault())
        val f2 = SimpleDateFormat("d MMM yyyy", Locale.getDefault())
        wkTitle.text = "${f1.format(Date(start))} – ${f2.format(Date(end - 1))}"
        wkSub.text = when (weekOffset) { 0 -> "Эта неделя"; -1 -> "Прошлая неделя"; else -> "${-weekOffset} нед. назад" }
        wkTotal.text = "Всего за неделю: ${hm(sum)}  •  часы по дням"
        wkRight.alpha = if (weekOffset == 0) 0.25f else 1f
    }

    private fun topRow(r: Row): View {
        val row = ShimmerCard(this, p.bg, dp(14).toFloat(), p.ac).apply {
            setPadding(dp(10), dp(8), dp(12), dp(8)); gravity = Gravity.CENTER_VERTICAL
            setMetal(metalOf(r.rank))
        }
        val badge = tv("", 13f, p.sub, true).apply { gravity = Gravity.CENTER }
        styleBadge(badge, r.rank)
        row.addView(badge, lp(dp(28), dp(28)).apply { rightMargin = dp(10) })
        val img = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        round(img, 8)
        bindCover(img, r.t.cover)
        row.addView(img, lp(dp(46), dp(46)))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, dp(6), 0) }
        col.addView(tv("${r.t.artist} - ${r.t.title}", 14f, p.tx, true).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
        if (r.t.album.isNotEmpty()) col.addView(tv(r.t.album, 12f, p.sub).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
        row.addView(col, lp(0, -2, 1f))
        row.addView(tv("${r.plays} ${times(r.plays)}", 13f, p.ac, true))
        row.setOnClickListener { details(r.t) }
        pressFx(row)
        return row
    }

    private fun updateStats() {
        if (!::stTime.isInitialized) return
        stTime.text = hm(all.sumOf { it.dur })
        stTracks.text = all.size.toString()
        stArtists.text = all.map { it.artist.trim().lowercase() }.toSet().size.toString()
        updateWeek()

        // время суток
        val per = IntArray(4)
        val c3 = Calendar.getInstance()
        for (t in all) {
            c3.timeInMillis = t.ts
            val hr = c3.get(Calendar.HOUR_OF_DAY)
            per[when { hr in 6..11 -> 0; hr in 12..17 -> 1; hr in 18..23 -> 2; else -> 3 }]++
        }
        dayDonut.set(per)
        dayLegend.removeAllViews()
        val names = arrayOf("Утро", "День", "Вечер", "Ночь")
        val ranges = arrayOf("6–12", "12–18", "18–24", "0–6")
        val total = per.sum()
        for (i in 0..3) {
            val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(5), 0, dp(5)) }
            r.addView(View(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(dayDonut.colors[i]) }
            }, lp(dp(10), dp(10)).apply { rightMargin = dp(10) })
            val nm = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            nm.addView(tv(names[i], 14f, p.tx, true)); nm.addView(tv(ranges[i] + " ч", 11f, p.sub))
            r.addView(nm, lp(0, -2, 1f))
            r.addView(tv(if (total > 0) "${per[i] * 100 / total}%" else "0%", 14f, p.tx, true))
            dayLegend.addView(r)
        }
        if (total > 0) {
            var best = 0
            for (i in 1..3) if (per[i] > per[best]) best = i
            val ph = arrayOf("🌅 Чаще всего ты слушаешь музыку утром", "☀️ Чаще всего ты слушаешь музыку днём",
                "🌇 Чаще всего ты слушаешь музыку вечером", "🌙 Чаще всего ты слушаешь музыку ночью")
            dayInsight.text = ph[best]
        } else dayInsight.text = "Пока нет данных"

        // жанры
        genBox.removeAllViews()
        val cnt = HashMap<String, Int>()
        for (t in all) for (g in t.genres) {
            val k = g.lowercase().replaceFirstChar { it.uppercase() }
            cnt[k] = (cnt[k] ?: 0) + 1
        }
        val top = cnt.entries.sortedByDescending { it.value }.take(5)
        if (top.isEmpty()) {
            genBox.addView(tv("Нет данных: в тегах прослушанных треков не указан жанр.", 14f, p.sub))
        } else {
            val mx = top[0].value
            val track = (p.tx and 0xFFFFFF) or (0x22 shl 24)
            for (e in top) {
                val r = LinearLayout(this).apply { setPadding(0, dp(8), 0, dp(4)) }
                r.addView(tv(e.key, 15f, p.tx), lp(0, -2, 1f))
                r.addView(tv("${e.value * 100 / all.size}%", 13f, p.sub))
                genBox.addView(r)
                val bar = LinearLayout(this).apply {
                    background = GradientDrawable().apply { setColor(track); cornerRadius = dp(4).toFloat() }
                }
                bar.addView(View(this).apply {
                    background = GradientDrawable().apply { setColor(p.ac); cornerRadius = dp(4).toFloat() }
                }, lp(0, dp(8), e.value.toFloat()))
                bar.addView(View(this), lp(0, dp(8), (mx - e.value).toFloat()))
                genBox.addView(bar, lp(-1, dp(8)))
            }
        }

        // топ треков
        topBox.removeAllViews()
        if (agg.isEmpty()) topBox.addView(tv("Пока нет прослушанных треков.", 14f, p.sub))
        else for (r in agg.take(5)) topBox.addView(topRow(r), lp(-1, -2).apply { topMargin = dp(6) })
    }

    // ---------- музыкальный календарь ----------
    private fun trWord(n: Int) = if (n % 100 in 11..14) "треков" else when (n % 10) { 1 -> "трек"; 2, 3, 4 -> "трека"; else -> "треков" }

    private fun closeCalendar() { inCalendar = false; setContentView(mainRoot); enter(mainRoot, -1) }

    private fun showCalendar() {
        hideKb()
        inCalendar = true
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(4), dp(12), 0); setBackgroundColor(p.bg) }
        col.addView(tv("‹ Назад", 18f, p.ac).apply { setPadding(dp(4), dp(10), 0, dp(6)); setOnClickListener { closeCalendar() } })
        col.addView(tv("Музыкальный календарь", 22f, p.tx, true).apply { setPadding(dp(4), 0, 0, dp(8)) })
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = cardBg(20); setPadding(dp(10), dp(12), dp(10), dp(8)) }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(tv("‹", 30f, p.ac).apply { setPadding(dp(14), 0, dp(14), 0); setOnClickListener { shiftMonth(-1) } })
        calMonthTv = tv("", 18f, p.tx, true).apply { gravity = Gravity.CENTER }
        calSubTv = tv("", 12f, p.sub).apply { gravity = Gravity.CENTER }
        val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        mid.addView(calMonthTv, lp(-1, -2)); mid.addView(calSubTv, lp(-1, -2))
        head.addView(mid, lp(0, -2, 1f))
        head.addView(tv("›", 30f, p.ac).apply { setPadding(dp(14), 0, dp(14), 0); setOnClickListener { shiftMonth(1) } })
        card.addView(head)
        calView = CalView(this, p).apply {
            onPick = { day -> calDay = day; refreshCalendar(true) }
            onSwipe = { dir -> shiftMonth(dir) }
        }
        card.addView(calView, lp(-1, -2).apply { topMargin = dp(6) })
        col.addView(card)
        calDayTv = tv("", 15f, p.tx, true).apply { setPadding(dp(6), dp(14), 0, dp(6)) }
        col.addView(calDayTv)
        calAd = Hist(false)
        calRv = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(context)
            adapter = calAd
            edgeEffectFactory = Bounce()
            clipToPadding = false; setPadding(0, 0, 0, dp(16))
            overScrollMode = View.OVER_SCROLL_ALWAYS
        }
        calEmpty = tv("", 14f, p.sub).apply { gravity = Gravity.CENTER; setPadding(dp(24), dp(30), dp(24), 0) }
        val fl = FrameLayout(this)
        fl.addView(calRv, FrameLayout.LayoutParams(-1, -1))
        fl.addView(calEmpty, FrameLayout.LayoutParams(-1, -2))
        col.addView(fl, lp(-1, 0, 1f))
        setContentView(col)
        enter(col, 1)
        refreshCalendar(false)
    }

    private fun shiftMonth(dm: Int) {
        calMonth += dm
        if (calMonth < 0) { calMonth = 11; calYear-- } else if (calMonth > 11) { calMonth = 0; calYear++ }
        val sh = calView.width * 0.3f * dm
        calView.animate().translationX(-sh).alpha(0f).setDuration(110).withEndAction {
            refreshCalendar(true)
            calView.translationX = sh
            calView.animate().translationX(0f).alpha(1f).setDuration(170).start()
        }.start()
    }

    private fun refreshCalendar(animate: Boolean) {
        if (!::calView.isInitialized) return
        val cal = Calendar.getInstance()
        cal.clear(); cal.set(calYear, calMonth, 1)
        val dim = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        calDay = calDay.coerceIn(1, dim)
        val start = cal.timeInMillis
        cal.add(Calendar.MONTH, 1)
        val end = cal.timeInMillis
        val cnt = IntArray(32)
        var total = 0
        val c2 = Calendar.getInstance()
        for (t in all) {
            if (t.ts < start || t.ts >= end) continue
            c2.timeInMillis = t.ts
            cnt[c2.get(Calendar.DAY_OF_MONTH)]++; total++
        }
        val now = Calendar.getInstance()
        val tod = if (now.get(Calendar.YEAR) == calYear && now.get(Calendar.MONTH) == calMonth) now.get(Calendar.DAY_OF_MONTH) else 0
        calView.setData(calYear, calMonth, cnt, calDay, tod)
        calMonthTv.text = SimpleDateFormat("LLLL yyyy", Locale.getDefault()).format(Date(start)).replaceFirstChar { it.uppercase() }
        calSubTv.text = if (total == 0) "в этом месяце пока тихо" else "прослушиваний за месяц: $total"
        cal.clear(); cal.set(calYear, calMonth, calDay)
        val ds = cal.timeInMillis
        cal.add(Calendar.DAY_OF_YEAR, 1)
        val de = cal.timeInMillis
        val rows = all.filter { it.ts in ds until de }.sortedBy { it.ts }.map { Row(it, 0, 0) }
        if (animate) calAd.lastAnim = -1
        calAd.items = rows
        calAd.notifyDataSetChanged()
        calDayTv.text = SimpleDateFormat("d MMMM, EEEE", Locale.getDefault()).format(Date(ds)) + "  •  ${rows.size} ${trWord(rows.size)}"
        calEmpty.text = "В этот день музыка не записывалась"
        calEmpty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
    }

    // ---------- настройки ----------
    private fun btn(t: String, a: () -> Unit) = tv(t, 16f, p.tx).apply {
        background = cardBg(); setPadding(dp(16), dp(14), dp(16), dp(14)); setOnClickListener { a() }; pressFx(this)
    }

    private fun closeSettings() { inSettings = false; setContentView(mainRoot); enter(mainRoot, -1) }

    private fun showSettings() {
        hideKb()
        inSettings = true
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(24)) }
        fun add(v: View) = col.addView(v, lp(-1, -2).apply { topMargin = dp(10) })
        col.addView(tv("‹ Назад", 18f, p.ac).apply { setPadding(0, dp(8), 0, dp(8)); setOnClickListener { closeSettings() } })
        col.addView(tv("Настройки", 24f, p.tx, true))

        val th = pr.getInt("th", 60)
        val lbl = tv("Порог прослушивания: $th%", 16f, p.tx)
        add(lbl)
        add(SeekBar(this).apply {
            max = 100; progress = th
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) {
                    lbl.text = "Порог прослушивания: $v%"; pr.edit().putInt("th", v).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        add(tv("С какого процента трек считается прослушанным и попадает в историю (0–100).", 12f, p.sub))

        add(btn("Тема оформления: ${p.n}") {
            AlertDialog.Builder(this).setItems(PALS.map { it.n }.toTypedArray()) { _, i ->
                pr.edit().putInt("theme", i).apply(); applyTheme(); buildMain(); showSettings()
            }.show()
        })
        add(btn("Создать бэкап") {
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "application/zip"
                putExtra(Intent.EXTRA_TITLE, "aimp-history-" + SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date()) + ".zip")
            }, 1)
        })
        add(btn("Восстановить из бэкапа") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            }, 2)
        })
        add(btn("Доступ к уведомлениям") {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        })
        add(btn("Удалить всю историю") {
            AlertDialog.Builder(this).setMessage("Удалить всю историю прослушиваний? Это нельзя отменить.")
                .setPositiveButton("Удалить") { _, _ -> db.clear(); cache.evictAll(); toast("История удалена") }
                .setNegativeButton("Отмена", null).show()
        }.apply { setTextColor(0xFFFF5252.toInt()) })

        val sv = ScrollView(this).apply { setBackgroundColor(p.bg); addView(col) }
        setContentView(sv)
        enter(sv, 1)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        val uri = data?.data ?: return
        if (res != RESULT_OK) return
        if (rc == 1) Thread {
            try {
                contentResolver.openOutputStream(uri)!!.use { o ->
                    ZipOutputStream(o).use { z ->
                        z.putNextEntry(ZipEntry("history.json")); z.write(db.toJson().toByteArray()); z.closeEntry()
                        db.coverDir.listFiles()?.forEach { f ->
                            z.putNextEntry(ZipEntry("covers/" + f.name)); f.inputStream().use { it.copyTo(z) }; z.closeEntry()
                        }
                    }
                }
                toast("Бэкап сохранён")
            } catch (e: Exception) { toast("Ошибка: ${e.message}") }
        }.start()
        if (rc == 2) Thread {
            try {
                var json: String? = null
                ZipInputStream(contentResolver.openInputStream(uri)!!).use { z ->
                    var e = z.nextEntry
                    while (e != null) {
                        val n = e.name
                        if (n == "history.json") json = z.readBytes().toString(Charsets.UTF_8)
                        else if (n.startsWith("covers/") && !e.isDirectory)
                            File(db.coverDir, File(n).name).outputStream().use { z.copyTo(it) }
                        e = z.nextEntry
                    }
                }
                if (json == null) throw Exception("в архиве нет history.json")
                db.restore(json!!)
                cache.evictAll()
                toast("История восстановлена")
            } catch (e: Exception) { toast("Ошибка: ${e.message}") }
        }.start()
    }
}
