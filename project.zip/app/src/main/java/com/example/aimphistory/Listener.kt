package com.example.aimphistory

import android.content.ComponentName
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import org.json.JSONObject
import java.io.File

class Listener : NotificationListenerService() {
    private val h = Handler(Looper.getMainLooper())
    private var msm: MediaSessionManager? = null
    private var ctrl: MediaController? = null
    private var meta: MediaMetadata? = null
    private var key = ""
    private var played = 0L
    private var done = false
    private var lastPos = 0L

    private val cb = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) { newTrack(metadata) }
        override fun onPlaybackStateChanged(state: PlaybackState?) { refreshNow() }
    }
    private val sl = MediaSessionManager.OnActiveSessionsChangedListener { pick(it) }

    private fun curPos(st: PlaybackState): Long =
        if (st.state == PlaybackState.STATE_PLAYING)
            st.position + ((SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * st.playbackSpeed).toLong()
        else st.position

    private val tick = object : Runnable {
        override fun run() {
            val st = ctrl?.playbackState
            if (st != null && st.state == PlaybackState.STATE_PLAYING) {
                played += 1000
                val pos = curPos(st)
                // трек запущен заново (повтор) — считаем как новое прослушивание
                if (done && pos < 2000 && lastPos > 5000) { played = 0; done = false }
                lastPos = pos
                check()
            }
            refreshNow()
            h.postDelayed(this, 1000)
        }
    }

    override fun onListenerConnected() {
        val m = getSystemService(MediaSessionManager::class.java)
        msm = m
        val cn = ComponentName(this, Listener::class.java)
        m.addOnActiveSessionsChangedListener(sl, cn, h)
        pick(m.getActiveSessions(cn))
        h.removeCallbacks(tick); h.post(tick)
    }

    override fun onListenerDisconnected() {
        msm?.removeOnActiveSessionsChangedListener(sl)
        ctrl?.unregisterCallback(cb); ctrl = null
        h.removeCallbacks(tick)
        Now.active = false; Now.playing = false; Now.push()
    }

    private fun pick(list: List<MediaController>?) {
        val c = list?.firstOrNull { it.packageName.startsWith("com.aimp") }
        if (c?.sessionToken == ctrl?.sessionToken) return
        ctrl?.unregisterCallback(cb)
        ctrl = c
        c?.registerCallback(cb, h)
        newTrack(c?.metadata)
    }

    private fun artistOf(m: MediaMetadata) = m.getString(MediaMetadata.METADATA_KEY_ARTIST)
        ?: m.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: "Неизвестный артист"

    private fun titleOf(m: MediaMetadata) = m.getString(MediaMetadata.METADATA_KEY_TITLE)
        ?: m.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: "Без названия"

    private fun md5(s: String) = java.security.MessageDigest.getInstance("MD5")
        .digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    // одна обложка на альбом артиста
    private fun coverBase(m: MediaMetadata): String {
        val artist = artistOf(m)
        val album = m.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: ""
        val albumArtist = m.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: artist
        val key = if (album.isNotBlank()) "$albumArtist|$album" else "$artist|${titleOf(m)}"
        return "c_" + md5(key.lowercase())
    }

    private fun newTrack(m: MediaMetadata?) {
        meta = m
        if (m == null) { key = ""; refreshNow(); return }
        val k = listOf(MediaMetadata.METADATA_KEY_ARTIST, MediaMetadata.METADATA_KEY_TITLE, MediaMetadata.METADATA_KEY_ALBUM)
            .joinToString("|") { m.getString(it) ?: "" } + "|" + m.getLong(MediaMetadata.METADATA_KEY_DURATION)
        if (k != key) { key = k; played = 0; done = false; lastPos = 0 }
        refreshNow()
    }

    private fun refreshNow() {
        val st = ctrl?.playbackState
        val m = meta
        val s = st?.state ?: PlaybackState.STATE_NONE
        Now.active = ctrl != null && m != null && (s == PlaybackState.STATE_PLAYING ||
            s == PlaybackState.STATE_PAUSED || s == PlaybackState.STATE_BUFFERING)
        Now.playing = s == PlaybackState.STATE_PLAYING
        if (m != null) {
            Now.key = key
            Now.artist = artistOf(m)
            Now.title = titleOf(m)
            Now.album = m.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: ""
            Now.dur = m.getLong(MediaMetadata.METADATA_KEY_DURATION)
            Now.cover = m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: m.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: m.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
            Now.coverBase = coverBase(m)
        }
        Now.pos = if (st != null) maxOf(0L, curPos(st)) else 0L
        Now.done = done
        Now.threshold = getSharedPreferences("p", 0).getInt("th", 60)
        Now.push()
    }

    private fun check() {
        val m = meta ?: return
        if (done) return
        val th = getSharedPreferences("p", 0).getInt("th", 60)
        val d = m.getLong(MediaMetadata.METADATA_KEY_DURATION)
        if (th > 0 && d <= 0) return
        var need = d * th / 100
        if (th == 100) need = maxOf(0L, d - 1500)
        if (played >= need) { done = true; record(m) }
    }

    private fun record(m: MediaMetadata) {
        val db = Db.get(this)
        val ts = System.currentTimeMillis()
        val tags = JSONObject()
        for (k in m.keySet()) {
            if (k.endsWith(".ART") || k.endsWith("ALBUM_ART") || k.endsWith("DISPLAY_ICON")) continue
            val name = k.removePrefix("android.media.metadata.")
            if (name in HIDDEN) continue
            val s = m.getText(k)?.toString()
            if (s != null) tags.put(name, s) else {
                val n = m.getLong(k)
                if (n != 0L) tags.put(name, n)
            }
        }
        val base = coverBase(m)
        var cover = db.coverDir.listFiles { f -> f.name.startsWith("$base.") && !f.name.endsWith(".tmp") }
            ?.firstOrNull()?.name ?: ""
        if (cover.isEmpty()) {
            val tmp = File(db.coverDir, "$base.tmp")
            try {
                val uri = listOf("android.media.metadata.ALBUM_ART_URI", "android.media.metadata.ART_URI",
                    "android.media.metadata.DISPLAY_ICON_URI").firstNotNullOfOrNull { m.getString(it) }
                if (uri != null) {
                    contentResolver.openInputStream(Uri.parse(uri))?.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                    if (tmp.length() > 0 && tmp.renameTo(File(db.coverDir, "$base.img"))) cover = "$base.img"
                }
            } catch (e: Exception) { }
            if (cover.isEmpty()) {
                val bm = m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                    ?: m.getBitmap(MediaMetadata.METADATA_KEY_ART)
                    ?: m.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
                if (bm != null) {
                    tmp.outputStream().use { bm.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
                    if (tmp.renameTo(File(db.coverDir, "$base.png"))) cover = "$base.png"
                }
            }
            if (tmp.exists()) tmp.delete()
        }
        db.add(Track(ts, artistOf(m), titleOf(m), m.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: "",
            m.getLong(MediaMetadata.METADATA_KEY_DURATION), cover, tags))
    }
}
