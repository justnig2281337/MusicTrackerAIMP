package com.example.aimphistory

import android.content.ComponentName
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import org.json.JSONObject
import java.io.File

class Listener : NotificationListenerService() {
    private val h = Handler(Looper.getMainLooper())
    private var msm: MediaSessionManager? = null
    private var ctrl: MediaController? = null
    private var meta: MediaMetadata? = null
    private var key = ""
    private var played = 0L
    private var done = false
    private var lastPos = 0L

    private val cb = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) { newTrack(metadata) }
    }
    private val sl = MediaSessionManager.OnActiveSessionsChangedListener { pick(it) }

    private val tick = object : Runnable {
        override fun run() {
            val c = ctrl
            val st = c?.playbackState
            if (c != null && st != null && st.state == PlaybackState.STATE_PLAYING) {
                played += 1000
                val pos = st.position + ((SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * st.playbackSpeed).toLong()
                // трек запущен заново (повтор) — считаем как новое прослушивание
                if (done && pos < 2000 && lastPos > 5000) { played = 0; done = false }
                lastPos = pos
                check()
            }
            h.postDelayed(this, 1000)
        }
    }

    override fun onListenerConnected() {
        val m = getSystemService(MediaSessionManager::class.java)
        msm = m
        val cn = ComponentName(this, Listener::class.java)
        m.addOnActiveSessionsChangedListener(sl, cn, h)
        pick(m.getActiveSessions(cn))
        h.removeCallbacks(tick); h.post(tick)
    }

    override fun onListenerDisconnected() {
        msm?.removeOnActiveSessionsChangedListener(sl)
        ctrl?.unregisterCallback(cb); ctrl = null
        h.removeCallbacks(tick)
    }

    private fun pick(list: List<MediaController>?) {
        val c = list?.firstOrNull { it.packageName.startsWith("com.aimp") }
        if (c?.sessionToken == ctrl?.sessionToken) return
        ctrl?.unregisterCallback(cb)
        ctrl = c
        c?.registerCallback(cb, h)
        newTrack(c?.metadata)
    }

    private fun newTrack(m: MediaMetadata?) {
        meta = m
        if (m == null) { key = ""; return }
        val k = listOf(MediaMetadata.METADATA_KEY_ARTIST, MediaMetadata.METADATA_KEY_TITLE, MediaMetadata.METADATA_KEY_ALBUM)
            .joinToString("|") { m.getString(it) ?: "" } + "|" + m.getLong(MediaMetadata.METADATA_KEY_DURATION)
        if (k == key) return
        key = k; played = 0; done = false; lastPos = 0
    }

    private fun check() {
        val m = meta ?: return
        if (done) return
        val th = getSharedPreferences("p", 0).getInt("th", 60)
        val d = m.getLong(MediaMetadata.METADATA_KEY_DURATION)
        if (th > 0 && d <= 0) return
        var need = d * th / 100
        if (th == 100) need = maxOf(0L, d - 1500)
        if (played >= need) { done = true; record(m) }
    }

    private fun md5(s: String) = java.security.MessageDigest.getInstance("MD5")
        .digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    private fun record(m: MediaMetadata) {
        val db = Db.get(this)
        val ts = System.currentTimeMillis()
        val tags = JSONObject()
        for (k in m.keySet()) {
            if (k.endsWith(".ART") || k.endsWith("ALBUM_ART") || k.endsWith("DISPLAY_ICON")) continue
            val name = k.removePrefix("android.media.metadata.")
            if (name in HIDDEN) continue
            val s = m.getText(k)?.toString()
            if (s != null) tags.put(name, s) else {
                val n = m.getLong(k)
                if (n != 0L) tags.put(name, n)
            }
        }
        val artist = m.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: m.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: "Неизвестный артист"
        val title = m.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: m.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: "Без названия"
        val album = m.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: ""
        val albumArtist = m.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: artist

        // одна обложка на альбом артиста
        val key = if (album.isNotBlank()) "$albumArtist|$album" else "$artist|$title"
        val base = "c_" + md5(key.lowercase())
        var cover = db.coverDir.listFiles { f -> f.name.startsWith("$base.") && !f.name.endsWith(".tmp") }
            ?.firstOrNull()?.name ?: ""
        if (cover.isEmpty()) {
            val tmp = File(db.coverDir, "$base.tmp")
            try {
                val uri = listOf("android.media.metadata.ALBUM_ART_URI", "android.media.metadata.ART_URI",
                    "android.media.metadata.DISPLAY_ICON_URI").firstNotNullOfOrNull { m.getString(it) }
                if (uri != null) {
                    contentResolver.openInputStream(Uri.parse(uri))?.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                    if (tmp.length() > 0 && tmp.renameTo(File(db.coverDir, "$base.img"))) cover = "$base.img"
                }
            } catch (e: Exception) { }
            if (cover.isEmpty()) {
                val bm = m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                    ?: m.getBitmap(MediaMetadata.METADATA_KEY_ART)
                    ?: m.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
                if (bm != null) {
                    tmp.outputStream().use { bm.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
                    if (tmp.renameTo(File(db.coverDir, "$base.png"))) cover = "$base.png"
                }
            }
            if (tmp.exists()) tmp.delete()
        }
        db.add(Track(ts, artist, title, album, m.getLong(MediaMetadata.METADATA_KEY_DURATION), cover, tags))
    }
}
