package com.example.aimphistory

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class Track(
    val ts: Long, val artist: String, val title: String, val album: String,
    val dur: Long, val cover: String, val tags: JSONObject
)

class Db private constructor(ctx: Context) : SQLiteOpenHelper(ctx, "history.db", null, 1) {
    val coverDir = File(ctx.filesDir, "covers").also { it.mkdirs() }

    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE h(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, artist TEXT, title TEXT, album TEXT, dur INTEGER, cover TEXT, tags TEXT)")
    }

    override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {}

    private fun ins(d: SQLiteDatabase, t: Track) {
        val v = ContentValues()
        v.put("ts", t.ts); v.put("artist", t.artist); v.put("title", t.title)
        v.put("album", t.album); v.put("dur", t.dur); v.put("cover", t.cover)
        v.put("tags", t.tags.toString())
        d.insert("h", null, v)
    }

    fun add(t: Track) { ins(writableDatabase, t); changed() }

    fun all(): List<Track> {
        val l = ArrayList<Track>()
        readableDatabase.rawQuery("SELECT ts,artist,title,album,dur,cover,tags FROM h ORDER BY ts DESC", null).use { c ->
            while (c.moveToNext()) l.add(
                Track(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getString(3) ?: "",
                    c.getLong(4), c.getString(5) ?: "", JSONObject(c.getString(6) ?: "{}"))
            )
        }
        return l
    }

    fun clear() {
        writableDatabase.delete("h", null, null)
        coverDir.listFiles()?.forEach { it.delete() }
        changed()
    }

    fun toJson(): String {
        val a = JSONArray()
        for (t in all()) a.put(JSONObject().apply {
            put("ts", t.ts); put("artist", t.artist); put("title", t.title); put("album", t.album)
            put("dur", t.dur); put("cover", t.cover); put("tags", t.tags)
        })
        return a.toString()
    }

    fun restore(json: String) {
        val a = JSONArray(json)
        val d = writableDatabase
        d.beginTransaction()
        try {
            d.delete("h", null, null)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                ins(d, Track(o.getLong("ts"), o.optString("artist"), o.optString("title"), o.optString("album"),
                    o.optLong("dur"), o.optString("cover"), o.optJSONObject("tags") ?: JSONObject()))
            }
            d.setTransactionSuccessful()
        } finally { d.endTransaction() }
        changed()
    }

    companion object {
        private var inst: Db? = null
        var onChange: (() -> Unit)? = null
        @Synchronized fun get(c: Context): Db = inst ?: Db(c.applicationContext).also { inst = it }
        fun changed() { Handler(Looper.getMainLooper()).post { onChange?.invoke() } }
    }
}
