package com.example.aimphistory

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.EdgeEffect
import java.util.Calendar
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.recyclerview.widget.RecyclerView

class P(val n: String, val bg: Int, val card: Int, val tx: Int, val sub: Int, val ac: Int, val light: Boolean = false)

val PALS = listOf(
    P("Тёмная", 0xFF121212.toInt(), 0xFF1E1E1E.toInt(), 0xFFFFFFFF.toInt(), 0xFFA0A0A0.toInt(), 0xFF4FC3F7.toInt()),
    P("AMOLED", 0xFF000000.toInt(), 0xFF111111.toInt(), 0xFFFFFFFF.toInt(), 0xFF909090.toInt(), 0xFFBB86FC.toInt()),
    P("Светлая", 0xFFF2F2F7.toInt(), 0xFFFFFFFF.toInt(), 0xFF111111.toInt(), 0xFF6B6B6B.toInt(), 0xFF1976D2.toInt(), true),
    P("Синяя ночь", 0xFF0D1B2A.toInt(), 0xFF1B2B40.toInt(), 0xFFE0E1DD.toInt(), 0xFF8FA3B8.toInt(), 0xFF48CAE4.toInt()),
    P("Лесная", 0xFF10201A.toInt(), 0xFF1B3028.toInt(), 0xFFE6F2EA.toInt(), 0xFF8DB09B.toInt(), 0xFF66BB6A.toInt()),
    P("Закат", 0xFF2A1520.toInt(), 0xFF3B1F2E.toInt(), 0xFFFFE9EE.toInt(), 0xFFC99AAA.toInt(), 0xFFFF7A59.toInt())
)

val TAGN = mapOf(
    "TITLE" to "Название", "ARTIST" to "Артист", "ALBUM" to "Альбом", "ALBUM_ARTIST" to "Исполнитель альбома",
    "AUTHOR" to "Автор", "WRITER" to "Автор текста", "COMPOSER" to "Композитор", "COMPILATION" to "Компиляция",
    "GENRE" to "Жанр", "YEAR" to "Год", "DATE" to "Дата", "TRACK_NUMBER" to "Номер трека",
    "NUM_TRACKS" to "Треков в альбоме", "DISC_NUMBER" to "Диск"
)

class Row(val t: Track, val plays: Int, val rank: Int)

class VH(val img: ImageView, val t: TextView, val a: TextView, val i: TextView, val b: TextView,
         val card: ShimmerCard, root: View) : RecyclerView.ViewHolder(root)

const val GOLD = 0xFFFFC83D.toInt()
const val SILVER = 0xFFC5CDD6.toInt()
const val BRONZE = 0xFFCD7F32.toInt()
fun metalOf(r: Int) = when (r) { 1 -> GOLD; 2 -> SILVER; 3 -> BRONZE; else -> 0 }

/** Состояние «сейчас играет», которое обновляет служба. */
object Now {
    var active = false
    var playing = false
    var key = ""
    var artist = ""
    var title = ""
    var album = ""
    var dur = 0L
    var pos = 0L
    var cover: Bitmap? = null
    var coverBase = ""
    var done = false
    var threshold = 60
    var onChange: (() -> Unit)? = null
    fun push() { onChange?.invoke() }
}

fun shade(c: Int, f: Float): Int {
    fun ch(x: Int) = if (f <= 1f) (x * f).toInt() else (x + (255 - x) * (f - 1f)).toInt().coerceIn(0, 255)
    return (0xFF shl 24) or (ch((c shr 16) and 255) shl 16) or (ch((c shr 8) and 255) shl 8) or ch(c and 255)
}
fun metalLight(c: Int) = shade(c, 1.6f)
fun metalDark(c: Int) = shade(c, 0.55f)
fun lum(c: Int) = (((c shr 16) and 255) * 299 + ((c shr 8) and 255) * 587 + (c and 255) * 114) / 1000
fun al(c: Int, a: Int) = (c and 0xFFFFFF) or (a shl 24)

/** Плашка. Для призовых мест: металлический фон, острый блик «лезвия» и искра. */
class ShimmerCard(c: Context, private val bg: Int, private val r: Float, private val accent: Int) : LinearLayout(c) {
    private var metal = 0
    private var sel = false
    private val d = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val selP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val body = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val g1 = Paint(Paint.ANTI_ALIAS_FLAG)
    private val g2 = Paint(Paint.ANTI_ALIAS_FLAG)
    private val star = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val path = Path()
    private val starPath = Path()
    private val mat = Matrix()
    private var s1: LinearGradient? = null
    private var s2: LinearGradient? = null
    private var bw = 0f
    private var phase = 0f
    private var anim: ValueAnimator? = null

    fun setMetal(m: Int) {
        metal = m; rebuild()
        if (isAttachedToWindow) restart()
        invalidate()
    }

    fun setSel(b: Boolean) { if (sel != b) { sel = b; invalidate() } }

    private fun rebuild() {
        s1 = null; s2 = null
        if (metal == 0 || width == 0 || height == 0) return
        val w = width.toFloat(); val h = height.toFloat()
        val lt = metalLight(metal); val dk = metalDark(metal)
        body.shader = LinearGradient(0f, 0f, w, h, intArrayOf(al(dk, 0x58), al(lt, 0x28), al(dk, 0x48), al(lt, 0x30)),
            floatArrayOf(0f, .35f, .7f, 1f), Shader.TileMode.CLAMP)
        edge.shader = LinearGradient(0f, 0f, w, h, intArrayOf(al(lt, 0xFF), al(metal, 0xD0), al(dk, 0xD0), al(lt, 0xFF)),
            floatArrayOf(0f, .4f, .7f, 1f), Shader.TileMode.CLAMP)
        glow.shader = RadialGradient(38 * d, h / 2, w * 0.55f, al(metal, 0x46), al(metal, 0), Shader.TileMode.CLAMP)
        bw = w * 0.22f
        val core = al(shade(metal, 2f), 0xF4)
        s1 = LinearGradient(0f, 0f, bw * 0.9f, bw * 0.45f, intArrayOf(0, al(lt, 0x50), core, al(lt, 0x50), 0),
            floatArrayOf(0f, .38f, .5f, .62f, 1f), Shader.TileMode.CLAMP)
        s2 = LinearGradient(0f, 0f, bw * 0.32f, bw * 0.16f, intArrayOf(0, al(lt, 0xA0), 0),
            floatArrayOf(0f, .5f, 1f), Shader.TileMode.CLAMP)
        g1.shader = s1; g2.shader = s2
    }

    private fun restart() {
        anim?.cancel(); anim = null
        if (metal != 0) {
            anim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = when (metal) { GOLD -> 2900L; SILVER -> 3400L; else -> 3900L }
                repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
                addUpdateListener { phase = it.animatedValue as Float; invalidate() }
                start()
            }
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); restart() }
    override fun onDetachedFromWindow() { anim?.cancel(); anim = null; super.onDetachedFromWindow() }
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { super.onSizeChanged(w, h, ow, oh); rebuild() }

    override fun dispatchDraw(cv: Canvas) {
        val w = width.toFloat()
        rect.set(0f, 0f, w, height.toFloat())
        fill.color = bg
        cv.drawRoundRect(rect, r, r, fill)
        var sx = -1f
        val a = s1; val b = s2
        if (metal != 0 && a != null && b != null) {
            cv.drawRoundRect(rect, r, r, body)
            cv.drawRoundRect(rect, r, r, glow)
            val t = phase / 0.34f
            if (t < 1f) {
                val e = t * t * (3 - 2 * t)
                val x = -bw * 1.3f + (w + bw * 1.7f) * e
                cv.save()
                path.reset(); path.addRoundRect(rect, r, r, Path.Direction.CW)
                cv.clipPath(path)
                mat.setTranslate(x - bw * 0.8f, 0f); b.setLocalMatrix(mat); cv.drawRect(rect, g2)
                mat.setTranslate(x, 0f); a.setLocalMatrix(mat); cv.drawRect(rect, g1)
                cv.restore()
                sx = x + bw * 0.45f
            }
            edge.strokeWidth = 1.8f * d
            val i = edge.strokeWidth / 2
            rect.inset(i, i); cv.drawRoundRect(rect, r - i, r - i, edge); rect.inset(-i, -i)
        }
        if (sel) {
            fill.color = al(accent, 0x2E)
            cv.drawRoundRect(rect, r, r, fill)
            selP.strokeWidth = 2.2f * d; selP.color = accent
            val i = selP.strokeWidth / 2
            rect.inset(i, i); cv.drawRoundRect(rect, r - i, r - i, selP); rect.inset(-i, -i)
        }
        super.dispatchDraw(cv)
        if (sx >= 0f) {
            val px = w - 28 * d; val py = 17 * d
            val range = bw * 0.9f
            val dist = Math.abs(sx - px)
            if (dist < range) {
                val k = 1f - dist / range
                val rr = 9 * d * k + 1
                val q = rr * 0.2f
                starPath.reset()
                starPath.moveTo(px, py - rr); starPath.lineTo(px + q, py - q); starPath.lineTo(px + rr, py)
                starPath.lineTo(px + q, py + q); starPath.lineTo(px, py + rr); starPath.lineTo(px - q, py + q)
                starPath.lineTo(px - rr, py); starPath.lineTo(px - q, py - q); starPath.close()
                star.color = al(0xFFFFFF, (255 * k).toInt())
                cv.drawPath(starPath, star)
            }
        }
    }
}

/** Анимированный эквалайзер. */
class EqView(c: Context, col: Int) : View(c) {
    private val pa = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = col }
    private val rf = RectF()
    private var ph = 0f
    private var an: ValueAnimator? = null
    private var on = false

    fun setPlaying(b: Boolean) {
        if (b == on) return
        on = b
        an?.cancel(); an = null
        if (b) {
            an = ValueAnimator.ofFloat(0f, (2 * Math.PI).toFloat()).apply {
                duration = 1100; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
                addUpdateListener { ph = it.animatedValue as Float; invalidate() }
                start()
            }
        } else invalidate()
    }

    override fun onDetachedFromWindow() { an?.cancel(); an = null; on = false; super.onDetachedFromWindow() }

    override fun onDraw(cv: Canvas) {
        val n = 4
        val bw = width / (n * 2f - 1f)
        for (i in 0 until n) {
            val f = if (on) 0.25f + 0.75f * Math.abs(Math.sin((ph * (1 + i * 0.35f) + i * 1.3f).toDouble())).toFloat() else 0.3f
            val h = height * f
            rf.set(i * 2 * bw, height - h, i * 2 * bw + bw, height.toFloat())
            cv.drawRoundRect(rf, bw / 2, bw / 2, pa)
        }
    }
}

/** Тонкая полоска прогресса с плавным движением. */
class Prog(c: Context, private val p: P) : View(c) {
    private var f = 0f
    private val pa = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rf = RectF()
    private var an: ValueAnimator? = null

    fun to(v: Float, jump: Boolean) {
        an?.cancel()
        val t = v.coerceIn(0f, 1f)
        if (jump) { f = t; invalidate(); return }
        an = ValueAnimator.ofFloat(f, t).apply {
            duration = 900; interpolator = LinearInterpolator()
            addUpdateListener { f = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDraw(cv: Canvas) {
        val h = height.toFloat()
        pa.color = (p.tx and 0xFFFFFF) or (0x22 shl 24)
        rf.set(0f, 0f, width.toFloat(), h); cv.drawRoundRect(rf, h / 2, h / 2, pa)
        pa.color = p.ac
        rf.set(0f, 0f, maxOf(width * f, h), h); cv.drawRoundRect(rf, h / 2, h / 2, pa)
    }
}

/** Кольцевая диаграмма: утро / день / вечер / ночь. */
class DayDonut(c: Context, private val p: P) : View(c) {
    val colors = intArrayOf(0xFFFFB74D.toInt(), 0xFF4FC3F7.toInt(), 0xFFFF7A59.toInt(), 0xFF7E57C2.toInt())
    private val em = arrayOf("🌅", "☀️", "🌇", "🌙")
    private val nm = arrayOf("Утро", "День", "Вечер", "Ночь")
    private var cnt = IntArray(4)
    private var prog = 0f
    private val pa = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val rf = RectF()
    private val d = resources.displayMetrics.density

    fun set(v: IntArray) {
        cnt = v
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 800; interpolator = DecelerateInterpolator()
            addUpdateListener { prog = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDraw(cv: Canvas) {
        val sz = minOf(width, height).toFloat()
        val sw = 20 * d
        val cx = width / 2f; val cy = height / 2f
        rf.set(cx - sz / 2 + sw / 2 + 4 * d, cy - sz / 2 + sw / 2 + 4 * d, cx + sz / 2 - sw / 2 - 4 * d, cy + sz / 2 - sw / 2 - 4 * d)
        pa.strokeWidth = sw
        pa.color = (p.tx and 0xFFFFFF) or (0x22 shl 24)
        cv.drawArc(rf, 0f, 360f, false, pa)
        val total = cnt.sum()
        if (total > 0) {
            var start = -90f
            val gap = if (cnt.count { it > 0 } > 1) 4f else 0f
            for (i in 0..3) {
                if (cnt[i] == 0) continue
                val sweep = 360f * cnt[i] / total
                pa.color = colors[i]
                cv.drawArc(rf, start + gap / 2, maxOf(sweep - gap, 1f) * prog, false, pa)
                start += sweep
            }
            var best = 0
            for (i in 1..3) if (cnt[i] > cnt[best]) best = i
            tp.textSize = 30 * d; tp.color = p.tx
            cv.drawText(em[best], cx, cy + 6 * d, tp)
            tp.textSize = 12 * d; tp.color = p.sub
            cv.drawText(nm[best], cx, cy + 26 * d, tp)
        } else {
            tp.textSize = 22 * d; tp.color = p.sub
            cv.drawText("—", cx, cy + 8 * d, tp)
        }
    }
}

/** Упругий отскок списка, когда долистал до края. */
class Bounce : RecyclerView.EdgeEffectFactory() {
    override fun createEdgeEffect(rv: RecyclerView, direction: Int): EdgeEffect {
        return object : EdgeEffect(rv.context) {
            private val sign = if (direction == RecyclerView.EdgeEffectFactory.DIRECTION_BOTTOM) -1f else 1f
            private val anim = SpringAnimation(rv, DynamicAnimation.TRANSLATION_Y, 0f).apply {
                spring.dampingRatio = 0.45f
                spring.stiffness = 180f
            }
            private fun pull(d: Float) { anim.cancel(); rv.translationY += sign * rv.height * d * 0.2f }
            override fun onPull(d: Float) { super.onPull(d); pull(d) }
            override fun onPull(d: Float, disp: Float) { super.onPull(d, disp); pull(d) }
            override fun onRelease() { super.onRelease(); anim.start() }
            override fun onAbsorb(v: Int) { super.onAbsorb(v); anim.setStartVelocity(sign * v * 0.1f).start() }
            override fun draw(c: Canvas): Boolean = false
        }
    }
}

/** Гистограмма активности по дням недели. */
class WeekChart(c: Context, private val p: P) : View(c) {
    private var vals = FloatArray(7)
    private var today = -1
    private var prog = 1f
    private val names = arrayOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")
    private val pa = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val rf = RectF()
    private val d = resources.displayMetrics.density

    fun set(v: FloatArray, t: Int) {
        vals = v; today = t
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 500; interpolator = DecelerateInterpolator()
            addUpdateListener { prog = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val colW = w / 7
        val topH = 20 * d; val botH = 24 * d
        val areaTop = topH + 4 * d; val areaBot = h - botH
        val mx = maxOf(vals.max(), 1f)
        for (i in 0..6) {
            val cx = colW * i + colW / 2
            val bw = colW * 0.52f
            pa.color = (p.tx and 0xFFFFFF) or (0x22 shl 24)
            rf.set(cx - bw / 2, areaTop, cx + bw / 2, areaBot)
            cv.drawRoundRect(rf, bw / 2, bw / 2, pa)
            if (vals[i] > 0f) {
                val fh = (areaBot - areaTop) * (vals[i] / mx) * prog
                val top = minOf(areaBot - maxOf(fh, bw), areaBot - bw)
                pa.color = if (i == today) p.ac else (p.ac and 0xFFFFFF) or (0xB0 shl 24)
                rf.set(cx - bw / 2, top, cx + bw / 2, areaBot)
                cv.drawRoundRect(rf, bw / 2, bw / 2, pa)
            }
            tp.textSize = 11 * d
            tp.typeface = Typeface.DEFAULT
            tp.color = p.tx
            val label = if (vals[i] <= 0f) "0" else if (vals[i] < 0.1f) "<0,1" else "%.1f".format(vals[i])
            cv.drawText(label, cx, topH - 6 * d, tp)
            tp.color = if (i == today) p.ac else p.sub
            if (i == today) tp.typeface = Typeface.DEFAULT_BOLD
            cv.drawText(names[i], cx, h - 7 * d, tp)
        }
    }
}

/** Плавный зум: щипок вокруг пальцев, перемещение, двойной тап. */
class ZoomView(c: Context) : ImageView(c) {
    private val m = Matrix()
    private val v = FloatArray(9)
    private var base = 1f

    private val sd = ScaleGestureDetector(c, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            val s = cur()
            val ns = (s * d.scaleFactor).coerceIn(base, base * 8f)
            val f = ns / s
            m.postScale(f, f, d.focusX, d.focusY)
            fix()
            return true
        }
    })
    private val gd = GestureDetector(c, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent) = true
        override fun onScroll(a: MotionEvent?, b: MotionEvent, dx: Float, dy: Float): Boolean {
            m.postTranslate(-dx, -dy); fix(); return true
        }
        override fun onDoubleTap(e: MotionEvent): Boolean {
            animateTo(if (cur() > base * 1.05f) base else base * 3f, e.x, e.y); return true
        }
    })

    init {
        scaleType = ScaleType.MATRIX
        sd.isQuickScaleEnabled = false
    }

    private fun cur(): Float { m.getValues(v); return v[Matrix.MSCALE_X] }

    private fun fix() {
        val dr = drawable ?: return
        m.getValues(v)
        val sc = v[Matrix.MSCALE_X]
        val w = dr.intrinsicWidth * sc
        val h = dr.intrinsicHeight * sc
        val tx = if (w <= width) (width - w) / 2 else v[Matrix.MTRANS_X].coerceIn(width - w, 0f)
        val ty = if (h <= height) (height - h) / 2 else v[Matrix.MTRANS_Y].coerceIn(height - h, 0f)
        m.postTranslate(tx - v[Matrix.MTRANS_X], ty - v[Matrix.MTRANS_Y])
        imageMatrix = m
    }

    private fun fit() {
        val dr = drawable ?: return
        if (width == 0 || height == 0) return
        val dw = dr.intrinsicWidth.toFloat(); val dh = dr.intrinsicHeight.toFloat()
        base = minOf(width / dw, height / dh)
        m.reset()
        m.postScale(base, base)
        m.postTranslate((width - dw * base) / 2, (height - dh * base) / 2)
        imageMatrix = m
    }

    private fun animateTo(target: Float, px: Float, py: Float) {
        val s0 = cur()
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 240; interpolator = DecelerateInterpolator()
            addUpdateListener {
                val ns = s0 + (target - s0) * (it.animatedValue as Float)
                val f = ns / cur()
                m.postScale(f, f, px, py); fix()
            }
            start()
        }
    }

    override fun setImageBitmap(bm: Bitmap?) { super.setImageBitmap(bm); fit() }
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { super.onSizeChanged(w, h, ow, oh); fit() }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        sd.onTouchEvent(e); gd.onTouchEvent(e)
        return true
    }
}

/** Месячный календарь: тепловая карта прослушиваний по дням. */
class CalView(c: Context, private val p: P) : View(c) {
    var onPick: ((Int) -> Unit)? = null
    var onSwipe: ((Int) -> Unit)? = null
    private var counts = IntArray(32)
    private var selected = 0
    private var today = 0
    private var firstCol = 0
    private var days = 30
    private val d = resources.displayMetrics.density
    private val head = 26 * d
    private val rowH = 48 * d
    private val pa = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val names = arrayOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")
    private val gd = GestureDetector(c, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent) = true
        override fun onSingleTapUp(e: MotionEvent): Boolean { pick(e.x, e.y); return true }
        override fun onFling(a: MotionEvent?, b: MotionEvent, vx: Float, vy: Float): Boolean {
            if (a == null) return false
            val dx = b.x - a.x
            if (Math.abs(dx) > 60 * d && Math.abs(dx) > Math.abs(b.y - a.y) * 1.2f) { onSwipe?.invoke(if (dx > 0) -1 else 1); return true }
            return false
        }
    })

    fun setData(year: Int, month: Int, cnt: IntArray, sel: Int, tod: Int) {
        val cal = Calendar.getInstance(); cal.clear(); cal.set(year, month, 1)
        firstCol = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7
        days = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        counts = cnt; selected = sel; today = tod
        invalidate()
    }

    private fun pick(x: Float, y: Float) {
        if (y < head) return
        val col = (x / (width / 7f)).toInt().coerceIn(0, 6)
        val row = ((y - head) / rowH).toInt()
        if (row !in 0..5) return
        val day = row * 7 + col - firstCol + 1
        if (day in 1..days) { selected = day; invalidate(); onPick?.invoke(day) }
    }

    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(MeasureSpec.getSize(w), (head + 6 * rowH).toInt()) }
    override fun onTouchEvent(e: MotionEvent): Boolean { gd.onTouchEvent(e); return true }

    override fun onDraw(cv: Canvas) {
        val cw = width / 7f
        tp.typeface = Typeface.DEFAULT
        for (i in 0..6) { tp.color = p.sub; tp.textSize = 12 * d; cv.drawText(names[i], cw * i + cw / 2, head - 8 * d, tp) }
        val mx = maxOf(1, counts.max())
        val onAcc = if (lum(p.ac) > 150) 0xFF101010.toInt() else 0xFFFFFFFF.toInt()
        for (day in 1..days) {
            val idx = firstCol + day - 1
            val cx = cw * (idx % 7) + cw / 2
            val cy = head + rowH * (idx / 7) + rowH / 2
            val n = counts[day]
            val isSel = day == selected
            pa.style = Paint.Style.FILL
            if (isSel) { pa.color = p.ac; cv.drawCircle(cx, cy, 21 * d, pa) }
            else if (n > 0) { pa.color = al(p.ac, 0x30 + 0x70 * n / mx); cv.drawCircle(cx, cy, 20 * d, pa) }
            if (day == today && !isSel) {
                pa.style = Paint.Style.STROKE; pa.strokeWidth = 1.6f * d; pa.color = p.ac
                cv.drawCircle(cx, cy, 20 * d, pa)
            }
            tp.typeface = if (isSel || day == today) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            tp.textSize = 15 * d
            tp.color = if (isSel) onAcc else p.tx
            cv.drawText(day.toString(), cx, if (n > 0) cy - 1 * d else cy + 5 * d, tp)
            if (n > 0) {
                tp.typeface = Typeface.DEFAULT; tp.textSize = 9 * d
                tp.color = if (isSel) onAcc else p.sub
                cv.drawText(n.toString(), cx, cy + 14 * d, tp)
            }
        }
    }
}
