package com.example.aimphistory

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.PathInterpolator
import android.animation.ArgbEvaluator
import org.json.JSONObject
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.EdgeEffect
import java.util.Calendar
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.recyclerview.widget.RecyclerView

class P(
    val n: String, val bg: Int, val bg2: Int, val card: Int, val tx: Int, val sub: Int,
    val ac: Int, val ac2: Int, val light: Boolean = false, val rad: Int = 18, val stroke: Int = 0
)

val EASE = PathInterpolator(0.2f, 0f, 0f, 1f)

fun withA(c: Int, a: Int) = (c and 0xFFFFFF) or (a shl 24)
fun solid(c: Int) = c or (0xFF shl 24)
fun mix(a: Int, b: Int, t: Float): Int {
    fun ch(s: Int) = ((((a shr s) and 255) * (1 - t)) + (((b shr s) and 255) * t)).toInt()
    return (ch(24) shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
}
fun over(top: Int, bottom: Int): Int {
    val ta = (top ushr 24) / 255f
    fun ch(s: Int) = ((((top shr s) and 255) * ta) + (((bottom shr s) and 255) * (1 - ta))).toInt()
    return (0xFF shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
}

val PALS = listOf(
    P("Тёмная", 0xFF121212.toInt(), 0xFF171B21.toInt(), 0xFF1E1E1E.toInt(), 0xFFFFFFFF.toInt(), 0xFFA0A0A0.toInt(), 0xFF4FC3F7.toInt(), 0xFF81D4FA.toInt()),
    P("AMOLED", 0xFF000000.toInt(), 0xFF000000.toInt(), 0xFF0F0F0F.toInt(), 0xFFFFFFFF.toInt(), 0xFF909090.toInt(), 0xFFBB86FC.toInt(), 0xFFE1BEE7.toInt(), stroke = 0x22FFFFFF),
    P("Светлая", 0xFFF2F2F7.toInt(), 0xFFE6E9F2.toInt(), 0xFFFFFFFF.toInt(), 0xFF111111.toInt(), 0xFF6B6B6B.toInt(), 0xFF1976D2.toInt(), 0xFF64B5F6.toInt(), true),
    P("Синяя ночь", 0xFF0D1B2A.toInt(), 0xFF1B263B.toInt(), 0xCC1B2B40.toInt(), 0xFFE0E1DD.toInt(), 0xFF8FA3B8.toInt(), 0xFF48CAE4.toInt(), 0xFF90E0EF.toInt(), stroke = 0x2248CAE4),
    P("Лесная", 0xFF0B1511.toInt(), 0xFF15291F.toInt(), 0xCC1B3028.toInt(), 0xFFE6F2EA.toInt(), 0xFF8DB09B.toInt(), 0xFF66BB6A.toInt(), 0xFFA5D6A7.toInt(), stroke = 0x2266BB6A),
    P("Закат", 0xFF2A1520.toInt(), 0xFF40202F.toInt(), 0xCC3B1F2E.toInt(), 0xFFFFE9EE.toInt(), 0xFFC99AAA.toInt(), 0xFFFF7A59.toInt(), 0xFFFFB199.toInt(), stroke = 0x22FF7A59),
    P("Неон", 0xFF0A0118.toInt(), 0xFF1E0A3C.toInt(), 0xCC1D0F3A.toInt(), 0xFFF3E8FF.toInt(), 0xFFA78BCF.toInt(), 0xFF00E5FF.toInt(), 0xFFFF4DFF.toInt(), rad = 20, stroke = 0x6600E5FF),
    P("Аврора", 0xFF06161F.toInt(), 0xFF1B1038.toInt(), 0x99142B3A.toInt(), 0xFFE6FFFA.toInt(), 0xFF8FB8B5.toInt(), 0xFF5EEAD4.toInt(), 0xFFA78BFA.toInt(), rad = 22, stroke = 0x335EEAD4),
    P("Океан", 0xFF031B2B.toInt(), 0xFF0A4A5C.toInt(), 0x992A6F82.toInt(), 0xFFEAFBFF.toInt(), 0xFF9CC9D6.toInt(), 0xFF2DD4BF.toInt(), 0xFF38BDF8.toInt(), rad = 22, stroke = 0x3338BDF8),
    P("Кофе", 0xFF1C1410.toInt(), 0xFF2E2017.toInt(), 0xCC33241A.toInt(), 0xFFF5E6D3.toInt(), 0xFFB39B85.toInt(), 0xFFFFB74D.toInt(), 0xFFFFE0B2.toInt(), stroke = 0x22FFB74D),
    P("Сакура", 0xFFFFF1F5.toInt(), 0xFFFFDDE7.toInt(), 0xFFFFFFFF.toInt(), 0xFF3A1F2B.toInt(), 0xFF9C6B7E.toInt(), 0xFFE91E63.toInt(), 0xFFFF80AB.toInt(), true, 24, 0x22E91E63),
    P("Мята", 0xFFEAFBF3.toInt(), 0xFFCFF0E0.toInt(), 0xFFFFFFFF.toInt(), 0xFF0F2A20.toInt(), 0xFF5E8574.toInt(), 0xFF00A86B.toInt(), 0xFF6EE7B7.toInt(), true, 22, 0x2200A86B)
)

val TAGN = mapOf(
    "TITLE" to "Название", "ARTIST" to "Артист", "ALBUM" to "Альбом", "ALBUM_ARTIST" to "Исполнитель альбома",
    "AUTHOR" to "Автор", "WRITER" to "Автор текста", "COMPOSER" to "Композитор", "COMPILATION" to "Компиляция",
    "GENRE" to "Жанр", "YEAR" to "Год", "DATE" to "Дата", "TRACK_NUMBER" to "Номер трека",
    "NUM_TRACKS" to "Треков в альбоме", "DISC_NUMBER" to "Диск"
)

class Row(val t: Track, val plays: Int, val rank: Int)

class VH(val img: ImageView, val t: TextView, val a: TextView, val i: TextView, val b: TextView,
         val card: ShimmerCard, root: View) : RecyclerView.ViewHolder(root)

const val GOLD = 0xFFFFC83D.toInt()
const val SILVER = 0xFFC5CDD6.toInt()
const val BRONZE = 0xFFCD7F32.toInt()
fun metalOf(r: Int) = when (r) { 1 -> GOLD; 2 -> SILVER; 3 -> BRONZE; else -> 0 }

/** Состояние «сейчас играет», которое обновляет служба. */
object Now {
    var active = false
    var playing = false
    var key = ""
    var artist = ""
    var title = ""
    var album = ""
    var dur = 0L
    var pos = 0L
    var cover: Bitmap? = null
    var coverBase = ""
    var tags: JSONObject = JSONObject()
    var done = false
    var threshold = 60
    var onChange: (() -> Unit)? = null
    fun push() { onChange?.invoke() }
}

fun shade(c: Int, f: Float): Int {
    fun ch(x: Int) = if (f <= 1f) (x * f).toInt() else (x + (255 - x) * (f - 1f)).toInt().coerceIn(0, 255)
    return (0xFF shl 24) or (ch((c shr 16) and 255) shl 16) or (ch((c shr 8) and 255) shl 8) or ch(c and 255)
}
fun metalLight(c: Int) = shade(c, 1.6f)
fun metalDark(c: Int) = shade(c, 0.55f)
fun lum(c: Int) = (((c shr 16) and 255) * 299 + ((c shr 8) and 255) * 587 + (c and 255) * 114) / 1000
fun al(c: Int, a: Int) = (c and 0xFFFFFF) or (a shl 24)

/** Плашка. Для призовых мест: металлический фон, острый блик «лезвия» и искра. */
class ShimmerCard(c: Context, private val bg: Int, private val r: Float, private val accent: Int) : LinearLayout(c) {
    private var metal = 0
    private var sel = false
    private val d = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val selP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val body = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val g1 = Paint(Paint.ANTI_ALIAS_FLAG)
    private val g2 = Paint(Paint.ANTI_ALIAS_FLAG)
    private val star = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val path = Path()
    private val starPath = Path()
    private val mat = Matrix()
    private var s1: LinearGradient? = null
    private var s2: LinearGradient? = null
    private var bw = 0f
    private var phase = 0f
    private var anim: ValueAnimator? = null

    fun setMetal(m: Int) {
        metal = m; rebuild()
        if (isAttachedToWindow) restart()
        invalidate()
    }

    fun setSel(b: Boolean) { if (sel != b) { sel = b; invalidate() } }

    private fun rebuild() {
        s1 = null; s2 = null
        if (metal == 0 || width == 0 || height == 0) return
        val w = width.toFloat(); val h = height.toFloat()
        val lt = metalLight(metal); val dk = metalDark(metal)
        body.shader = LinearGradient(0f, 0f, w, h, intArrayOf(al(dk, 0x58), al(lt, 0x28), al(dk, 0x48), al(lt, 0x30)),
            floatArrayOf(0f, .35f, .7f, 1f), Shader.TileMode.CLAMP)
        edge.shader = LinearGradient(0f, 0f, w, h, intArrayOf(al(lt, 0xFF), al(metal, 0xD0), al(dk, 0xD0), al(lt, 0xFF)),
            floatArrayOf(0f, .4f, .7f, 1f), Shader.TileMode.CLAMP)
        glow.shader = RadialGradient(38 * d, h / 2, w * 0.55f, al(metal, 0x46), al(metal, 0), Shader.TileMode.CLAMP)
        bw = w * 0.22f
        val core = al(shade(metal, 2f), 0xF4)
        s1 = LinearGradient(0f, 0f, bw * 0.9f, bw * 0.45f, intArrayOf(0, al(lt, 0x50), core, al(lt, 0x50), 0),
            floatArrayOf(0f, .38f, .5f, .62f, 1f), Shader.TileMode.CLAMP)
        s2 = LinearGradient(0f, 0f, bw * 0.32f, bw * 0.16f, intArrayOf(0, al(lt, 0xA0), 0),
            floatArrayOf(0f, .5f, 1f), Shader.TileMode.CLAMP)
        g1.shader = s1; g2.shader = s2
    }

    private fun restart() {
        anim?.cancel(); anim = null
        if (metal != 0) {
            anim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = when (metal) { GOLD -> 2900L; SILVER -> 3400L; else -> 3900L }
                repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
                addUpdateListener { phase = it.animatedValue as Float; invalidate() }
                start()
            }
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); restart() }
    override fun onDetachedFromWindow() { anim?.cancel(); anim = null; super.onDetachedFromWindow() }
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { super.onSizeChanged(w, h, ow, oh); rebuild() }

    override fun dispatchDraw(cv: Canvas) {
        val w = width.toFloat()
        rect.set(0f, 0f, w, height.toFloat())
        fill.color = bg
        cv.drawRoundRect(rect, r, r, fill)
        var sx = -1f
        val a = s1; val b = s2
        if (metal != 0 && a != null && b != null) {
            cv.drawRoundRect(rect, r, r, body)
            cv.drawRoundRect(rect, r, r, glow)
            val t = phase / 0.34f
            if (t < 1f) {
                val e = t * t * (3 - 2 * t)
                val x = -bw * 1.3f + (w + bw * 1.7f) * e
                cv.save()
                path.reset(); path.addRoundRect(rect, r, r, Path.Direction.CW)
                cv.clipPath(path)
                mat.setTranslate(x - bw * 0.8f, 0f); b.setLocalMatrix(mat); cv.drawRect(rect, g2)
                mat.setTranslate(x, 0f); a.setLocalMatrix(mat); cv.drawRect(rect, g1)
                cv.restore()
                sx = x + bw * 0.45f
            }
            edge.strokeWidth = 1.8f * d
            val i = edge.strokeWidth / 2
            rect.inset(i, i); cv.drawRoundRect(rect, r - i, r - i, edge); rect.inset(-i, -i)
        }
        if (sel) {
            fill.color = al(accent, 0x2E)
            cv.drawRoundRect(rect, r, r, fill)
            selP.strokeWidth = 2.2f * d; selP.color = accent
            val i = selP.strokeWidth / 2
            rect.inset(i, i); cv.drawRoundRect(rect, r - i, r - i, selP); rect.inset(-i, -i)
        }
        super.dispatchDraw(cv)
        if (sx >= 0f) {
            val px = w - 28 * d; val py = 17 * d
            val range = bw * 0.9f
            val dist = Math.abs(sx - px)
            if (dist < range) {
                val k = 1f - dist / range
                val rr = 9 * d * k + 1
                val q = rr * 0.2f
                starPath.reset()
                starPath.moveTo(px, py - rr); starPath.lineTo(px + q, py - q); starPath.lineTo(px + rr, py)
                starPath.lineTo(px + q, py + q); starPath.lineTo(px, py + rr); starPath.lineTo(px - q, py + q)
                starPath.lineTo(px - rr, py); starPath.lineTo(px - q, py - q); starPath.close()
                star.color = al(0xFFFFFF, (255 * k).toInt())
                cv.drawPath(starPath, star)
            }
        }
    }
}

/** Анимированный эквалайзер. */
class EqView(c: Context, col: Int) : View(c) {
    private val pa = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = col }
    private val rf = RectF()
    private var ph = 0f
    private var an: ValueAnimator? = null
    private var on = false

    fun setPlaying(b: Boolean) {
        if (b == on) return
        on = b
        an?.cancel(); an = null
        if (b) {
            an = ValueAnimator.ofFloat(0f, (2 * Math.PI).toFloat()).apply {
                duration = 1100; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
                addUpdateListener { ph = it.animatedValue as Float; invalidate() }
                start()
            }
        } else invalidate()
    }

    override fun onDetachedFromWindow() { an?.cancel(); an = null; on = false; super.onDetachedFromWindow() }

    override fun onDraw(cv: Canvas) {
        val n = 4
        val bw = width / (n * 2f - 1f)
        for (i in 0 until n) {
            val f = if (on) 0.25f + 0.75f * Math.abs(Math.sin((ph * (1 + i * 0.35f) + i * 1.3f).toDouble())).toFloat() else 0.3f
            val h = height * f
            rf.set(i * 2 * bw, height - h, i * 2 * bw + bw, height.toFloat())
            cv.drawRoundRect(rf, bw / 2, bw / 2, pa)
        }
    }
}

/** Тонкая полоска прогресса с плавным движением. */
class Prog(c: Context, private val p: P) : View(c) {
    private var f = 0f
    private val pa = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rf = RectF()
    private var an: ValueAnimator? = null
    private var sh: LinearGradient? = null
    private var shW = 0

    fun to(v: Float, jump: Boolean) {
        an?.cancel()
        val t = v.coerceIn(0f, 1f)
        if (jump) { f = t; invalidate(); return }
        an = ValueAnimator.ofFloat(f, t).apply {
            duration = 900; interpolator = LinearInterpolator()
            addUpdateListener { f = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDraw(cv: Canvas) {
        val h = height.toFloat()
        pa.color = (p.tx and 0xFFFFFF) or (0x22 shl 24)
        rf.set(0f, 0f, width.toFloat(), h); cv.drawRoundRect(rf, h / 2, h / 2, pa)
        if (sh == null || shW != width) { sh = LinearGradient(0f, 0f, width.toFloat(), 0f, p.ac, p.ac2, Shader.TileMode.CLAMP); shW = width }
        pa.shader = sh
        rf.set(0f, 0f, maxOf(width * f, h), h); cv.drawRoundRect(rf, h / 2, h / 2, pa)
        pa.shader = null
    }
}

/** Кольцевая диаграмма: утро / день / вечер / ночь. */
class DayDonut(c: Context, private val p: P) : View(c) {
    val colors = intArrayOf(0xFFFFB74D.toInt(), 0xFF4FC3F7.toInt(), 0xFFFF7A59.toInt(), 0xFF7E57C2.toInt())
    private val em = arrayOf("🌅", "☀️", "🌇", "🌙")
    private val nm = arrayOf("Утро", "День", "Вечер", "Ночь")
    private var cnt = IntArray(4)
    private var prog = 0f
    private val pa = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val rf = RectF()
    private val d = resources.displayMetrics.density

    fun set(v: IntArray) {
        cnt = v
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 800; interpolator = DecelerateInterpolator()
            addUpdateListener { prog = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDraw(cv: Canvas) {
        val sz = minOf(width, height).toFloat()
        val sw = 20 * d
        val cx = width / 2f; val cy = height / 2f
        rf.set(cx - sz / 2 + sw / 2 + 4 * d, cy - sz / 2 + sw / 2 + 4 * d, cx + sz / 2 - sw / 2 - 4 * d, cy + sz / 2 - sw / 2 - 4 * d)
        pa.strokeWidth = sw
        pa.color = (p.tx and 0xFFFFFF) or (0x22 shl 24)
        cv.drawArc(rf, 0f, 360f, false, pa)
        val total = cnt.sum()
        if (total > 0) {
            var start = -90f
            val gap = if (cnt.count { it > 0 } > 1) 4f else 0f
            for (i in 0..3) {
                if (cnt[i] == 0) continue
                val sweep = 360f * cnt[i] / total
                pa.color = colors[i]
                cv.drawArc(rf, start + gap / 2, maxOf(sweep - gap, 1f) * prog, false, pa)
                start += sweep
            }
            var best = 0
            for (i in 1..3) if (cnt[i] > cnt[best]) best = i
            tp.textSize = 30 * d; tp.color = p.tx
            cv.drawText(em[best], cx, cy + 6 * d, tp)
            tp.textSize = 12 * d; tp.color = p.sub
            cv.drawText(nm[best], cx, cy + 26 * d, tp)
        } else {
            tp.textSize = 22 * d; tp.color = p.sub
            cv.drawText("—", cx, cy + 8 * d, tp)
        }
    }
}

/** Упругий отскок списка у края. Состояние края не копится, поэтому после отскока клики сразу работают. */
class Bounce : RecyclerView.EdgeEffectFactory() {
    override fun createEdgeEffect(rv: RecyclerView, direction: Int): EdgeEffect {
        return object : EdgeEffect(rv.context) {
            private val sign = if (direction == RecyclerView.EdgeEffectFactory.DIRECTION_BOTTOM) -1f else 1f
            private val anim = SpringAnimation(rv, DynamicAnimation.TRANSLATION_Y, 0f).apply {
                spring.dampingRatio = 0.45f
                spring.stiffness = 180f
                addEndListener { _, _, _, _ -> rv.translationY = 0f }
            }

            private fun pull(d: Float): Float {
                anim.cancel()
                val before = rv.translationY
                var t = before + sign * rv.height * d * 0.2f
                t = if (sign > 0) maxOf(0f, t) else minOf(0f, t)
                rv.translationY = t
                return if (before == 0f && d < 0f) 0f else d
            }

            override fun onPull(d: Float) { pull(d) }
            override fun onPull(d: Float, disp: Float) { pull(d) }
            override fun onPullDistance(d: Float, disp: Float): Float = pull(d)
            override fun getDistance(): Float = 0f
            override fun onRelease() { anim.start() }
            override fun onAbsorb(v: Int) { anim.setStartVelocity(sign * v * 0.1f).start() }
            override fun draw(c: Canvas): Boolean = false
        }
    }
}

/** Гистограмма активности по дням недели. */
class WeekChart(c: Context, private val p: P) : View(c) {
    private var vals = FloatArray(7)
    private var today = -1
    private var prog = 1f
    private val names = arrayOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")
    private val pa = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val rf = RectF()
    private val d = resources.displayMetrics.density

    fun set(v: FloatArray, t: Int) {
        vals = v; today = t
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 500; interpolator = DecelerateInterpolator()
            addUpdateListener { prog = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val colW = w / 7
        val topH = 20 * d; val botH = 24 * d
        val areaTop = topH + 4 * d; val areaBot = h - botH
        val mx = maxOf(vals.max(), 1f)
        for (i in 0..6) {
            val cx = colW * i + colW / 2
            val bw = colW * 0.52f
            pa.color = (p.tx and 0xFFFFFF) or (0x22 shl 24)
            rf.set(cx - bw / 2, areaTop, cx + bw / 2, areaBot)
            cv.drawRoundRect(rf, bw / 2, bw / 2, pa)
            if (vals[i] > 0f) {
                val fh = (areaBot - areaTop) * (vals[i] / mx) * prog
                val top = minOf(areaBot - maxOf(fh, bw), areaBot - bw)
                pa.color = if (i == today) p.ac else (p.ac and 0xFFFFFF) or (0xB0 shl 24)
                rf.set(cx - bw / 2, top, cx + bw / 2, areaBot)
                cv.drawRoundRect(rf, bw / 2, bw / 2, pa)
            }
            tp.textSize = 11 * d
            tp.typeface = Typeface.DEFAULT
            tp.color = p.tx
            val label = if (vals[i] <= 0f) "0" else if (vals[i] < 0.1f) "<0,1" else "%.1f".format(vals[i])
            cv.drawText(label, cx, topH - 6 * d, tp)
            tp.color = if (i == today) p.ac else p.sub
            if (i == today) tp.typeface = Typeface.DEFAULT_BOLD
            cv.drawText(names[i], cx, h - 7 * d, tp)
        }
    }
}

/** Плавный зум: щипок вокруг пальцев, перемещение, двойной тап. */
class ZoomView(c: Context) : ImageView(c) {
    private val m = Matrix()
    private val v = FloatArray(9)
    private var base = 1f

    private val sd = ScaleGestureDetector(c, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            val s = cur()
            val ns = (s * d.scaleFactor).coerceIn(base, base * 8f)
            val f = ns / s
            m.postScale(f, f, d.focusX, d.focusY)
            fix()
            return true
        }
    })
    private val gd = GestureDetector(c, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent) = true
        override fun onScroll(a: MotionEvent?, b: MotionEvent, dx: Float, dy: Float): Boolean {
            m.postTranslate(-dx, -dy); fix(); return true
        }
        override fun onDoubleTap(e: MotionEvent): Boolean {
            animateTo(if (cur() > base * 1.05f) base else base * 3f, e.x, e.y); return true
        }
    })

    init {
        scaleType = ScaleType.MATRIX
        sd.isQuickScaleEnabled = false
    }

    private fun cur(): Float { m.getValues(v); return v[Matrix.MSCALE_X] }

    private fun fix() {
        val dr = drawable ?: return
        m.getValues(v)
        val sc = v[Matrix.MSCALE_X]
        val w = dr.intrinsicWidth * sc
        val h = dr.intrinsicHeight * sc
        val tx = if (w <= width) (width - w) / 2 else v[Matrix.MTRANS_X].coerceIn(width - w, 0f)
        val ty = if (h <= height) (height - h) / 2 else v[Matrix.MTRANS_Y].coerceIn(height - h, 0f)
        m.postTranslate(tx - v[Matrix.MTRANS_X], ty - v[Matrix.MTRANS_Y])
        imageMatrix = m
    }

    private fun fit() {
        val dr = drawable ?: return
        if (width == 0 || height == 0) return
        val dw = dr.intrinsicWidth.toFloat(); val dh = dr.intrinsicHeight.toFloat()
        base = minOf(width / dw, height / dh)
        m.reset()
        m.postScale(base, base)
        m.postTranslate((width - dw * base) / 2, (height - dh * base) / 2)
        imageMatrix = m
    }

    private fun animateTo(target: Float, px: Float, py: Float) {
        val s0 = cur()
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 240; interpolator = DecelerateInterpolator()
            addUpdateListener {
                val ns = s0 + (target - s0) * (it.animatedValue as Float)
                val f = ns / cur()
                m.postScale(f, f, px, py); fix()
            }
            start()
        }
    }

    override fun setImageBitmap(bm: Bitmap?) { super.setImageBitmap(bm); fit() }
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { super.onSizeChanged(w, h, ow, oh); fit() }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        sd.onTouchEvent(e); gd.onTouchEvent(e)
        return true
    }
}

/** Месячный календарь: тепловая карта прослушиваний по дням. */
class CalView(c: Context, private val p: P) : View(c) {
    var onPick: ((Int) -> Unit)? = null
    var onSwipe: ((Int) -> Unit)? = null
    private var counts = IntArray(32)
    private var selected = 0
    private var today = 0
    private var firstCol = 0
    private var days = 30
    private val d = resources.displayMetrics.density
    private val head = 26 * d
    private val rowH = 48 * d
    private val pa = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val names = arrayOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")
    private val gd = GestureDetector(c, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent) = true
        override fun onSingleTapUp(e: MotionEvent): Boolean { pick(e.x, e.y); return true }
        override fun onFling(a: MotionEvent?, b: MotionEvent, vx: Float, vy: Float): Boolean {
            if (a == null) return false
            val dx = b.x - a.x
            if (Math.abs(dx) > 60 * d && Math.abs(dx) > Math.abs(b.y - a.y) * 1.2f) { onSwipe?.invoke(if (dx > 0) -1 else 1); return true }
            return false
        }
    })

    fun setData(year: Int, month: Int, cnt: IntArray, sel: Int, tod: Int) {
        val cal = Calendar.getInstance(); cal.clear(); cal.set(year, month, 1)
        firstCol = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7
        days = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        counts = cnt; selected = sel; today = tod
        invalidate()
    }

    private fun pick(x: Float, y: Float) {
        if (y < head) return
        val col = (x / (width / 7f)).toInt().coerceIn(0, 6)
        val row = ((y - head) / rowH).toInt()
        if (row !in 0..5) return
        val day = row * 7 + col - firstCol + 1
        if (day in 1..days) { selected = day; invalidate(); onPick?.invoke(day) }
    }

    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(MeasureSpec.getSize(w), (head + 6 * rowH).toInt()) }
    override fun onTouchEvent(e: MotionEvent): Boolean { gd.onTouchEvent(e); return true }

    override fun onDraw(cv: Canvas) {
        val cw = width / 7f
        tp.typeface = Typeface.DEFAULT
        for (i in 0..6) { tp.color = p.sub; tp.textSize = 12 * d; cv.drawText(names[i], cw * i + cw / 2, head - 8 * d, tp) }
        val mx = maxOf(1, counts.max())
        val onAcc = if (lum(p.ac) > 150) 0xFF101010.toInt() else 0xFFFFFFFF.toInt()
        for (day in 1..days) {
            val idx = firstCol + day - 1
            val cx = cw * (idx % 7) + cw / 2
            val cy = head + rowH * (idx / 7) + rowH / 2
            val n = counts[day]
            val isSel = day == selected
            pa.style = Paint.Style.FILL
            if (isSel) { pa.color = p.ac; cv.drawCircle(cx, cy, 21 * d, pa) }
            else if (n > 0) { pa.color = al(p.ac, 0x30 + 0x70 * n / mx); cv.drawCircle(cx, cy, 20 * d, pa) }
            if (day == today && !isSel) {
                pa.style = Paint.Style.STROKE; pa.strokeWidth = 1.6f * d; pa.color = p.ac
                cv.drawCircle(cx, cy, 20 * d, pa)
            }
            tp.typeface = if (isSel || day == today) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            tp.textSize = 15 * d
            tp.color = if (isSel) onAcc else p.tx
            cv.drawText(day.toString(), cx, if (n > 0) cy - 1 * d else cy + 5 * d, tp)
            if (n > 0) {
                tp.typeface = Typeface.DEFAULT; tp.textSize = 9 * d
                tp.color = if (isSel) onAcc else p.sub
                cv.drawText(n.toString(), cx, cy + 14 * d, tp)
            }
        }
    }
}


/** Фон плашки «сейчас играет»: обложка + цвет из обложки. */
class NowBg(c: Context, private val p: P) : View(c) {
    private var bm: Bitmap? = null
    private var tintC = 0
    private var coverA = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val rect = RectF()
    private val dst = RectF()
    private val src = Rect()
    private val path = Path()
    private val r = 20 * resources.displayMetrics.density
    private var shader: LinearGradient? = null
    private var shBase = 0
    private var shW = 0

    fun clear() { bm = null; tintC = 0; coverA = 0f; invalidate() }

    // фон не должен сам раздуваться: высоту ему задаёт плашка
    override fun onMeasure(wm: Int, hm: Int) {
        val h = if (View.MeasureSpec.getMode(hm) == View.MeasureSpec.EXACTLY) View.MeasureSpec.getSize(hm) else 0
        setMeasuredDimension(View.MeasureSpec.getSize(wm), h)
    }

    fun setCover(b: Bitmap) {
        bm = b
        ValueAnimator.ofFloat(coverA, 1f).apply {
            duration = 650; interpolator = EASE
            addUpdateListener { coverA = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    fun tint(col: Int) {
        val from = if (tintC == 0) over(p.card, p.bg2) else tintC
        ValueAnimator.ofObject(ArgbEvaluator(), from, col).apply {
            duration = 800; interpolator = EASE
            addUpdateListener { tintC = it.animatedValue as Int; invalidate() }
            start()
        }
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        rect.set(0f, 0f, w, h)
        val baseCard = over(p.card, p.bg2)
        val base = if (tintC == 0) baseCard else mix(baseCard, tintC, if (p.light) 0.34f else 0.45f)
        path.reset(); path.addRoundRect(rect, r, r, Path.Direction.CW)
        cv.save(); cv.clipPath(path)
        paint.shader = null; paint.color = base
        cv.drawRect(rect, paint)
        val b = bm
        if (b != null) {
            val sc = maxOf(w / b.width, h / b.height)
            val sw = w / sc; val sh = h / sc
            val l = (b.width - sw) / 2; val t = (b.height - sh) / 2
            src.set(l.toInt(), t.toInt(), (l + sw).toInt(), (t + sh).toInt())
            dst.set(0f, 0f, w, h)
            bp.alpha = (170 * coverA).toInt()
            cv.drawBitmap(b, src, dst, bp)
        }
        if (shader == null || shBase != base || shW != width) {
            shader = LinearGradient(0f, 0f, w, 0f,
                intArrayOf(withA(base, 0xFF), withA(base, 0xE8), withA(base, 0x28)),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
            shBase = base; shW = width
        }
        paint.shader = shader
        cv.drawRect(rect, paint)
        paint.shader = null
        cv.restore()
        val sw = resources.displayMetrics.density * 1.2f
        paint.style = Paint.Style.STROKE; paint.strokeWidth = sw
        paint.color = withA(if (tintC == 0) p.ac else tintC, 0x99)
        rect.inset(sw / 2, sw / 2)
        cv.drawRoundRect(rect, r - sw / 2, r - sw / 2, paint)
        paint.style = Paint.Style.FILL
    }
}

/** Анимированный огонёк серии. */
class FlameView(c: Context) : View(c) {
    private var active = false
    private var t = 0f
    private var an: ValueAnimator? = null
    private val outer = Path()
    private val inner = Path()
    private val po = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pi = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pg = Paint(Paint.ANTI_ALIAS_FLAG)
    private var shO: LinearGradient? = null
    private var shI: LinearGradient? = null
    private var shG: RadialGradient? = null

    fun setActive(a: Boolean) {
        if (a == active && (an != null) == a) return
        active = a
        an?.cancel(); an = null
        if (a && isAttachedToWindow) start() else invalidate()
    }

    private fun start() {
        an = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1300; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
            addUpdateListener { t = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); if (active && an == null) start() }
    override fun onDetachedFromWindow() { an?.cancel(); an = null; super.onDetachedFromWindow() }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        shO = LinearGradient(0f, h * 0.1f, 0f, h.toFloat(),
            intArrayOf(0xFFFFE082.toInt(), 0xFFFF9800.toInt(), 0xFFE53935.toInt()), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        shI = LinearGradient(0f, h * 0.4f, 0f, h.toFloat(),
            intArrayOf(0xFFFFFDE7.toInt(), 0xFFFFD54F.toInt()), null, Shader.TileMode.CLAMP)
        shG = RadialGradient(w / 2f, h * 0.6f, w * 0.95f, intArrayOf(0x80FF9800.toInt(), 0x00FF9800), null, Shader.TileMode.CLAMP)
    }

    private fun build(p: Path, cx: Float, baseY: Float, w: Float, h: Float, hf: Float, sway: Float) {
        p.reset()
        val tx = cx + sway; val ty = baseY - h * 0.9f * hf
        p.moveTo(tx, ty)
        p.cubicTo(cx + w * 0.10f + sway * 0.5f, baseY - h * 0.62f, cx + w * 0.50f, baseY - h * 0.40f, cx + w * 0.38f, baseY - h * 0.16f)
        p.cubicTo(cx + w * 0.30f, baseY + h * 0.03f, cx - w * 0.30f, baseY + h * 0.03f, cx - w * 0.38f, baseY - h * 0.16f)
        p.cubicTo(cx - w * 0.50f, baseY - h * 0.40f, cx - w * 0.10f + sway * 0.5f, baseY - h * 0.62f, tx, ty)
        p.close()
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val cx = w / 2; val baseY = h * 0.95f
        if (active) {
            val s = Math.sin(t * 2 * Math.PI).toFloat()
            val s2 = Math.sin(t * 5 * Math.PI + 1.0).toFloat()
            pg.shader = shG; pg.alpha = (190 + 60 * s).toInt()
            cv.drawCircle(cx, h * 0.6f, w * 0.95f, pg)
            build(outer, cx, baseY, w, h * 0.95f, 0.93f + 0.07f * s + 0.04f * s2, s * w * 0.05f)
            po.shader = shO
            cv.drawPath(outer, po)
            build(inner, cx, baseY, w * 0.55f, h * 0.6f, 0.95f + 0.05f * s2 + 0.04f * s, s * w * 0.03f)
            pi.shader = shI
            cv.drawPath(inner, pi)
        } else {
            build(outer, cx, baseY, w, h * 0.95f, 1f, 0f)
            po.shader = null; po.color = 0x44888888
            cv.drawPath(outer, po)
        }
    }
}

/** Превью темы для выбора. */
class ThemePreview(c: Context, private val t: P, private val selected: Boolean) : View(c) {
    private val d = resources.displayMetrics.density
    private val pa = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rf = RectF()

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val r = 16 * d
        rf.set(0f, 0f, w, h)
        pa.style = Paint.Style.FILL
        pa.shader = LinearGradient(0f, 0f, 0f, h, t.bg, t.bg2, Shader.TileMode.CLAMP)
        cv.drawRoundRect(rf, r, r, pa)
        pa.shader = null
        tp.color = t.tx; tp.textSize = 12 * d
        tp.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        cv.drawText(t.n, 12 * d, 22 * d, tp)
        val cardC = mix(over(t.card, t.bg2), t.tx, 0.07f)
        for (i in 0..1) {
            val top = 34 * d + i * 30 * d
            rf.set(10 * d, top, w - 10 * d, top + 24 * d)
            pa.style = Paint.Style.FILL; pa.color = cardC
            cv.drawRoundRect(rf, 9 * d, 9 * d, pa)
            if (t.stroke != 0) {
                pa.style = Paint.Style.STROKE; pa.strokeWidth = d; pa.color = t.stroke
                cv.drawRoundRect(rf, 9 * d, 9 * d, pa)
                pa.style = Paint.Style.FILL
            }
            rf.set(14 * d, top + 4 * d, 30 * d, top + 20 * d)
            pa.color = withA(t.ac, if (i == 0) 0xFF else 0x99)
            cv.drawRoundRect(rf, 5 * d, 5 * d, pa)
            pa.color = withA(t.tx, 0xB0)
            rf.set(36 * d, top + 7 * d, 36 * d + w * 0.38f, top + 11 * d)
            cv.drawRoundRect(rf, 2 * d, 2 * d, pa)
            pa.color = withA(t.sub, 0x99)
            rf.set(36 * d, top + 14 * d, 36 * d + w * 0.22f, top + 17 * d)
            cv.drawRoundRect(rf, 2 * d, 2 * d, pa)
        }
        pa.color = t.ac2
        rf.set(w - 30 * d, 12 * d, w - 14 * d, 20 * d)
        cv.drawRoundRect(rf, 4 * d, 4 * d, pa)
        if (selected) {
            pa.style = Paint.Style.STROKE; pa.strokeWidth = 3 * d; pa.color = t.ac
            rf.set(1.5f * d, 1.5f * d, w - 1.5f * d, h - 1.5f * d)
            cv.drawRoundRect(rf, r, r, pa)
            pa.style = Paint.Style.FILL
            cv.drawCircle(w - 18 * d, h - 18 * d, 11 * d, pa)
            tp.color = if (t.light) 0xFFFFFFFF.toInt() else 0xFF101010.toInt()
            tp.textSize = 14 * d; tp.textAlign = Paint.Align.CENTER
            cv.drawText("✓", w - 18 * d, h - 13 * d, tp)
            tp.textAlign = Paint.Align.LEFT
        }
    }
}
