package com.example.aimphistory

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView

class P(val n: String, val bg: Int, val card: Int, val tx: Int, val sub: Int, val ac: Int, val light: Boolean = false)

val PALS = listOf(
    P("Тёмная", 0xFF121212.toInt(), 0xFF1E1E1E.toInt(), 0xFFFFFFFF.toInt(), 0xFFA0A0A0.toInt(), 0xFF4FC3F7.toInt()),
    P("AMOLED", 0xFF000000.toInt(), 0xFF111111.toInt(), 0xFFFFFFFF.toInt(), 0xFF909090.toInt(), 0xFFBB86FC.toInt()),
    P("Светлая", 0xFFF2F2F7.toInt(), 0xFFFFFFFF.toInt(), 0xFF111111.toInt(), 0xFF6B6B6B.toInt(), 0xFF1976D2.toInt(), true),
    P("Синяя ночь", 0xFF0D1B2A.toInt(), 0xFF1B2B40.toInt(), 0xFFE0E1DD.toInt(), 0xFF8FA3B8.toInt(), 0xFF48CAE4.toInt()),
    P("Лесная", 0xFF10201A.toInt(), 0xFF1B3028.toInt(), 0xFFE6F2EA.toInt(), 0xFF8DB09B.toInt(), 0xFF66BB6A.toInt()),
    P("Закат", 0xFF2A1520.toInt(), 0xFF3B1F2E.toInt(), 0xFFFFE9EE.toInt(), 0xFFC99AAA.toInt(), 0xFFFF7A59.toInt())
)

val TAGN = mapOf(
    "TITLE" to "Название", "ARTIST" to "Артист", "ALBUM" to "Альбом", "ALBUM_ARTIST" to "Исполнитель альбома",
    "AUTHOR" to "Автор", "WRITER" to "Автор текста", "COMPOSER" to "Композитор", "COMPILATION" to "Компиляция",
    "GENRE" to "Жанр", "YEAR" to "Год", "DATE" to "Дата", "TRACK_NUMBER" to "Номер трека",
    "NUM_TRACKS" to "Треков в альбоме", "DISC_NUMBER" to "Диск"
)

class VH(val img: ImageView, val t: android.widget.TextView, val a: android.widget.TextView,
         val i: android.widget.TextView, root: View) : RecyclerView.ViewHolder(root)

/** Гистограмма активности по дням недели. */
class WeekChart(c: Context, private val p: P) : View(c) {
    private var vals = FloatArray(7)
    private var today = -1
    private var prog = 1f
    private val names = arrayOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")
    private val pa = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val rf = RectF()
    private val d = resources.displayMetrics.density

    fun set(v: FloatArray, t: Int) {
        vals = v; today = t
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 500; interpolator = DecelerateInterpolator()
            addUpdateListener { prog = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val colW = w / 7
        val topH = 20 * d; val botH = 24 * d
        val areaTop = topH + 4 * d; val areaBot = h - botH
        val mx = maxOf(vals.max(), 1f)
        for (i in 0..6) {
            val cx = colW * i + colW / 2
            val bw = colW * 0.52f
            pa.color = (p.tx and 0xFFFFFF) or (0x22 shl 24)
            rf.set(cx - bw / 2, areaTop, cx + bw / 2, areaBot)
            cv.drawRoundRect(rf, bw / 2, bw / 2, pa)
            if (vals[i] > 0f) {
                val fh = (areaBot - areaTop) * (vals[i] / mx) * prog
                val top = minOf(areaBot - maxOf(fh, bw), areaBot - bw)
                pa.color = if (i == today) p.ac else (p.ac and 0xFFFFFF) or (0xB0 shl 24)
                rf.set(cx - bw / 2, top, cx + bw / 2, areaBot)
                cv.drawRoundRect(rf, bw / 2, bw / 2, pa)
            }
            tp.textSize = 11 * d
            tp.typeface = Typeface.DEFAULT
            tp.color = p.tx
            val label = if (vals[i] <= 0f) "0" else if (vals[i] < 0.1f) "<0,1" else "%.1f".format(vals[i])
            cv.drawText(label, cx, topH - 6 * d, tp)
            tp.color = if (i == today) p.ac else p.sub
            if (i == today) tp.typeface = Typeface.DEFAULT_BOLD
            cv.drawText(names[i], cx, h - 7 * d, tp)
        }
    }
}

/** Плавный зум: щипок вокруг пальцев, перемещение, двойной тап. */
class ZoomView(c: Context) : ImageView(c) {
    private val m = Matrix()
    private val v = FloatArray(9)
    private var base = 1f

    private val sd = ScaleGestureDetector(c, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            val s = cur()
            val ns = (s * d.scaleFactor).coerceIn(base, base * 8f)
            val f = ns / s
            m.postScale(f, f, d.focusX, d.focusY)
            fix()
            return true
        }
    })
    private val gd = GestureDetector(c, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent) = true
        override fun onScroll(a: MotionEvent?, b: MotionEvent, dx: Float, dy: Float): Boolean {
            m.postTranslate(-dx, -dy); fix(); return true
        }
        override fun onDoubleTap(e: MotionEvent): Boolean {
            animateTo(if (cur() > base * 1.05f) base else base * 3f, e.x, e.y); return true
        }
    })

    init {
        scaleType = ScaleType.MATRIX
        sd.isQuickScaleEnabled = false
    }

    private fun cur(): Float { m.getValues(v); return v[Matrix.MSCALE_X] }

    private fun fix() {
        val dr = drawable ?: return
        m.getValues(v)
        val sc = v[Matrix.MSCALE_X]
        val w = dr.intrinsicWidth * sc
        val h = dr.intrinsicHeight * sc
        val tx = if (w <= width) (width - w) / 2 else v[Matrix.MTRANS_X].coerceIn(width - w, 0f)
        val ty = if (h <= height) (height - h) / 2 else v[Matrix.MTRANS_Y].coerceIn(height - h, 0f)
        m.postTranslate(tx - v[Matrix.MTRANS_X], ty - v[Matrix.MTRANS_Y])
        imageMatrix = m
    }

    private fun fit() {
        val dr = drawable ?: return
        if (width == 0 || height == 0) return
        val dw = dr.intrinsicWidth.toFloat(); val dh = dr.intrinsicHeight.toFloat()
        base = minOf(width / dw, height / dh)
        m.reset()
        m.postScale(base, base)
        m.postTranslate((width - dw * base) / 2, (height - dh * base) / 2)
        imageMatrix = m
    }

    private fun animateTo(target: Float, px: Float, py: Float) {
        val s0 = cur()
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 240; interpolator = DecelerateInterpolator()
            addUpdateListener {
                val ns = s0 + (target - s0) * (it.animatedValue as Float)
                val f = ns / cur()
                m.postScale(f, f, px, py); fix()
            }
            start()
        }
    }

    override fun setImageBitmap(bm: Bitmap?) { super.setImageBitmap(bm); fit() }
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { super.onSizeChanged(w, h, ow, oh); fit() }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        sd.onTouchEvent(e); gd.onTouchEvent(e)
        return true
    }
}
